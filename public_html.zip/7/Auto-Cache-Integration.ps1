# PowerShell Script لإضافة Cache Busting تلقائياً لكل ملفات HTML
# Auto Cache Busting Integration for Windows

Write-Host "بدء إضافة Cache Busting لكل ملفات HTML..." -ForegroundColor Green

# Template للصفحات العادية
$regularTemplate = @"
    <!-- Cache Busting System -->
    <script src="cache-busting.js"></script>
    <script>
        // Initialize cache busting for regular pages
        const pageCacheBuster = new CacheBuster({
            checkInterval: 30000,
            showNotifications: true,
            autoRefresh: false,
            customMessage: 'تم تحديث الصفحة - تحديث متاح'
        });
        pageCacheBuster.start();
    </script>
"@

# Template للصفحات الإدارية
$adminTemplate = @"
    <!-- Cache Busting System -->
    <script src="cache-busting.js"></script>
    <script>
        // Initialize cache busting for admin pages
        const adminCacheBuster = new CacheBuster({
            checkInterval: 10000,
            showNotifications: true,
            autoRefresh: true,
            customMessage: 'تم تحديث النظام الإداري'
        });
        adminCacheBuster.start();
    </script>
"@

# قائمة الصفحات الإدارية
$adminPages = @(
    "admin.html",
    "superadmin.html",
    "admin-register.html",
    "manage-family-members.html",
    "manage-members.html",
    "manage-aid.html",
    "manage-aid-new.html",
    "manage-special-cases.html",
    "user-requests-admin.html",
    "deaths-admin.html",
    "injuries-admin.html",
    "martyrs-admin.html",
    "aid-logs.html",
    "password-resets.html",
    "edit-requests.html"
)

# قائمة الصفحات المعالجة بالفعل
$processedPages = @(
    "admin.html",
    "index.html",
    "dashboard.html",
    "manage-family-members.html"
)

# البحث عن كل ملفات HTML
$htmlFiles = Get-ChildItem -Path "." -Filter "*.html"

foreach ($file in $htmlFiles) {
    $fileName = $file.Name
    $filePath = $file.FullName
    
    # قراءة محتوى الملف
    $content = Get-Content -Path $filePath -Raw -Encoding UTF8
    
    # تحقق إذا كان يحتوي بالفعل على cache-busting
    if ($content -like "*cache-busting.js*") {
        Write-Host "✓ $fileName - يحتوي بالفعل على cache busting" -ForegroundColor Yellow
        continue
    }
    
    # تحقق إذا كان في قائمة المعالجة
    if ($processedPages -contains $fileName) {
        Write-Host "✓ $fileName - معالج بالفعل" -ForegroundColor Yellow
        continue
    }
    
    # تحديد نوع Template
    if ($adminPages -contains $fileName) {
        $template = $adminTemplate
        Write-Host "🔧 معالجة $fileName (صفحة إدارية)..." -ForegroundColor Cyan
    } else {
        $template = $regularTemplate
        Write-Host "🔧 معالجة $fileName (صفحة عادية)..." -ForegroundColor Cyan
    }
    
    # تحقق من وجود </body>
    if ($content -like "*</body>*") {
        # إنشاء نسخة احتياطية
        $backupPath = $filePath + ".backup"
        Copy-Item -Path $filePath -Destination $backupPath
        
        # إضافة template قبل </body>
        $newContent = $content -replace "</body>", "$template`n</body>"
        
        # كتابة المحتوى الجديد
        $newContent | Out-File -FilePath $filePath -Encoding UTF8
        
        Write-Host "✅ تم إضافة cache busting لـ $fileName" -ForegroundColor Green
    } else {
        Write-Host "⚠️  $fileName - لا يحتوي على tag </body>" -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "🎉 انتهت معالجة كل ملفات HTML!" -ForegroundColor Green
Write-Host "📝 تم إنشاء نسخ احتياطية بامتداد .backup" -ForegroundColor Yellow
Write-Host ""
Write-Host "الخطوة التالية:" -ForegroundColor Magenta
Write-Host "1. ارفع كل الملفات للاستضافة" -ForegroundColor White
Write-Host "2. اختبر الموقع للتأكد من عمل cache busting" -ForegroundColor White
Write-Host "3. احذف ملفات .backup إذا كان كل شيء يعمل بشكل صحيح" -ForegroundColor White

# إحصائيات
$totalFiles = $htmlFiles.Count
Write-Host ""
Write-Host "📊 إحصائيات:" -ForegroundColor Magenta
Write-Host "   إجمالي ملفات HTML: $totalFiles" -ForegroundColor White
Write-Host "   ملفات معالجة: $($processedPages.Count)" -ForegroundColor White
Write-Host "   ملفات إدارية: $($adminPages.Count)" -ForegroundColor White

# عرض قائمة بالملفات المهمة
Write-Host ""
Write-Host "📋 ملفات HTML الرئيسية في الموقع:" -ForegroundColor Magenta
$htmlFiles | ForEach-Object { 
    $icon = if ($adminPages -contains $_.Name) { "🔧" } elseif ($processedPages -contains $_.Name) { "✅" } else { "📄" }
    Write-Host "   $icon $($_.Name)" -ForegroundColor White
}
