# نظام فحص جميع الملفات للرفع على الاستضافة
# Complete Files Check for Upload

Clear-Host
Write-Host ""
Write-Host "=========================================================" -ForegroundColor Cyan
Write-Host "   نظام فحص وتجهيز جميع الملفات v4.0.0" -ForegroundColor Yellow
Write-Host "=========================================================" -ForegroundColor Cyan
Write-Host ""

$version = "4.0.0"
$updateDate = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$timestamp = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()

# جمع جميع الملفات
$htmlFiles = Get-ChildItem -Path . -Filter "*.html" -File | Where-Object { $_.Name -notlike "test-*" }
$cssFiles = Get-ChildItem -Path . -Filter "*.css" -File
$jsFiles = Get-ChildItem -Path . -Filter "*.js" -File
$jsonFiles = Get-ChildItem -Path . -Filter "*.json" -File
$phpFiles = Get-ChildItem -Path . -Filter "*.php" -File
$gsFiles = Get-ChildItem -Path . -Filter "*.gs" -File
$imgFiles = Get-ChildItem -Path . -Filter "*.webp" -File

Write-Host "[1/5] احصاء الملفات..." -ForegroundColor Yellow
Write-Host ""
Write-Host "  HTML: $($htmlFiles.Count) ملف" -ForegroundColor Green
Write-Host "  CSS: $($cssFiles.Count) ملف" -ForegroundColor Green
Write-Host "  JavaScript: $($jsFiles.Count) ملف" -ForegroundColor Green
Write-Host "  JSON: $($jsonFiles.Count) ملف" -ForegroundColor Green
Write-Host "  PHP: $($phpFiles.Count) ملف" -ForegroundColor Green
Write-Host "  Google Apps Script: $($gsFiles.Count) ملف" -ForegroundColor Green
Write-Host "  صور: $($imgFiles.Count) ملف" -ForegroundColor Green
Write-Host ""

# حساب الحجم الكلي
$allFiles = @()
$allFiles += $htmlFiles
$allFiles += $cssFiles
$allFiles += $jsFiles
$allFiles += $jsonFiles
$allFiles += $phpFiles
$allFiles += $imgFiles

$totalSize = 0
foreach ($file in $allFiles) {
    $totalSize += $file.Length
}

$totalSizeMB = [math]::Round($totalSize / 1MB, 2)
$totalFilesCount = $allFiles.Count

Write-Host "[2/5] الحجم الكلي..." -ForegroundColor Yellow
Write-Host "  إجمالي: $totalFilesCount ملف" -ForegroundColor Cyan
Write-Host "  الحجم: $totalSizeMB MB" -ForegroundColor Cyan
Write-Host ""

# تحديث version.json
Write-Host "[3/5] تحديث version.json..." -ForegroundColor Yellow

$versionData = @{
    version = $version
    timestamp = $timestamp
    lastUpdate = (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ")
    files = @{}
    totalFiles = $totalFilesCount
    totalSize = "$totalSizeMB MB"
}

# إضافة جميع الملفات
foreach ($file in $allFiles) {
    $versionData.files[$file.Name] = $version
}

$versionData | ConvertTo-Json -Depth 10 | Out-File -FilePath "version.json" -Encoding UTF8
Write-Host "  تم تحديث version.json" -ForegroundColor Green
Write-Host ""

# نسخة احتياطية
Write-Host "[4/5] نسخة احتياطية..." -ForegroundColor Yellow
$backupFolder = "backup\FULL_BACKUP_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
New-Item -ItemType Directory -Path $backupFolder -Force | Out-Null

$backedUpCount = 0
foreach ($file in $allFiles) {
    Copy-Item $file.FullName -Destination $backupFolder -Force
    $backedUpCount++
}

Write-Host "  تم نسخ $backedUpCount ملف" -ForegroundColor Green
Write-Host "  المسار: $backupFolder" -ForegroundColor Cyan
Write-Host ""

# إنشاء قائمة مفصلة
Write-Host "[5/5] انشاء قوائم التحقق..." -ForegroundColor Yellow

$uploadList = @"
========================================================
   قائمة رفع الملفات الشاملة v4.0.0
========================================================

التاريخ: $updateDate
الملفات: $totalFilesCount ملف
الحجم: $totalSizeMB MB

========================================================
المجموعة 1: ملفات حرجة - ارفعها أولاً
========================================================

"@

# إضافة الملفات الحرجة
$criticalFiles = @("version.json", "cache-busting.js", "enhanced-cache-busting.js")
foreach ($fileName in $criticalFiles) {
    $file = $allFiles | Where-Object { $_.Name -eq $fileName }
    if ($file) {
        $size = [math]::Round($file.Length / 1KB, 2)
        $uploadList += "  [ ] $fileName - $size KB`n"
    }
}

$uploadList += @"

========================================================
المجموعة 2: الملفات الأساسية
========================================================

"@

$coreFiles = @("dashboard.html", "script.js", "app-config.js", "style.css", "modern-theme.css", "professional-theme.css", "mobile-tables.css")
foreach ($fileName in $coreFiles) {
    $file = $allFiles | Where-Object { $_.Name -eq $fileName }
    if ($file) {
        $size = [math]::Round($file.Length / 1KB, 2)
        $uploadList += "  [ ] $fileName - $size KB`n"
    }
}

$uploadList += @"

========================================================
المجموعة 3: صفحات HTML
========================================================

"@

foreach ($file in $htmlFiles | Where-Object { $_.Name -notin $coreFiles } | Sort-Object Name) {
    $size = [math]::Round($file.Length / 1KB, 2)
    $uploadList += "  [ ] $($file.Name) - $size KB`n"
}

$uploadList += @"

========================================================
المجموعة 4: ملفات CSS
========================================================

"@

foreach ($file in $cssFiles | Where-Object { $_.Name -notin $coreFiles } | Sort-Object Name) {
    $size = [math]::Round($file.Length / 1KB, 2)
    $uploadList += "  [ ] $($file.Name) - $size KB`n"
}

$uploadList += @"

========================================================
المجموعة 5: ملفات JavaScript
========================================================

"@

foreach ($file in $jsFiles | Where-Object { $_.Name -notin $criticalFiles -and $_.Name -notin $coreFiles } | Sort-Object Name) {
    $size = [math]::Round($file.Length / 1KB, 2)
    $uploadList += "  [ ] $($file.Name) - $size KB`n"
}

$uploadList += @"

========================================================
المجموعة 6: ملفات JSON
========================================================

"@

foreach ($file in $jsonFiles | Where-Object { $_.Name -ne "version.json" } | Sort-Object Name) {
    $size = [math]::Round($file.Length / 1KB, 2)
    $uploadList += "  [ ] $($file.Name) - $size KB`n"
}

$uploadList += @"

========================================================
المجموعة 7: ملفات PHP
========================================================

"@

foreach ($file in $phpFiles | Sort-Object Name) {
    $size = [math]::Round($file.Length / 1KB, 2)
    $uploadList += "  [ ] $($file.Name) - $size KB`n"
}

$uploadList += @"

========================================================
المجموعة 8: الصور
========================================================

"@

foreach ($file in $imgFiles | Sort-Object Name) {
    $size = [math]::Round($file.Length / 1KB, 2)
    $uploadList += "  [ ] $($file.Name) - $size KB`n"
}

$uploadList += @"

========================================================
ملاحظة: ملفات Google Apps Script
========================================================

الملفات التالية لا ترفع على الاستضافة، بل على Google Apps Script:

"@

foreach ($file in $gsFiles | Sort-Object Name) {
    $size = [math]::Round($file.Length / 1KB, 2)
    $uploadList += "  - $($file.Name) - $size KB`n"
}

$uploadList += @"

========================================================
خطوات الرفع على Hostinger
========================================================

1. تسجيل الدخول:
   - اذهب الى: https://hpanel.hostinger.com/
   - سجل دخول بحسابك

2. فتح File Manager:
   - من لوحة التحكم > Files > File Manager
   - اذهب الى: public_html/

3. رفع الملفات بالترتيب:
   
   أ) المجموعة 1 (واحد واحد):
      - version.json أولاً
      - cache-busting.js
      - enhanced-cache-busting.js
      انتظر اكتمال كل ملف
   
   ب) المجموعة 2 (الملفات الأساسية):
      - script.js (ملف كبير)
      - dashboard.html (ملف كبير جداً)
      - ملفات CSS (يمكن رفعها معاً)
      - app-config.js
   
   ج) باقي المجموعات:
      - يمكن رفع 5-10 ملفات معاً
      - راقب شريط التقدم
      - اختر Overwrite للاستبدال

4. بعد الرفع:
   - امسح cache السيرفر من Hostinger
   - إذا تستخدم CloudFlare، امسح الـ cache
   - انتظر 1-2 دقيقة

5. الاختبار:
   - افتح الموقع في وضع Incognito
   - اضغط Ctrl+Shift+R
   - افتح Console (F12)
   - يجب رؤية النسخة 4.0.0

========================================================
نصائح مهمة
========================================================

DO:
  - ارفع version.json أولاً دائماً
  - راقب شريط التقدم
  - اختر Overwrite للاستبدال
  - امسح cache السيرفر بعد الرفع
  - اختبر في وضع Incognito

DON'T:
  - لا ترفع أكثر من 10 ملفات معاً
  - لا تغلق النافذة أثناء الرفع
  - لا تنسى مسح الـ cache
  - لا ترفع ملفات .md أو .ps1

========================================================

"@

$uploadList | Out-File -FilePath "COMPLETE-UPLOAD-CHECKLIST.txt" -Encoding UTF8

Write-Host "  تم إنشاء: COMPLETE-UPLOAD-CHECKLIST.txt" -ForegroundColor Green
Write-Host ""

# الملخص النهائي
Write-Host "=========================================================" -ForegroundColor Cyan
Write-Host "   جميع الملفات جاهزة للرفع" -ForegroundColor Green
Write-Host "=========================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "الملفات: $totalFilesCount ملف" -ForegroundColor White
Write-Host "الحجم: $totalSizeMB MB" -ForegroundColor White
Write-Host "النسخة الاحتياطية: $backupFolder" -ForegroundColor White
Write-Host ""
Write-Host "الملفات المنشأة:" -ForegroundColor Yellow
Write-Host "  - version.json (محدّث)" -ForegroundColor Green
Write-Host "  - COMPLETE-UPLOAD-CHECKLIST.txt (قائمة شاملة)" -ForegroundColor Green
Write-Host "  - $backupFolder (نسخة احتياطية)" -ForegroundColor Green
Write-Host ""

$choice = Read-Host "هل تريد فتح قائمة الرفع الآن؟ (Y/N)"
if ($choice -eq "Y" -or $choice -eq "y" -or $choice -eq "") {
    Start-Process "COMPLETE-UPLOAD-CHECKLIST.txt"
}

Write-Host ""
Write-Host "جاهز للرفع!" -ForegroundColor Green
Write-Host ""
