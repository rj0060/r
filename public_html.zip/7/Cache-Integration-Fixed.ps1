# PowerShell Script for Auto Cache Busting Integration
# Fixed encoding issues for Windows PowerShell

Write-Host "Starting Cache Busting Integration..." -ForegroundColor Green

# Template for regular pages
$regularTemplate = @"
    <!-- Cache Busting System -->
    <script src="cache-busting.js"></script>
    <script>
        // Initialize cache busting for regular pages
        const pageCacheBuster = new CacheBuster({
            checkInterval: 30000,
            showNotifications: true,
            autoRefresh: false,
            customMessage: 'Page updated - refresh available'
        });
        pageCacheBuster.start();
    </script>
"@

# Template for admin pages
$adminTemplate = @"
    <!-- Cache Busting System -->
    <script src="cache-busting.js"></script>
    <script>
        // Initialize cache busting for admin pages
        const adminCacheBuster = new CacheBuster({
            checkInterval: 10000,
            showNotifications: true,
            autoRefresh: true,
            customMessage: 'Admin system updated'
        });
        adminCacheBuster.start();
    </script>
"@

# Admin pages list
$adminPages = @(
    "admin.html",
    "superadmin.html", 
    "admin-register.html",
    "manage-family-members.html",
    "manage-members.html",
    "manage-aid.html",
    "manage-aid-new.html",
    "manage-special-cases.html",
    "user-requests-admin.html",
    "deaths-admin.html",
    "injuries-admin.html",
    "martyrs-admin.html",
    "aid-logs.html",
    "password-resets.html",
    "edit-requests.html"
)

# Already processed pages
$processedPages = @(
    "admin.html",
    "index.html", 
    "dashboard.html",
    "manage-family-members.html"
)

# Get all HTML files
$htmlFiles = Get-ChildItem -Path "." -Filter "*.html"

$processedCount = 0
$skippedCount = 0

foreach ($file in $htmlFiles) {
    $fileName = $file.Name
    $filePath = $file.FullName
    
    try {
        # Read file content
        $content = Get-Content -Path $filePath -Raw -Encoding UTF8
        
        # Check if already has cache-busting
        if ($content -like "*cache-busting.js*") {
            Write-Host "SKIP: $fileName - already has cache busting" -ForegroundColor Yellow
            $skippedCount++
            continue
        }
        
        # Check if already processed
        if ($processedPages -contains $fileName) {
            Write-Host "SKIP: $fileName - already processed manually" -ForegroundColor Yellow  
            $skippedCount++
            continue
        }
        
        # Determine template type
        if ($adminPages -contains $fileName) {
            $template = $adminTemplate
            Write-Host "PROCESSING: $fileName (admin page)..." -ForegroundColor Cyan
        } else {
            $template = $regularTemplate
            Write-Host "PROCESSING: $fileName (regular page)..." -ForegroundColor Cyan
        }
        
        # Check for body tag
        if ($content -like "*</body>*") {
            # Create backup
            $backupPath = $filePath + ".backup"
            Copy-Item -Path $filePath -Destination $backupPath -Force
            
            # Add template before closing body tag
            $newContent = $content -replace "</body>", "$template`n</body>"
            
            # Write new content
            $newContent | Set-Content -Path $filePath -Encoding UTF8
            
            Write-Host "SUCCESS: $fileName - cache busting added" -ForegroundColor Green
            $processedCount++
        } else {
            Write-Host "WARNING: $fileName - no closing body tag found" -ForegroundColor Red
        }
    }
    catch {
        Write-Host "ERROR: $fileName - $($_.Exception.Message)" -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Magenta
Write-Host "INTEGRATION COMPLETE!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Magenta
Write-Host "Total HTML files: $($htmlFiles.Count)" -ForegroundColor White
Write-Host "Files processed: $processedCount" -ForegroundColor Green
Write-Host "Files skipped: $skippedCount" -ForegroundColor Yellow
Write-Host "Backup files created: $processedCount" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Magenta
Write-Host "1. Upload all files to hosting" -ForegroundColor White  
Write-Host "2. Test the website to ensure cache busting works" -ForegroundColor White
Write-Host "3. Delete .backup files if everything works correctly" -ForegroundColor White
