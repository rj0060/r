# نظام رفع التحديث الآمن مع فحص شامل
# Safe Deployment System with Verification

# إعدادات الألوان
$host.UI.RawUI.BackgroundColor = "Black"
$host.UI.RawUI.ForegroundColor = "Green"
Clear-Host

Write-Host ""
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "   🚀 نظام رفع التحديث v3.0.0 - Deployment System" -ForegroundColor Yellow
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

# معلومات التحديث
$version = "3.0.0"
$updateDate = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

Write-Host "[معلومات التحديث]" -ForegroundColor Magenta
Write-Host "  الإصدار: v$version" -ForegroundColor White
Write-Host "  التاريخ: $updateDate" -ForegroundColor White
Write-Host ""

# قائمة الملفات المحدثة
$updatedFiles = @(
    "dashboard.html",
    "script.js", 
    "version.json",
    "cache-busting.js",
    "style.css",
    "modern-theme.css",
    "professional-theme.css",
    "mobile-tables.css"
)

Write-Host "[1/6] فحص الملفات المحدثة..." -ForegroundColor Yellow
Write-Host ""

$allFilesExist = $true
$totalSize = 0

foreach ($file in $updatedFiles) {
    if (Test-Path $file) {
        $fileInfo = Get-Item $file
        $size = [math]::Round($fileInfo.Length / 1KB, 2)
        $totalSize += $size
        $modified = $fileInfo.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss")
        Write-Host "  ✓ $file" -ForegroundColor Green -NoNewline
        Write-Host " ($size KB, آخر تعديل: $modified)" -ForegroundColor Gray
    } else {
        Write-Host "  ✗ $file - غير موجود!" -ForegroundColor Red
        $allFilesExist = $false
    }
}

Write-Host ""
Write-Host "  📦 إجمالي الحجم: $([math]::Round($totalSize, 2)) KB" -ForegroundColor Cyan
Write-Host ""

if (-not $allFilesExist) {
    Write-Host "⚠️  تحذير: بعض الملفات غير موجودة!" -ForegroundColor Red
    Write-Host ""
    pause
    exit
}

# فحص محتوى version.json
Write-Host "[2/6] التحقق من version.json..." -ForegroundColor Yellow

if (Test-Path "version.json") {
    $versionContent = Get-Content "version.json" -Raw | ConvertFrom-Json
    Write-Host "  ✓ رقم الإصدار: $($versionContent.version)" -ForegroundColor Green
    Write-Host "  ✓ آخر تحديث: $($versionContent.lastUpdate)" -ForegroundColor Green
    Write-Host "  ✓ عدد الملفات المسجلة: $($versionContent.files.PSObject.Properties.Count)" -ForegroundColor Green
} else {
    Write-Host "  ✗ version.json غير موجود!" -ForegroundColor Red
}
Write-Host ""

# فحص dashboard.html للميزات الجديدة
Write-Host "[3/6] فحص الميزات الجديدة في dashboard.html..." -ForegroundColor Yellow

$dashboardContent = Get-Content "dashboard.html" -Raw

$features = @{
    "نافذة الترحيب" = "welcomeModal"
    "دليل الاستخدام" = "userGuideModal"
    "نظام التبويبات" = "switchTab"
    "تحسين الأداء" = "GENDER_ICONS"
    "عرض الجوال" = "family-mobile-cards"
}

foreach ($feature in $features.GetEnumerator()) {
    if ($dashboardContent -match $feature.Value) {
        Write-Host "  ✓ $($feature.Key)" -ForegroundColor Green
    } else {
        Write-Host "  ✗ $($feature.Key) - غير موجود!" -ForegroundColor Red
    }
}
Write-Host ""

# فحص script.js
Write-Host "[4/6] فحص تحسينات الأداء في script.js..." -ForegroundColor Yellow

$scriptContent = Get-Content "script.js" -Raw

if ($scriptContent -match "GENDER_ICONS") {
    Write-Host "  ✓ Cache للأيقونات" -ForegroundColor Green
}
if ($scriptContent -match "for \(let i = 0") {
    Write-Host "  ✓ حلقات for محسّنة" -ForegroundColor Green
}
if ($scriptContent -match "\.push\(") {
    Write-Host "  ✓ استخدام Array.push()" -ForegroundColor Green
}
Write-Host ""

# إنشاء نسخة احتياطية
Write-Host "[5/6] إنشاء نسخة احتياطية..." -ForegroundColor Yellow

$backupFolder = "backup\backup_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
New-Item -ItemType Directory -Path $backupFolder -Force | Out-Null

foreach ($file in $updatedFiles) {
    if (Test-Path $file) {
        Copy-Item $file -Destination $backupFolder -Force
    }
}

if (Test-Path "$backupFolder\dashboard.html") {
    Write-Host "  ✓ تم إنشاء النسخة الاحتياطية: $backupFolder" -ForegroundColor Green
} else {
    Write-Host "  ✗ فشل إنشاء النسخة الاحتياطية!" -ForegroundColor Red
}
Write-Host ""

# إنشاء ملف checklist
Write-Host "[6/6] إنشاء قائمة التحقق..." -ForegroundColor Yellow

$checklist = @"
═══════════════════════════════════════════════════════════
   ✅ قائمة التحقق من التحديث v3.0.0
═══════════════════════════════════════════════════════════

📅 التاريخ: $updateDate
📦 الإصدار: v$version

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 خطوات الرفع على الاستضافة
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

الخطوة 1: الاستعداد
  □ تسجيل دخول إلى لوحة التحكم (cPanel/Plesk)
  □ فتح File Manager أو FTP
  □ الذهاب إلى مجلد الموقع (public_html)

الخطوة 2: رفع الملفات (الترتيب مهم جداً!)
  □ 1. رفع version.json أولاً
  □ 2. رفع cache-busting.js
  □ 3. رفع script.js
  □ 4. رفع dashboard.html
  □ 5. رفع جميع ملفات CSS:
       • style.css
       • modern-theme.css
       • professional-theme.css
       • mobile-tables.css

الخطوة 3: مسح الـ Cache
  □ مسح cache السيرفر من cPanel
  □ مسح CDN cache (CloudFlare/cPanel)
  □ الانتظار 1-2 دقيقة

الخطوة 4: الاختبار
  □ فتح الموقع في وضع Incognito/Private
  □ الضغط على Ctrl+Shift+R (Hard Refresh)
  □ فتح Developer Tools (F12)
  □ التحقق من Console - يجب رؤية:
      "🚀 تهيئة نظام Cache Busting"
  □ التحقق من Network - الملفات يجب أن تحتوي ?v=
  □ يجب ظهور النافذة الترحيبية تلقائياً
  □ التحقق من وجود زر ? (دليل الاستخدام)

الخطوة 5: التأكد من الميزات الجديدة
  □ النافذة الترحيبية تظهر عند الدخول
  □ زر دليل الاستخدام يعمل
  □ التبويبات الثلاثة تعمل (الرئيسية، العائلة، المساعدات)
  □ عرض أفراد العائلة سريع
  □ البطاقات تظهر بشكل جميل على الجوال

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 أوامر اختبار في Console
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// فحص الإصدار الحالي
fetch('version.json?t=' + Date.now())
  .then(r => r.json())
  .then(d => console.log('Version:', d.version));

// مسح localStorage وإعادة تحميل
localStorage.clear(); 
location.reload(true);

// فحص الملفات المحملة
performance.getEntriesByType('resource')
  .filter(r => r.name.includes('.js') || r.name.includes('.css'))
  .forEach(r => console.log(r.name));

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 معالجة المشاكل الشائعة
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

❌ المشكلة: المستخدمون يرون النسخة القديمة
✅ الحل:
   1. تأكد من رفع version.json أولاً
   2. امسح cache السيرفر من cPanel
   3. في CloudFlare: Purge Everything
   4. انتظر 2-3 دقائق
   5. النظام سيحدث تلقائياً كل 30 ثانية

❌ المشكلة: النافذة الترحيبية لا تظهر
✅ الحل:
   في Console اكتب:
   localStorage.removeItem('hasSeenWelcomeMessage');
   localStorage.removeItem('lastWelcomeMessageDate');
   location.reload();

❌ المشكلة: أخطاء JavaScript
✅ الحل:
   1. تأكد من رفع script.js كاملاً
   2. افحص Console للأخطاء
   3. تأكد من عدم وجود مشاكل في النقل

❌ المشكلة: CSS لا يظهر بشكل صحيح
✅ الحل:
   1. تأكد من رفع جميع ملفات CSS
   2. امسح cache المتصفح
   3. Hard Refresh (Ctrl+Shift+R)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 الميزات الجديدة في v3.0.0
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✨ نافذة ترحيبية تلقائية
   • تظهر للمستخدم عند الدخول
   • رسالة مهمة من مجلس العائلة
   • تذكير بتحديث البيانات
   • تظهر مرة واحدة يومياً

📚 دليل استخدام تفاعلي
   • 7 أقسام شاملة
   • شرح مفصل لكل ميزة
   • خطوات واضحة مع أرقام
   • تصميم جميل ومتجاوب

🚀 أداء محسّن (3-5x أسرع)
   • Cache للأيقونات والأصناف
   • حلقات for بدلاً من map()
   • معالجة واحدة للبيانات
   • DOM manipulation محسّن

📱 تحسينات الجوال
   • بطاقات جميلة متحركة
   • تصميم متجاوب كامل
   • أزرار كبيرة سهلة الضغط

🔄 نظام تبويبات جديد
   • الصفحة الرئيسية
   • أفراد العائلة
   • سجل المساعدات
   • انتقال سلس مع localStorage

💾 نظام Cache Busting قوي
   • تحديث تلقائي للمستخدمين
   • فحص كل 30 ثانية
   • إجبار تحميل النسخة الجديدة

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 ملاحظات مهمة
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚡ السرعة:
   • المستخدمون النشطون سيحدثون خلال 1-2 دقيقة
   • الذين يفتحون الموقع لاحقاً سيحصلون على v3.0.0 مباشرة
   • لا حاجة لإخبار المستخدمين بالتحديث

🔒 الأمان:
   • النسخة الاحتياطية موجودة في: $backupFolder
   • يمكن الرجوع للنسخة القديمة في أي وقت

📊 المراقبة:
   • راقب سجلات السيرفر للتحديثات
   • افحص Console في متصفحات مختلفة
   • تأكد من عدم وجود أخطاء JavaScript

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 جاهز للرفع! ✅
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

تم التحضير بنجاح. ابدأ برفع الملفات الآن!

"@

$checklist | Out-File -FilePath "DEPLOYMENT_CHECKLIST.txt" -Encoding UTF8

Write-Host "  ✓ تم إنشاء: DEPLOYMENT_CHECKLIST.txt" -ForegroundColor Green
Write-Host ""

# الملخص النهائي
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "   ✅ جاهز للرفع!" -ForegroundColor Green
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""
Write-Host "📁 الملفات الجاهزة: $($updatedFiles.Count) ملف" -ForegroundColor White
Write-Host "📦 الحجم الإجمالي: $([math]::Round($totalSize, 2)) KB" -ForegroundColor White
Write-Host "🔖 الإصدار: v$version" -ForegroundColor White
Write-Host "💾 النسخة الاحتياطية: $backupFolder" -ForegroundColor White
Write-Host ""
Write-Host "📋 افتح DEPLOYMENT_CHECKLIST.txt لقائمة التحقق الكاملة" -ForegroundColor Yellow
Write-Host ""
Write-Host "🚀 يمكنك الآن رفع الملفات على الاستضافة!" -ForegroundColor Green
Write-Host ""

# فتح الملفات
$choice = Read-Host "هل تريد فتح قائمة التحقق الآن؟ (Y/N)"
if ($choice -eq "Y" -or $choice -eq "y") {
    Start-Process "DEPLOYMENT_CHECKLIST.txt"
}

Write-Host ""
Write-Host "✨ حظاً موفقاً في الرفع!" -ForegroundColor Cyan
Write-Host ""
