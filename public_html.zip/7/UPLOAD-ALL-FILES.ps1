# ═══════════════════════════════════════════════════════════
#    🚀 نظام رفع جميع الملفات على الاستضافة v4.0.0
# ═══════════════════════════════════════════════════════════

$host.UI.RawUI.BackgroundColor = "Black"
$host.UI.RawUI.ForegroundColor = "Green"
Clear-Host

Write-Host ""
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "   نظام رفع وتحديث جميع الملفات v4.0.0" -ForegroundColor Yellow
Write-Host "   Complete Files Upload and Update System" -ForegroundColor Yellow
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

# تحديث رقم الإصدار
$version = "4.0.0"
$updateDate = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$timestamp = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()

Write-Host "[معلومات التحديث]" -ForegroundColor Magenta
Write-Host "  📅 التاريخ: $updateDate" -ForegroundColor White
Write-Host "  🔖 الإصدار: v$version" -ForegroundColor White
Write-Host ""

# ═══════════════════════════════════════════════════════════
# المرحلة 1: جمع جميع الملفات من المشروع
# ═══════════════════════════════════════════════════════════

Write-Host "[1/7] جمع قائمة جميع الملفات..." -ForegroundColor Yellow
Write-Host ""

# تصنيف الملفات حسب النوع
$htmlFiles = Get-ChildItem -Path . -Filter "*.html" -File | Where-Object { $_.Name -notlike "test-*" -and $_.Name -notlike "*mobile_update*" }
$cssFiles = Get-ChildItem -Path . -Filter "*.css" -File
$jsFiles = Get-ChildItem -Path . -Filter "*.js" -File
$jsonFiles = Get-ChildItem -Path . -Filter "*.json" -File
$phpFiles = Get-ChildItem -Path . -Filter "*.php" -File
$gsFiles = Get-ChildItem -Path . -Filter "*.gs" -File
$imgFiles = Get-ChildItem -Path . -Filter "*.webp" -File

Write-Host "  📄 ملفات HTML: $($htmlFiles.Count) ملف" -ForegroundColor Cyan
Write-Host "  🎨 ملفات CSS: $($cssFiles.Count) ملف" -ForegroundColor Cyan
Write-Host "  ⚡ ملفات JavaScript: $($jsFiles.Count) ملف" -ForegroundColor Cyan
Write-Host "  📋 ملفات JSON: $($jsonFiles.Count) ملف" -ForegroundColor Cyan
Write-Host "  🔧 ملفات PHP: $($phpFiles.Count) ملف" -ForegroundColor Cyan
Write-Host "  📜 ملفات Google Apps Script: $($gsFiles.Count) ملف" -ForegroundColor Cyan
Write-Host "  🖼️  ملفات الصور: $($imgFiles.Count) ملف" -ForegroundColor Cyan
Write-Host ""

# ═══════════════════════════════════════════════════════════
# المرحلة 2: فحص جميع الملفات
# ═══════════════════════════════════════════════════════════

Write-Host "[2/7] فحص جميع الملفات..." -ForegroundColor Yellow
Write-Host ""

$allFiles = @()
$allFiles += $htmlFiles
$allFiles += $cssFiles
$allFiles += $jsFiles
$allFiles += $jsonFiles
$allFiles += $phpFiles
$allFiles += $gsFiles
$allFiles += $imgFiles

$totalSize = 0
$filesList = @()

foreach ($file in $allFiles) {
    $size = [math]::Round($file.Length / 1KB, 2)
    $totalSize += $size
    $modified = $file.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss")
    
    $filesList += [PSCustomObject]@{
        Name = $file.Name
        Size = $size
        Modified = $modified
        Type = $file.Extension.TrimStart('.')
    }
    
    # عرض الملف مع لون حسب النوع
    $color = switch ($file.Extension) {
        ".html" { "Green" }
        ".css"  { "Cyan" }
        ".js"   { "Yellow" }
        ".json" { "Magenta" }
        ".php"  { "Blue" }
        ".gs"   { "DarkYellow" }
        ".webp" { "White" }
        default { "Gray" }
    }
    
    $sizeText = "($size KB)"
    Write-Host "  OK $($file.Name) $sizeText" -ForegroundColor $color
}

Write-Host ""
Write-Host "  📦 إجمالي الملفات: $($allFiles.Count) ملف" -ForegroundColor Green
Write-Host "  💾 إجمالي الحجم: $([math]::Round($totalSize, 2)) KB ($([math]::Round($totalSize/1024, 2)) MB)" -ForegroundColor Green
Write-Host ""

# ═══════════════════════════════════════════════════════════
# المرحلة 3: تحديث version.json
# ═══════════════════════════════════════════════════════════

Write-Host "[3/7] تحديث version.json..." -ForegroundColor Yellow
Write-Host ""

$versionData = @{
    version = $version
    timestamp = $timestamp
    lastUpdate = (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ")
    files = @{}
    features = @(
        "نظام رفع شامل لجميع الملفات",
        "تحديث تلقائي مع cache busting",
        "نافذة ترحيبية تفاعلية",
        "دليل استخدام شامل",
        "أداء محسّن للعرض",
        "تصميم متجاوب للجوال",
        "نظام تبويبات متقدم",
        "مراقبة النسخ التلقائية"
    )
    cachePolicy = @{
        css = "max-age=31536000"
        js = "max-age=31536000"
        html = "no-cache"
        json = "no-cache"
    }
    totalFiles = $allFiles.Count
    totalSize = "$([math]::Round($totalSize/1024, 2)) MB"
}

# إضافة جميع الملفات إلى version.json
foreach ($file in $filesList) {
    $versionData.files[$file.Name] = $version
}

# حفظ version.json
$versionData | ConvertTo-Json -Depth 10 | Out-File -FilePath "version.json" -Encoding UTF8

Write-Host "  ✓ تم تحديث version.json" -ForegroundColor Green
Write-Host "  ✓ تم تسجيل $($allFiles.Count) ملف" -ForegroundColor Green
Write-Host ""

# ═══════════════════════════════════════════════════════════
# المرحلة 4: إنشاء نسخة احتياطية شاملة
# ═══════════════════════════════════════════════════════════

Write-Host "[4/7] إنشاء نسخة احتياطية شاملة..." -ForegroundColor Yellow
Write-Host ""

$backupFolder = "backup\FULL_BACKUP_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
New-Item -ItemType Directory -Path $backupFolder -Force | Out-Null

$backedUpCount = 0
foreach ($file in $allFiles) {
    Copy-Item $file.FullName -Destination $backupFolder -Force
    $backedUpCount++
}

Write-Host "  ✓ تم نسخ $backedUpCount ملف" -ForegroundColor Green
Write-Host "  💾 المسار: $backupFolder" -ForegroundColor Cyan
Write-Host ""

# ═══════════════════════════════════════════════════════════
# المرحلة 5: إنشاء قائمة الرفع التفصيلية
# ═══════════════════════════════════════════════════════════

Write-Host "[5/7] إنشاء قائمة الرفع التفصيلية..." -ForegroundColor Yellow
Write-Host ""

# تصنيف الملفات حسب الأولوية
$criticalFiles = @("version.json", "cache-busting.js", "enhanced-cache-busting.js")
$coreFiles = @("dashboard.html", "script.js", "app-config.js", "style.css", "modern-theme.css", "professional-theme.css", "mobile-tables.css")
$adminFiles = $htmlFiles | Where-Object { $_.Name -like "*admin*" }
$formFiles = $htmlFiles | Where-Object { $_.Name -like "*requests*" -or $_.Name -like "*form*" }
$reportFiles = $htmlFiles | Where-Object { $_.Name -like "*report*" -or $_.Name -like "*aid*" }
$publicFiles = $htmlFiles | Where-Object { 
    $_.Name -notlike "*admin*" -and 
    $_.Name -notlike "*requests*" -and 
    $_.Name -notlike "*report*" -and 
    $_.Name -notlike "*form*" -and
    $_.Name -ne "dashboard.html" -and
    $_.Name -ne "index.html"
}

$uploadGuide = @"
═══════════════════════════════════════════════════════════
   📋 قائمة رفع الملفات الشاملة - Complete Upload List
═══════════════════════════════════════════════════════════

📅 التاريخ: $updateDate
🔖 الإصدار: v$version
📦 إجمالي الملفات: $($allFiles.Count) ملف
💾 الحجم الكلي: $([math]::Round($totalSize/1024, 2)) MB

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 🎯 المجموعة 1: ملفات حرجة (ارفعها أولاً!) - CRITICAL FILES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠️  هذه الملفات يجب أن ترفع أولاً وبالترتيب:

$(foreach ($fileName in $criticalFiles) {
    $file = $allFiles | Where-Object { $_.Name -eq $fileName }
    if ($file) {
        $size = [math]::Round($file.Length / 1KB, 2)
        "  □ $fileName ($size KB)"
    }
})

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 🎨 المجموعة 2: الملفات الأساسية - CORE FILES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

$(foreach ($fileName in $coreFiles) {
    $file = $allFiles | Where-Object { $_.Name -eq $fileName }
    if ($file) {
        $size = [math]::Round($file.Length / 1KB, 2)
        "  □ $fileName ($size KB)"
    }
})

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 🔐 المجموعة 3: صفحات الإدارة - ADMIN PAGES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

$(foreach ($file in $adminFiles) {
    $size = [math]::Round($file.Length / 1KB, 2)
    "  □ $($file.Name) ($size KB)"
})

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 📝 المجموعة 4: نماذج الطلبات - REQUEST FORMS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

$(foreach ($file in $formFiles) {
    $size = [math]::Round($file.Length / 1KB, 2)
    "  □ $($file.Name) ($size KB)"
})

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 📊 المجموعة 5: التقارير والمساعدات - REPORTS & AID
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

$(foreach ($file in $reportFiles) {
    $size = [math]::Round($file.Length / 1KB, 2)
    "  □ $($file.Name) ($size KB)"
})

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 👥 المجموعة 6: الصفحات العامة - PUBLIC PAGES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

$(foreach ($file in $publicFiles) {
    $size = [math]::Round($file.Length / 1KB, 2)
    "  □ $($file.Name) ($size KB)"
})

  □ index.html (صفحة الدخول الرئيسية)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 🎨 المجموعة 7: ملفات CSS - STYLESHEETS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

$(foreach ($file in $cssFiles) {
    $size = [math]::Round($file.Length / 1KB, 2)
    "  □ $($file.Name) ($size KB)"
})

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 ⚡ المجموعة 8: ملفات JavaScript - SCRIPTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

$(foreach ($file in $jsFiles) {
    $size = [math]::Round($file.Length / 1KB, 2)
    "  □ $($file.Name) ($size KB)"
})

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 📋 المجموعة 9: ملفات JSON - DATA FILES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

$(foreach ($file in $jsonFiles) {
    $size = [math]::Round($file.Length / 1KB, 2)
    "  □ $($file.Name) ($size KB)"
})

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 🔧 المجموعة 10: ملفات PHP - SERVER SCRIPTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

$(foreach ($file in $phpFiles) {
    $size = [math]::Round($file.Length / 1KB, 2)
    "  □ $($file.Name) ($size KB)"
})

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 📜 المجموعة 11: Google Apps Script Files
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠️  هذه الملفات لا ترفع على الاستضافة، بل على Google Apps Script:

$(foreach ($file in $gsFiles) {
    $size = [math]::Round($file.Length / 1KB, 2)
    "  □ $($file.Name) ($size KB)"
})

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 🖼️  المجموعة 12: الصور - IMAGES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

$(foreach ($file in $imgFiles) {
    $size = [math]::Round($file.Length / 1KB, 2)
    "  □ $($file.Name) ($size KB)"
})

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 📝 خطوات الرفع على Hostinger
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1️⃣  تسجيل الدخول:
   • اذهب إلى: https://hpanel.hostinger.com/
   • سجل دخول بحسابك

2️⃣  فتح File Manager:
   • من لوحة التحكم → Files → File Manager
   • اذهب إلى مجلد: public_html/

3️⃣  رفع الملفات بالترتيب:
   
   المرحلة 1: الملفات الحرجة (واحد واحد)
   • version.json أولاً
   • cache-busting.js
   • enhanced-cache-busting.js
   • انتظر اكتمال كل ملف قبل التالي

   المرحلة 2: الملفات الأساسية
   • script.js (ملف كبير، قد يأخذ وقت)
   • dashboard.html (ملف كبير جداً)
   • ملفات CSS (يمكن رفعها معاً)
   • app-config.js

   المرحلة 3: باقي الملفات
   • يمكن رفع 5-10 ملفات معاً
   • راقب شريط التقدم
   • اختر Overwrite عند السؤال

4️⃣  بعد الرفع:
   • امسح cache السيرفر من Hostinger
   • إذا كنت تستخدم CloudFlare، امسح الـ cache
   • انتظر 1-2 دقيقة

5️⃣  الاختبار:
   • افتح الموقع في وضع Incognito
   • اضغط Ctrl+Shift+R
   • افتح Console (F12) → يجب رؤية النسخة 4.0.0

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 ⚡ نصائح مهمة
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ ارفع version.json أولاً دائماً
✅ لا تغلق نافذة الرفع حتى يكتمل
✅ راقب شريط التقدم للملفات الكبيرة
✅ اختر Overwrite لاستبدال الملفات القديمة
✅ امسح cache السيرفر بعد الرفع
✅ اختبر في وضع Incognito

⚠️  تجنب:
❌ رفع ملفات كثيرة معاً (أكثر من 10)
❌ إغلاق النافذة أثناء الرفع
❌ نسيان مسح الـ cache
❌ رفع ملفات .md أو .txt أو .ps1 (ليست ضرورية)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 🔍 التحقق من نجاح الرفع
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

في Console المتصفح (F12):

// فحص الإصدار
fetch('version.json?t=' + Date.now())
  .then(r => r.json())
  .then(d => console.log('الإصدار الحالي:', d.version, '✅'));

// مسح الـ cache والتحديث
localStorage.clear();
location.reload(true);

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 📞 الدعم
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

إذا واجهت مشاكل:
1. راجع ملف HOSTINGER-UPLOAD-GUIDE.txt
2. تأكد من رفع version.json أولاً
3. امسح جميع أنواع الـ cache
4. جرب في متصفح آخر

✨ حظاً موفقاً في الرفع!

"@

$uploadGuide | Out-File -FilePath "COMPLETE-UPLOAD-LIST.txt" -Encoding UTF8

Write-Host "  ✓ تم إنشاء: COMPLETE-UPLOAD-LIST.txt" -ForegroundColor Green
Write-Host ""

# ═══════════════════════════════════════════════════════════
# المرحلة 6: إنشاء ملف FTP لرفع تلقائي (اختياري)
# ═══════════════════════════════════════════════════════════

Write-Host "[6/7] إنشاء سكربت FTP للرفع التلقائي..." -ForegroundColor Yellow
Write-Host ""

$ftpScript = @"
# ═══════════════════════════════════════════════════════════
#    FTP Upload Script - سكربت رفع تلقائي
# ═══════════════════════════════════════════════════════════

# معلومات الاتصال (عدّلها حسب بياناتك)
`$ftpServer = "ftp.yoursite.com"
`$ftpUsername = "your_ftp_username"
`$ftpPassword = "your_ftp_password"
`$remotePath = "/public_html/"

Write-Host "⚠️  تحذير: هذا السكربت يحتاج معلومات FTP صحيحة!" -ForegroundColor Red
Write-Host ""
Write-Host "لاستخدام هذا السكربت:" -ForegroundColor Yellow
Write-Host "1. عدّل معلومات FTP في أعلى الملف" -ForegroundColor White
Write-Host "2. احفظ الملف" -ForegroundColor White
Write-Host "3. شغّله بالأمر: .\FTP-AUTO-UPLOAD.ps1" -ForegroundColor White
Write-Host ""
Write-Host "أو استخدم FileZilla للرفع اليدوي (الأسهل والأأمن)" -ForegroundColor Green
Write-Host ""

# مثال على رفع ملف واحد
function Upload-FTPFile {
    param(
        [string]`$localFile,
        [string]`$remoteFile
    )
    
    try {
        `$webclient = New-Object System.Net.WebClient
        `$webclient.Credentials = New-Object System.Net.NetworkCredential(`$ftpUsername, `$ftpPassword)
        `$uri = New-Object System.Uri(`$ftpServer + `$remotePath + `$remoteFile)
        `$webclient.UploadFile(`$uri, `$localFile)
        Write-Host "  ✓ تم رفع: `$localFile" -ForegroundColor Green
    } catch {
        Write-Host "  ✗ فشل رفع: `$localFile" -ForegroundColor Red
        Write-Host "     الخطأ: `$_" -ForegroundColor Red
    }
}

# مثال للاستخدام (غير مفعّل):
# Upload-FTPFile "version.json" "version.json"
# Upload-FTPFile "dashboard.html" "dashboard.html"

"@

$ftpScript | Out-File -FilePath "FTP-AUTO-UPLOAD.ps1" -Encoding UTF8

Write-Host "  ✓ تم إنشاء: FTP-AUTO-UPLOAD.ps1" -ForegroundColor Green
Write-Host "  ℹ️  ملاحظة: يحتاج تعديل معلومات FTP قبل الاستخدام" -ForegroundColor Yellow
Write-Host ""

# ═══════════════════════════════════════════════════════════
# المرحلة 7: الملخص النهائي
# ═══════════════════════════════════════════════════════════

Write-Host "[7/7] الملخص النهائي..." -ForegroundColor Yellow
Write-Host ""

Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host "   ✅ جميع الملفات جاهزة للرفع!" -ForegroundColor Green
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""
Write-Host "📊 الإحصائيات:" -ForegroundColor Magenta
Write-Host "  📄 ملفات HTML: $($htmlFiles.Count)" -ForegroundColor White
Write-Host "  🎨 ملفات CSS: $($cssFiles.Count)" -ForegroundColor White
Write-Host "  ⚡ ملفات JS: $($jsFiles.Count)" -ForegroundColor White
Write-Host "  📋 ملفات JSON: $($jsonFiles.Count)" -ForegroundColor White
Write-Host "  🔧 ملفات PHP: $($phpFiles.Count)" -ForegroundColor White
Write-Host "  📜 ملفات GS: $($gsFiles.Count) (لا ترفع على الاستضافة)" -ForegroundColor White
Write-Host "  🖼️  صور: $($imgFiles.Count)" -ForegroundColor White
Write-Host ""
Write-Host "  📦 المجموع: $($allFiles.Count) ملف" -ForegroundColor Green
Write-Host "  💾 الحجم: $([math]::Round($totalSize/1024, 2)) MB" -ForegroundColor Green
Write-Host ""
Write-Host "📁 الملفات المنشأة:" -ForegroundColor Magenta
Write-Host "  ✓ version.json (محدّث)" -ForegroundColor Green
Write-Host "  ✓ COMPLETE-UPLOAD-LIST.txt (قائمة شاملة)" -ForegroundColor Green
Write-Host "  ✓ FTP-AUTO-UPLOAD.ps1 (سكربت اختياري)" -ForegroundColor Green
Write-Host "  ✓ $backupFolder (نسخة احتياطية)" -ForegroundColor Green
Write-Host ""
Write-Host "🚀 الخطوات التالية:" -ForegroundColor Yellow
Write-Host "  1. افتح ملف COMPLETE-UPLOAD-LIST.txt" -ForegroundColor White
Write-Host "  2. اتبع التعليمات خطوة بخطوة" -ForegroundColor White
Write-Host "  3. ارفع الملفات بالترتيب المحدد" -ForegroundColor White
Write-Host "  4. امسح cache السيرفر بعد الرفع" -ForegroundColor White
Write-Host "  5. اختبر الموقع" -ForegroundColor White
Write-Host ""

# سؤال المستخدم
$choice = Read-Host "هل تريد فتح قائمة الرفع الآن؟ (Y/N)"
if ($choice -eq "Y" -or $choice -eq "y") {
    Start-Process "COMPLETE-UPLOAD-LIST.txt"
}

Write-Host ""
Write-Host "✨ جميع الملفات جاهزة ومنظمة للرفع!" -ForegroundColor Cyan
Write-Host "📞 للدعم: راجع HOSTINGER-UPLOAD-GUIDE.txt" -ForegroundColor Cyan
Write-Host ""

# حفظ تقرير مفصل
$report = @"
تقرير رفع الملفات - Upload Report
═══════════════════════════════════════════════════════════

التاريخ: $updateDate
الإصدار: v$version
المشغل: $env:USERNAME
الجهاز: $env:COMPUTERNAME

الإحصائيات:
- إجمالي الملفات: $($allFiles.Count)
- الحجم الكلي: $([math]::Round($totalSize/1024, 2)) MB
- النسخة الاحتياطية: $backupFolder

التصنيف:
- HTML: $($htmlFiles.Count) ملف
- CSS: $($cssFiles.Count) ملف
- JavaScript: $($jsFiles.Count) ملف
- JSON: $($jsonFiles.Count) ملف
- PHP: $($phpFiles.Count) ملف
- Google Apps Script: $($gsFiles.Count) ملف
- صور: $($imgFiles.Count) ملف

الملفات المحدثة:
$(foreach ($file in $filesList | Sort-Object Type, Name) {
    "  - $($file.Name) ($($file.Size) KB) [$($file.Type)]"
})

الحالة: ✅ جاهز للرفع

"@

$report | Out-File -FilePath "UPLOAD-REPORT-$(Get-Date -Format 'yyyyMMdd_HHmmss').txt" -Encoding UTF8

Write-Host "💾 تم حفظ تقرير مفصل في مجلد المشروع" -ForegroundColor Green
Write-Host ""
