# PowerShell Script للتحديث الشامل - Windows
# Update-Cache.ps1

param(
    [string]$Path = ".",
    [switch]$Force
)

Write-Host "=== بدء عملية التحديث الشامل ===" -ForegroundColor Green

# الحصول على timestamp الحالي
$timestamp = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
$version = Get-Date -Format "yyyy.MM.dd.HH.mm"

Write-Host "الإصدار الجديد: $version" -ForegroundColor Yellow
Write-Host "Timestamp: $timestamp" -ForegroundColor Yellow

# تحديث ملف الإصدارات
Write-Host "تحديث ملف الإصدارات..." -ForegroundColor Cyan

$versionData = @{
    version = $version
    timestamp = $timestamp
    files = @{}
    lastUpdate = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
    cachePolicy = @{
        css = "max-age=31536000"
        js = "max-age=31536000"
        html = "no-cache"
    }
} | ConvertTo-Json -Depth 3

$versionData | Out-File -FilePath "version.json" -Encoding UTF8

# الحصول على جميع ملفات CSS و JS
Write-Host "فحص الملفات..." -ForegroundColor Cyan

$cssFiles = Get-ChildItem -Path $Path -Filter "*.css" -File
$jsFiles = Get-ChildItem -Path $Path -Filter "*.js" -File

foreach ($file in $cssFiles) {
    $fileTime = [DateTimeOffset]::FromFileTime($file.LastWriteTime.ToFileTime()).ToUnixTimeSeconds()
    Write-Host "  CSS: $($file.Name) -> إصدار $fileTime" -ForegroundColor Gray
}

foreach ($file in $jsFiles) {
    $fileTime = [DateTimeOffset]::FromFileTime($file.LastWriteTime.ToFileTime()).ToUnixTimeSeconds()
    Write-Host "  JS: $($file.Name) -> إصدار $fileTime" -ForegroundColor Gray
}

# دالة لتحديث ملف HTML
function Update-HtmlFile {
    param(
        [string]$FilePath,
        [string]$Timestamp
    )
    
    if (Test-Path $FilePath) {
        Write-Host "  معالجة: $FilePath" -ForegroundColor White
        
        # إنشاء نسخة احتياطية
        Copy-Item $FilePath "$FilePath.backup" -Force
        
        # قراءة المحتوى
        $content = Get-Content $FilePath -Raw -Encoding UTF8
        
        # استبدال CSS links (تجنب CDN)
        $content = $content -replace 'href="([^"]*\.css)"(?![^>]*(?:cdn|http))', "href=`"`$1?v=$Timestamp`""
        
        # استبدال JS scripts (تجنب CDN)
        $content = $content -replace 'src="([^"]*\.js)"(?![^>]*(?:cdn|http))', "src=`"`$1?v=$Timestamp`""
        
        # كتابة المحتوى المُحدث
        $content | Out-File $FilePath -Encoding UTF8 -NoNewline
        
        Write-Host "    ✓ تم تحديث $FilePath" -ForegroundColor Green
    }
}

# تحديث ملفات HTML في المجلد الرئيسي
Write-Host "تحديث ملفات HTML..." -ForegroundColor Cyan

$htmlFiles = Get-ChildItem -Path $Path -Filter "*.html" -File
foreach ($htmlFile in $htmlFiles) {
    Update-HtmlFile -FilePath $htmlFile.FullName -Timestamp $timestamp
}

# تحديث ملفات في مجلد hm
$hmPath = Join-Path $Path "hm"
if (Test-Path $hmPath) {
    Write-Host "تحديث ملفات مجلد hm..." -ForegroundColor Cyan
    
    $hmHtmlFiles = Get-ChildItem -Path $hmPath -Filter "*.html" -File
    foreach ($htmlFile in $hmHtmlFiles) {
        Update-HtmlFile -FilePath $htmlFile.FullName -Timestamp $timestamp
    }
}

# إنشاء .htaccess إذا لم يكن موجوداً
$htaccessPath = Join-Path $Path ".htaccess"
if (-not (Test-Path $htaccessPath)) {
    Write-Host "إنشاء ملف .htaccess..." -ForegroundColor Cyan
    
    $htaccessContent = @"
# Cache Management Rules
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType text/html "access plus 0 seconds"
    ExpiresByType text/css "access plus 1 year"
    ExpiresByType application/javascript "access plus 1 year"
</IfModule>

<IfModule mod_headers.c>
    <FilesMatch "\.(html|htm)$">
        Header set Cache-Control "no-cache, no-store, must-revalidate"
    </FilesMatch>
    <FilesMatch "\.(css|js)$">
        Header set Cache-Control "public, max-age=31536000"
    </FilesMatch>
</IfModule>
"@
    
    $htaccessContent | Out-File $htaccessPath -Encoding UTF8
}

# إنشاء سجل التحديثات
$logEntry = "$version - $timestamp - تحديث شامل"
$logEntry | Add-Content "update.log" -Encoding UTF8

Write-Host ""
Write-Host "=== تم إنهاء التحديث بنجاح ===" -ForegroundColor Green
Write-Host "الإصدار الجديد: $version" -ForegroundColor Yellow
Write-Host "جميع الملفات تم تحديثها مع versioning" -ForegroundColor White
Write-Host ""
Write-Host "لتطبيق التحديثات:" -ForegroundColor Cyan
Write-Host "1. ارفع الملفات على الاستضافة" -ForegroundColor White
Write-Host "2. المستخدمون سيحصلون على التحديثات تلقائياً" -ForegroundColor White
Write-Host "3. في حالة عدم ظهور التحديثات، استخدم Ctrl+F5" -ForegroundColor White
Write-Host ""

# إنشاء ملف تشغيل سريع
$batchContent = @"
@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0Update-Cache.ps1"
pause
"@

$batchContent | Out-File "تحديث-الملفات.bat" -Encoding UTF8

Write-Host "تم إنشاء ملف 'تحديث-الملفات.bat' للتشغيل السريع" -ForegroundColor Green
