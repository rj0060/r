/**
 * @file admin-activity-tracker.js
 * @description تتبع شامل لأنشطة المدراء في جميع الصفحات
 * @version 1.0
 */

(function() {
    'use strict';
    
    // التحقق من وجود AdminPermissions
    if (!window.AdminPermissions) {
        console.warn('AdminPermissions غير محمل - تتبع الأنشطة معطل');
        return;
    }
    
    const ActivityTracker = {
        /**
         * تتبع موافقة/رفض الطلبات في صفحات الإدارة
         */
        trackRequestActions() {
            // تتبع أزرار الموافقة
            document.addEventListener('click', async (e) => {
                const approveBtn = e.target.closest('[class*="approve"], [class*="accept"], [onclick*="approve"]');
                if (approveBtn) {
                    const requestId = approveBtn.dataset.requestId || approveBtn.dataset.id || 'غير محدد';
                    const requestType = this.getRequestTypeFromPage();
                    
                    // الانتظار قليلاً للحصول على السبب إذا كان هناك مودال
                    setTimeout(async () => {
                        const reason = document.querySelector('[id*="reason"], [id*="notes"]')?.value || 'لا يوجد';
                        await AdminPermissions.logApproval(requestType, requestId, reason);
                    }, 500);
                }
                
                // تتبع أزرار الرفض
                const rejectBtn = e.target.closest('[class*="reject"], [class*="deny"], [onclick*="reject"]');
                if (rejectBtn) {
                    const requestId = rejectBtn.dataset.requestId || rejectBtn.dataset.id || 'غير محدد';
                    const requestType = this.getRequestTypeFromPage();
                    
                    // الانتظار للحصول على سبب الرفض
                    setTimeout(async () => {
                        const reason = document.querySelector('[id*="reject"], [id*="reason"], [id*="notes"]')?.value || 'لا يوجد';
                        await AdminPermissions.logRejection(requestType, requestId, reason);
                    }, 500);
                }
            });
        },
        
        /**
         * الحصول على نوع الطلب من الصفحة الحالية
         */
        getRequestTypeFromPage() {
            const page = window.location.pathname.split('/').pop();
            const typeMap = {
                'edit-requests.html': 'طلب تعديل بيانات',
                'life-requests.html': 'طلب مولود',
                'password-resets.html': 'طلب إعادة تعيين كلمة مرور',
                'martyrs-admin.html': 'طلب شهيد',
                'deaths-admin.html': 'طلب وفاة',
                'manage-special-cases.html': 'حالة خاصة',
                'injuries-admin.html': 'طلب إصابة'
            };
            return typeMap[page] || 'طلب';
        },
        
        /**
         * تتبع إضافة السجلات
         */
        trackAddActions() {
            // تتبع نماذج الإضافة
            document.querySelectorAll('form[id*="add"], form[id*="create"]').forEach(form => {
                form.addEventListener('submit', async (e) => {
                    const formId = form.id;
                    const recordType = this.getRecordTypeFromForm(formId);
                    
                    setTimeout(async () => {
                        const recordId = this.extractRecordIdFromForm(form);
                        const details = this.extractFormDetails(form);
                        await AdminPermissions.logAddRecord(recordType, recordId, details);
                    }, 1000);
                });
            });
        },
        
        /**
         * تتبع تعديل السجلات
         */
        trackEditActions() {
            document.querySelectorAll('form[id*="edit"], form[id*="update"]').forEach(form => {
                form.addEventListener('submit', async (e) => {
                    const formId = form.id;
                    const recordType = this.getRecordTypeFromForm(formId);
                    
                    setTimeout(async () => {
                        const recordId = this.extractRecordIdFromForm(form);
                        const changes = this.extractFormChanges(form);
                        await AdminPermissions.logEditRecord(recordType, recordId, changes);
                    }, 1000);
                });
            });
        },
        
        /**
         * تتبع حذف السجلات
         */
        trackDeleteActions() {
            document.addEventListener('click', async (e) => {
                const deleteBtn = e.target.closest('[class*="delete"], [onclick*="delete"], [class*="remove"]');
                if (deleteBtn && deleteBtn.classList.contains('btn-danger')) {
                    const recordId = deleteBtn.dataset.id || deleteBtn.dataset.memberId || 'غير محدد';
                    const recordType = this.getRecordTypeFromPage();
                    
                    setTimeout(async () => {
                        const reason = 'حذف من لوحة التحكم';
                        await AdminPermissions.logDeleteRecord(recordType, recordId, reason);
                    }, 500);
                }
            });
        },
        
        /**
         * تتبع عرض التقارير
         */
        trackReportViews() {
            const reportForm = document.querySelector('form[id*="report"]');
            if (reportForm) {
                reportForm.addEventListener('submit', async (e) => {
                    setTimeout(async () => {
                        const reportType = document.getElementById('reportType')?.value || 'تقرير عام';
                        const filters = {
                            startDate: document.getElementById('startDate')?.value,
                            endDate: document.getElementById('endDate')?.value
                        };
                        await AdminPermissions.logViewReport(reportType, filters);
                    }, 500);
                });
            }
        },
        
        /**
         * استخراج نوع السجل من اسم النموذج
         */
        getRecordTypeFromForm(formId) {
            if (formId.includes('member')) return 'فرد';
            if (formId.includes('aid')) return 'مساعدة';
            if (formId.includes('martyr')) return 'شهيد';
            if (formId.includes('death')) return 'وفاة';
            if (formId.includes('birth')) return 'مولود';
            if (formId.includes('special')) return 'حالة خاصة';
            return 'سجل';
        },
        
        /**
         * استخراج نوع السجل من الصفحة
         */
        getRecordTypeFromPage() {
            const page = window.location.pathname.split('/').pop();
            if (page.includes('member')) return 'فرد';
            if (page.includes('aid')) return 'مساعدة';
            if (page.includes('martyr')) return 'شهيد';
            if (page.includes('death')) return 'وفاة';
            if (page.includes('birth')) return 'مولود';
            if (page.includes('special')) return 'حالة خاصة';
            return 'سجل';
        },
        
        /**
         * استخراج معرف السجل من النموذج
         */
        extractRecordIdFromForm(form) {
            const idField = form.querySelector('[id*="Id"], [id*="ID"], [name*="id"]');
            return idField?.value || 'جديد';
        },
        
        /**
         * استخراج تفاصيل من النموذج
         */
        extractFormDetails(form) {
            const nameField = form.querySelector('[id*="name"], [id*="Name"]');
            return nameField?.value || '';
        },
        
        /**
         * استخراج التغييرات من نموذج التعديل
         */
        extractFormChanges(form) {
            const changes = {};
            form.querySelectorAll('input, select, textarea').forEach(field => {
                if (field.name && field.value) {
                    changes[field.name] = field.value;
                }
            });
            return changes;
        },
        
        /**
         * تهيئة جميع أدوات التتبع
         */
        init() {
            this.trackRequestActions();
            this.trackAddActions();
            this.trackEditActions();
            this.trackDeleteActions();
            this.trackReportViews();
            
            console.log('✅ تم تفعيل تتبع الأنشطة الشامل');
        }
    };
    
    // تهيئة تلقائية عند تحميل الصفحة
    document.addEventListener('DOMContentLoaded', () => {
        // التحقق من أننا في صفحة أدمن
        const adminPages = ['admin.html', 'manage-members.html', 'manage-aid.html', 'aid-logs.html', 
                            'reports.html', 'password-resets.html', 'life-requests.html',
                            'martyrs-admin.html', 'deaths-admin.html', 'manage-special-cases.html', 
                            'edit-requests.html', 'fair-distribution.html'];
        
        const currentPage = window.location.pathname.split('/').pop();
        
        if (adminPages.includes(currentPage)) {
            // الانتظار قليلاً للتأكد من تحميل AdminPermissions
            setTimeout(() => {
                ActivityTracker.init();
            }, 1000);
        }
    });
    
    // تصدير للاستخدام العام
    window.ActivityTracker = ActivityTracker;
})();