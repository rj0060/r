/**
 * @file admin-permissions.js
 * @description نظام صلاحيات وتتبع أنشطة المدراء
 * @version 1.0
 */

const AdminPermissions = {
    permissions: null,
    isSuperAdmin: false,
    sessionId: null,
    
    // خريطة الصلاحيات للصفحات والأيقونات
    permissionMap: {
        'manage-members.html': 'إدارة الأفراد',
        'manage-aid.html': 'إدارة المساعدات',
        'manage-aid-new.html': 'إدارة المساعدات',
        'aid-logs.html': 'إدارة المساعدات',
        'reports.html': 'عرض التقارير',
        'martyrs-admin.html': 'إدارة الشهداء',
        'deaths-admin.html': 'إدارة الوفيات',
        'manage-special-cases.html': 'الحالات الخاصة',
        'life-requests.html': 'الحالات الخاصة',
        'password-resets.html': 'إعادة تعيين كلمات المرور',
        'edit-requests.html': 'إدارة الأفراد',
        'fair-distribution.html': 'إدارة المساعدات',
        'user-requests-admin.html': 'إدارة الأفراد', // Added for user requests
        'injuries-admin.html': 'الحالات الخاصة', // Added for injuries
        'superadmin.html': 'Q: إدارة المديرين' // Added for superadmin page access
    },
    
    // خريطة الأيقونات في لوحة التحكم
    cardPermissionMap: {
        'manage-members': 'إدارة الأفراد',
        'manage-aid': 'إدارة المساعدات',
        'manage-aid-new': 'إدارة المساعدات',
        'aid-logs': 'إدارة المساعدات',
        'reports': 'عرض التقارير',
        'martyrs-admin': 'إدارة الشهداء',
        'deaths-admin': 'إدارة الوفيات',
        'manage-special-cases': 'الحالات الخاصة',
        'life-requests': 'الحالات الخاصة',
        'password-resets': 'إعادة تعيين كلمات المرور',
        'edit-requests': 'إدارة الأفراد',
        'fair-distribution': 'إدارة المساعدات',
        'user-requests-admin': 'إدارة الأفراد', // Added for user requests
        'injuries-admin': 'الحالات الخاصة', // Added for injuries
        'superadmin': 'Q: إدارة المديرين' // Added for superadmin card/feature
    },
    
    /**
     * تهيئة نظام الصلاحيات
     */
    async init() {
        const token = sessionStorage.getItem('adminToken');
        if (!token) {
            console.warn('لا يوجد token للأدمن');
            return false;
        }
        
        // إنشاء معرف جلسة فريد
        this.sessionId = this.generateSessionId();
        sessionStorage.setItem('adminSessionId', this.sessionId);
        
        // حاول جلب الصلاحيات من sessionStorage أولاً
        const cachedPermissions = sessionStorage.getItem('adminPermissions');
        const cachedIsSuperAdmin = sessionStorage.getItem('isSuperAdmin');

        if (cachedPermissions && cachedIsSuperAdmin !== null) {
            try {
                this.permissions = JSON.parse(cachedPermissions);
                this.isSuperAdmin = (cachedIsSuperAdmin === 'true'); // Convert string to boolean
                console.log('✅ تم تحميل الصلاحيات من sessionStorage:', this.permissions, 'isSuperAdmin:', this.isSuperAdmin);
            } catch (e) {
                console.error('خطأ في تحليل الصلاحيات من sessionStorage:', e);
                // إذا فشل التحليل، امسح الكاش وحاول جلبها من الخادم
                sessionStorage.removeItem('adminPermissions');
                sessionStorage.removeItem('isSuperAdmin');
                await this.loadPermissions(token);
            }
        } else {
            // إذا لم تكن موجودة في sessionStorage، جلبها من الخادم
            await this.loadPermissions(token);
        }
        
        // تطبيق الصلاحيات على الصفحة الحالية
        this.applyPermissions();
        
        // تسجيل دخول الصفحة
        this.logPageView();
        
        // تتبع الأنشطة
        this.initActivityTracking();
        
        return true;
    },
    
    /**
     * توليد معرف جلسة فريد
     */
    generateSessionId() {
        return 'SESSION_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    },
    
    /**
     * جلب صلاحيات الأدمن من الخادم
     */
    async loadPermissions(token) {
        try {
            const result = await App.apiCall({
                action: 'getAdminPermissions',
                token: token
            }, false);
            
            if (result && result.success) {
                this.permissions = result.permissions;
                this.isSuperAdmin = result.isSuperAdmin || false; // Set based on backend response, default to false
                
                // حفظ في sessionStorage للوصول السريع
                sessionStorage.setItem('adminPermissions', JSON.stringify(this.permissions));
                sessionStorage.setItem('isSuperAdmin', this.isSuperAdmin);
                
                console.log('✅ تم تحميل صلاحيات الأدمن:', this.permissions);
                console.log('DEBUG: Full getAdminPermissions result:', result); // Added for debugging
                return true;
            } else {
                console.error('فشل في جلب الصلاحيات');
                return false;
            }
        } catch (error) {
            console.error('خطأ في جلب الصلاحيات:', error);
            return false;
        }
    },
    
    /**
     * التحقق من صلاحية معينة
     */
    hasPermission(permissionKey) {
        console.log(`DEBUG: Checking permission for key: "${permissionKey}"`);
        console.log(`DEBUG: isSuperAdmin: ${this.isSuperAdmin}`);
        console.log(`DEBUG: Permissions object:`, this.permissions);

        // السوبر أدمن لديه كل الصلاحيات
        if (this.isSuperAdmin) {
            console.log(`DEBUG: hasPermission: Super Admin, granting permission for "${permissionKey}"`);
            return true;
        }
        
        // التحقق من الصلاحية
        const has = this.permissions && this.permissions[permissionKey] === true;
        console.log(`DEBUG: hasPermission: Permissions object for "${permissionKey}":`, this.permissions ? this.permissions[permissionKey] : 'undefined');
        console.log(`DEBUG: hasPermission: Result for "${permissionKey}": ${has}`);
        return has;
    },

    /**
     * تطبيق الصلاحيات على الصفحة الحالية
     */
    applyPermissions() {
        const currentPage = window.location.pathname.split('/').pop();
        console.log(`DEBUG: applyPermissions: Applying permissions for current page: "${currentPage}"`);
        
        // التحقق من صلاحية الوصول للصفحة
        const requiredPermission = this.permissionMap[currentPage];
        console.log(`DEBUG: applyPermissions: Required permission for "${currentPage}": "${requiredPermission}"`);
        
        // إذا كانت الصفحة تتطلب صلاحية معينة، تحقق منها
        if (requiredPermission) {
            const hasRequiredPermission = this.hasPermission(requiredPermission);
            console.log(`DEBUG: applyPermissions: Has required permission for "${currentPage}": ${hasRequiredPermission}`);

            if (!hasRequiredPermission) {
                this.showAccessDenied();
                return;
            }
        } else {
            console.log(`DEBUG: applyPermissions: No specific permission required for page "${currentPage}".`);
        }
        
        // إخفاء/تعطيل الأيقونات في لوحة التحكم
        if (currentPage === 'admin.html') {
            this.applyDashboardPermissions();
        } else if (currentPage === 'superadmin.html') { // Apply dashboard permissions for superadmin page as well if it has cards
            this.applyDashboardPermissions();
        }
        
        // إخفاء/تمويه الإحصائيات
        this.applyStatisticsPermissions();
    },
    
    /**
     * تطبيق الصلاحيات على لوحة التحكم
     */
    applyDashboardPermissions() {
        document.querySelectorAll('.action-card').forEach(card => {
            const link = card.closest('a');
            if (!link) return;
            
            const href = link.getAttribute('href');
            const cardKey = Object.keys(this.cardPermissionMap).find(key => href && href.includes(key));
            
            if (cardKey) {
                const requiredPermission = this.cardPermissionMap[cardKey];
                
                if (!this.hasPermission(requiredPermission)) {
                    // إخفاء البطاقة أو تعطيلها
                    card.style.opacity = '0.5';
                    card.style.filter = 'grayscale(100%)';
                    card.style.pointerEvents = 'none';
                    
                    // إضافة علامة "غير مسموح"
                    const badge = card.querySelector('.action-badge span');
                    if (badge) {
                        badge.textContent = '🔒 غير مسموح';
                        badge.parentElement.style.background = '#dc3545';
                    }
                    
                    // منع النقر
                    link.addEventListener('click', (e) => {
                        e.preventDefault();
                        this.showPermissionDeniedToast();
                    });
                }
            }
        });
    },
    
    /**
     * تطبيق الصلاحيات على الإحصائيات
     */
    applyStatisticsPermissions() {
        if (!this.hasPermission('عرض الإحصائيات')) {
            // تمويه الأرقام في بطاقات الإحصائيات
            document.querySelectorAll('.stat-number, .stats-info h3, .branch-number').forEach(el => {
                el.style.filter = 'blur(8px)';
                el.style.userSelect = 'none';
                el.setAttribute('title', 'ليس لديك صلاحية عرض الإحصائيات');
            });
            
            // إضافة أيقونة قفل
            document.querySelectorAll('.stat-card-modern, .branch-card-modern').forEach(card => {
                const lockIcon = document.createElement('div');
                lockIcon.innerHTML = '<i class="bi bi-lock-fill" style="position:absolute;top:10px;right:10px;font-size:1.5rem;color:#dc3545;opacity:0.7;"></i>';
                card.style.position = 'relative';
                card.appendChild(lockIcon);
            });
        }
    },
    
    /**
     * عرض رسالة عدم السماح بالوصول
     */
    showAccessDenied() {
        document.body.innerHTML = `
            <div class="container mt-5">
                <div class="row justify-content-center">
                    <div class="col-md-6">
                        <div class="card border-danger">
                            <div class="card-header bg-danger text-white text-center">
                                <h3><i class="bi bi-shield-x me-2"></i>غير مسموح بالوصول</h3>
                            </div>
                            <div class="card-body text-center">
                                <i class="bi bi-lock-fill text-danger" style="font-size: 5rem;"></i>
                                <h4 class="mt-3">ليس لديك صلاحية الوصول لهذه الصفحة</h4>
                                <p class="text-muted">يرجى التواصل مع المدير الأعلى لمنحك الصلاحيات المطلوبة</p>
                                <a href="admin.html" class="btn btn-primary mt-3">
                                    <i class="bi bi-arrow-right me-2"></i>العودة للوحة التحكم
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    },
    
    /**
     * عرض رسالة toast عند محاولة الوصول لميزة غير مسموح بها
     */
    showPermissionDeniedToast() {
        if (typeof Toastify !== 'undefined') {
            Toastify({
                text: "🔒 ليس لديك صلاحية الوصول لهذه الميزة",
                duration: 3000,
                gravity: "top",
                position: "center",
                style: {
                    background: "linear-gradient(to right, #dc3545, #c82333)"
                }
            }).showToast();
        }
    },
    
    /**
     * تسجيل عرض الصفحة
     */
    async logPageView() {
        const currentPage = window.location.pathname.split('/').pop();
        await this.logActivity('page_view', `دخول صفحة: ${currentPage}`, currentPage);
    },
    
    /**
     * تسجيل نشاط الأدمن
     */
    async logActivity(activityType, description, page = null, additionalData = null) {
        try {
            const token = sessionStorage.getItem('adminToken');
            if (!token) return;
            
            const currentPage = page || window.location.pathname.split('/').pop();
            
            await App.apiCall({
                action: 'logAdminActivity',
                token: token,
                activityType: activityType,
                description: description,
                page: currentPage,
                ipAddress: await this.getClientIP(),
                userAgent: navigator.userAgent,
                sessionId: this.sessionId,
                additionalData: additionalData
            }, false);
            
            console.log('📝 تم تسجيل النشاط:', activityType, description);
        } catch (error) {
            console.error('خطأ في تسجيل النشاط:', error);
        }
    },
    
    /**
     * الحصول على عنوان IP للعميل (تقريبي)
     */
    async getClientIP() {
        try {
            const response = await fetch('https://api.ipify.org?format=json');
            const data = await response.json();
            return data.ip;
        } catch (error) {
            return 'غير متاح';
        }
    },
    
    /**
     * تهيئة تتبع الأنشطة التلقائي
     */
    initActivityTracking() {
        // تتبع النقرات على الروابط
        document.addEventListener('click', (e) => {
            const link = e.target.closest('a');
            if (link && link.href) {
                const href = link.getAttribute('href');
                if (href && !href.startsWith('#') && !href.startsWith('javascript:')) {
                    this.logActivity('navigation', `النقر على رابط: ${href}`);
                }
            }
            
            // تتبع النقرات على الأزرار المهمة
            const button = e.target.closest('button');
            if (button) {
                const buttonText = button.textContent.trim();
                const buttonClass = button.className;
                
                // تسجيل الأزرار المهمة فقط
                if (buttonClass.includes('btn-success') || 
                    buttonClass.includes('btn-danger') ||
                    buttonClass.includes('btn-warning') ||
                    buttonText.includes('موافقة') ||
                    buttonText.includes('رفض') ||
                    buttonText.includes('حذف') ||
                    buttonText.includes('إضافة')) {
                    this.logActivity('button_click', `النقر على زر: ${buttonText}`);
                }
            }
        });
        
        // تتبع قراءة الإشعارات
        const notificationIcon = document.getElementById('adminNotificationIcon');
        if (notificationIcon) {
            notificationIcon.addEventListener('click', () => {
                this.logActivity('view_notifications', 'فتح قائمة الإشعارات');
            });
        }
        
        // تتبع تحديث البيانات
        const refreshBtn = document.getElementById('refreshDataBtn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => {
                this.logActivity('refresh_data', 'تحديث بيانات لوحة التحكم');
            });
        }
    },
    
    /**
     * تسجيل موافقة على طلب
     */
    async logApproval(requestType, requestId, reason = '') {
        await this.logActivity(
            'approve_request',
            `موافقة على ${requestType}: ${requestId}`,
            null,
            { requestType, requestId, reason }
        );
    },
    
    /**
     * تسجيل رفض طلب
     */
    async logRejection(requestType, requestId, reason = '') {
        await this.logActivity(
            'reject_request',
            `رفض ${requestType}: ${requestId} - السبب: ${reason}`,
            null,
            { requestType, requestId, reason }
        );
    },
    
    /**
     * تسجيل قراءة إشعار
     */
    async logNotificationRead(notificationId, notificationType) {
        await this.logActivity(
            'read_notification',
            `قراءة إشعار: ${notificationType}`,
            null,
            { notificationId, notificationType }
        );
    },
    
    /**
     * تسجيل إضافة سجل
     */
    async logAddRecord(recordType, recordId, details = '') {
        await this.logActivity(
            'add_record',
            `إضافة ${recordType}: ${recordId} - ${details}`,
            null,
            { recordType, recordId, details }
        );
    },
    
    /**
     * تسجيل تعديل سجل
     */
    async logEditRecord(recordType, recordId, changes = {}) {
        await this.logActivity(
            'edit_record',
            `تعديل ${recordType}: ${recordId}`,
            null,
            { recordType, recordId, changes }
        );
    },
    
    /**
     * تسجيل حذف سجل
     */
    async logDeleteRecord(recordType, recordId, reason = '') {
        await this.logActivity(
            'delete_record',
            `حذف ${recordType}: ${recordId} - السبب: ${reason}`,
            null,
            { recordType, recordId, reason }
        );
    },
    
    /**
     * تسجيل عرض تقرير
     */
    async logViewReport(reportType, filters = {}) {
        await this.logActivity(
            'view_report',
            `عرض تقرير: ${reportType}`,
            null,
            { reportType, filters }
        );
    },
    
    /**
     * التحقق من الصلاحية قبل تنفيذ إجراء
     */
    checkPermissionOrDeny(permissionKey, actionName = 'هذا الإجراء') {
        if (!this.hasPermission(permissionKey)) {
            this.showPermissionDeniedToast();
            this.logActivity('permission_denied', `محاولة ${actionName} بدون صلاحية`);
            return false;
        }
        return true;
    }
};

// تهيئة تلقائية عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', async () => {
    // التحقق من وجود صفحة أدمن
    const adminPages = ['admin.html', 'manage-members.html', 'manage-aid.html', 'manage-aid-new.html', 'aid-logs.html', 
                        'reports.html', 'password-resets.html', 'superadmin.html', 'life-requests.html',
                        'martyrs-admin.html', 'deaths-admin.html', 'manage-special-cases.html', 
                        'edit-requests.html', 'fair-distribution.html', 'user-requests-admin.html', 'injuries-admin.html'];
    
    const currentPage = window.location.pathname.split('/').pop();
    
    if (adminPages.includes(currentPage)) {
        await AdminPermissions.init();
    }
});

// تصدير للاستخدام العام
window.AdminPermissions = AdminPermissions;
