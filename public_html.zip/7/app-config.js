// ملف إعداد موحد لرابط Google Apps Script
// عدّل القيمة أدناه فقط لتغيير الرابط في كل الموقع دون فتح بقية الملفات
// يمكن لاحقاً إضافة مفاتيح أخرى (بيئة اختبار / إنتاج)
window.APP_CONFIG = {
  WEB_APP_URL: 'https://script.google.com/macros/s/AKfycbwR4e1CfZes0NtI2VgawPPRTp6KhVgmO6hHua4oTnNEH1Zp6YTIGAOSbrsk34ucJHP4Ew/exec'
}