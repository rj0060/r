#!/bin/bash

# Auto Cache Busting Integration Script
# يضيف cache busting تلقائياً لكل ملفات HTML

echo "بدء إضافة Cache Busting لكل ملفات HTML..."

# Template للصفحات العادية
REGULAR_TEMPLATE='    <!-- Cache Busting System -->
    <script src="cache-busting.js"></script>
    <script>
        // Initialize cache busting for regular pages
        const pageCacheBuster = new CacheBuster({
            checkInterval: 30000,
            showNotifications: true,
            autoRefresh: false,
            customMessage: "تم تحديث الصفحة - تحديث متاح"
        });
        pageCacheBuster.start();
    </script>'

# Template للصفحات الإدارية
ADMIN_TEMPLATE='    <!-- Cache Busting System -->
    <script src="cache-busting.js"></script>
    <script>
        // Initialize cache busting for admin pages
        const adminCacheBuster = new CacheBuster({
            checkInterval: 10000,
            showNotifications: true,
            autoRefresh: true,
            customMessage: "تم تحديث النظام الإداري"
        });
        adminCacheBuster.start();
    </script>'

# قائمة الصفحات الإدارية
ADMIN_PAGES=(
    "admin.html"
    "superadmin.html"
    "admin-register.html"
    "manage-family-members.html"
    "manage-members.html"
    "manage-aid.html"
    "manage-aid-new.html"
    "manage-special-cases.html"
    "user-requests-admin.html"
    "deaths-admin.html"
    "injuries-admin.html"
    "martyrs-admin.html"
    "aid-logs.html"
    "password-resets.html"
    "edit-requests.html"
)

# قائمة الصفحات المعالجة بالفعل
PROCESSED_PAGES=(
    "admin.html"
    "index.html"
    "dashboard.html"
    "manage-family-members.html"
)

# معالجة كل ملفات HTML
for file in *.html; do
    if [[ -f "$file" ]]; then
        # تحقق إذا كان الملف يحتوي بالفعل على cache-busting
        if grep -q "cache-busting.js" "$file"; then
            echo "✓ $file - يحتوي بالفعل على cache busting"
            continue
        fi
        
        # تحقق إذا كان الملف في قائمة المعالجة
        if [[ " ${PROCESSED_PAGES[@]} " =~ " ${file} " ]]; then
            echo "✓ $file - معالج بالفعل"
            continue
        fi
        
        # تحديد نوع Template المطلوب
        if [[ " ${ADMIN_PAGES[@]} " =~ " ${file} " ]]; then
            TEMPLATE="$ADMIN_TEMPLATE"
            echo "🔧 معالجة $file (صفحة إدارية)..."
        else
            TEMPLATE="$REGULAR_TEMPLATE"
            echo "🔧 معالجة $file (صفحة عادية)..."
        fi
        
        # إضافة cache busting قبل </body>
        if grep -q "</body>" "$file"; then
            # إنشاء نسخة احتياطية
            cp "$file" "${file}.backup"
            
            # إضافة template قبل </body>
            sed -i "s|</body>|$TEMPLATE\n</body>|g" "$file"
            echo "✅ تم إضافة cache busting لـ $file"
        else
            echo "⚠️  $file - لا يحتوي على tag </body>"
        fi
    fi
done

echo ""
echo "🎉 انتهت معالجة كل ملفات HTML!"
echo "📝 تم إنشاء نسخ احتياطية بامتداد .backup"
echo ""
echo "الخطوة التالية:"
echo "1. ارفع كل الملفات للاستضافة"
echo "2. اختبر الموقع للتأكد من عمل cache busting"
echo "3. احذف ملفات .backup إذا كان كل شيء يعمل بشكل صحيح"
