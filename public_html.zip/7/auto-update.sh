#!/bin/bash
# Auto Update Script - سكريبت التحديث التلقائي
# يحدث version.json تلقائياً عند تشغيله

echo "🚀 بدء عملية التحديث التلقائي..."

# الحصول على timestamp حالي
TIMESTAMP=$(date +%s)000
CURRENT_DATE=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

# إنشاء version.json محدث
cat > version.json << EOF
{
  "version": "2.0.$(date +%s)",
  "timestamp": ${TIMESTAMP},
  "lastUpdate": "${CURRENT_DATE}",
  "files": {
    "style.css": "2.0.$(date +%s)",
    "modern-theme.css": "2.0.$(date +%s)", 
    "professional-theme.css": "2.0.$(date +%s)",
    "script.js": "2.0.$(date +%s)",
    "app-config.js": "2.0.$(date +%s)",
    "cache-busting.js": "2.0.$(date +%s)",
    "manage-family-members.html": "2.0.$(date +%s)"
  },
  "features": [
    "Advanced cache busting",
    "Auto-refresh on updates", 
    "Version monitoring",
    "Family member bulk approval",
    "Real-time updates"
  ],
  "cachePolicy": {
    "css": "max-age=31536000",
    "js": "max-age=31536000",
    "html": "no-cache"
  }
}
EOF

echo "✅ تم تحديث version.json بنجاح!"
echo "📅 آخر تحديث: ${CURRENT_DATE}"
echo "🔢 Timestamp: ${TIMESTAMP}"

# إضافة headers لملفات .htaccess
if [ ! -f ".htaccess" ]; then
    echo "📝 إنشاء ملف .htaccess..."
    cat > .htaccess << 'EOF'
# Cache Busting & Performance Headers
<IfModule mod_headers.c>
    # CSS و JS - تخزين طويل مع إعدادات cache busting
    <FilesMatch "\.(css|js)$">
        Header set Cache-Control "public, max-age=31536000, immutable"
        Header set Vary "Accept-Encoding"
    </FilesMatch>
    
    # HTML - عدم تخزين مؤقت
    <FilesMatch "\.(html|htm)$">
        Header set Cache-Control "no-cache, no-store, must-revalidate"
        Header set Pragma "no-cache"
        Header set Expires "0"
    </FilesMatch>
    
    # JSON - لا تخزين مؤقت
    <FilesMatch "\.json$">
        Header set Cache-Control "no-cache, no-store, must-revalidate"
        Header set Content-Type "application/json; charset=utf-8"
    </FilesMatch>
    
    # تمكين ضغط GZIP
    <FilesMatch "\.(js|css|html|json)$">
        Header set Content-Encoding gzip
    </FilesMatch>
</IfModule>

# منع تخزين version.json
<Files "version.json">
    Header set Cache-Control "no-cache, no-store, must-revalidate"
    Header set Pragma "no-cache"
    Header set Expires "0"
</Files>

# Security Headers
<IfModule mod_headers.c>
    Header always set X-Content-Type-Options nosniff
    Header always set X-Frame-Options DENY
    Header always set X-XSS-Protection "1; mode=block"
</IfModule>
EOF
    echo "✅ تم إنشاء ملف .htaccess بنجاح!"
fi

echo ""
echo "🎉 تم الانتهاء من التحديث!"
echo "🌐 الآن جميع المستخدمين سيحصلون على آخر إصدار تلقائياً"
echo ""
echo "للاستخدام المستقبلي:"
echo "- قم بتشغيل هذا السكريبت بعد كل تحديث"
echo "- أو استخدم الأمر التلقائي في PowerShell"
