/**
 * Advanced Cache Busting Script - نظام متقدم لحل مشكلة التخزين المؤقت
 * يتحقق من الإصدارات ويفرض التحديث التلقائي
 */

class CacheBuster {
    constructor() {
        this.currentVersion = null;
        this.versionCheckInterval = 30000; // فحص كل 30 ثانية
        this.init();
    }

    async init() {
        console.log('🚀 تهيئة نظام Cache Busting المتقدم...');
        
        // إضافة timestamp فوري للملفات
        this.addCacheBusting();
        
        // التحقق من الإصدار الحالي
        await this.checkVersion();
        
        // بدء المراقبة التلقائية
        this.startVersionMonitoring();
        
        // إضافة مستمع لتحديث الصفحة
        this.addVisibilityChangeListener();
    }

    addCacheBusting() {
        const version = new Date().getTime();
        
        // معالجة ملفات CSS
        const cssLinks = document.querySelectorAll('link[rel="stylesheet"][href*=".css"]:not([href*="http"]):not([href*="cdn"])');
        cssLinks.forEach(link => {
            const href = link.getAttribute('href');
            if (!href.includes('?v=')) {
                link.setAttribute('href', `${href}?v=${version}`);
                console.log(`📄 CSS updated: ${href}`);
            }
        });
        
        // معالجة ملفات JavaScript المحلية
        const jsScripts = document.querySelectorAll('script[src*=".js"]:not([src*="http"]):not([src*="cdn"])');
        jsScripts.forEach(script => {
            const src = script.getAttribute('src');
            if (!src.includes('?v=')) {
                script.setAttribute('src', `${src}?v=${version}`);
                console.log(`📄 JS updated: ${src}`);
            }
        });

        window.APP_VERSION = version;
        console.log('✅ Cache Busting applied - Version:', version);
    }

    async checkVersion() {
        try {
            const response = await fetch('version.json?' + new Date().getTime());
            const versionData = await response.json();
            
            if (this.currentVersion && this.currentVersion !== versionData.timestamp) {
                console.log('🔄 إصدار جديد متوفر! يتم التحديث...');
                this.showUpdateNotification();
                setTimeout(() => this.forceReload(), 2000);
            }
            
            this.currentVersion = versionData.timestamp;
            console.log('📋 الإصدار الحالي:', versionData.version, 'Timestamp:', versionData.timestamp);
            
        } catch (error) {
            console.warn('⚠️ فشل في التحقق من الإصدار:', error);
        }
    }

    startVersionMonitoring() {
        setInterval(() => {
            this.checkVersion();
        }, this.versionCheckInterval);
        
        console.log(`🕒 بدء مراقبة الإصدارات كل ${this.versionCheckInterval / 1000} ثانية`);
    }

    addVisibilityChangeListener() {
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) {
                console.log('👁️ الصفحة أصبحت مرئية، فحص التحديثات...');
                this.checkVersion();
            }
        });
    }

    showUpdateNotification() {
        // إنشاء إشعار تحديث جميل
        const notification = document.createElement('div');
        notification.innerHTML = `
            <div style="
                position: fixed;
                top: 20px;
                right: 20px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 15px 25px;
                border-radius: 15px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                z-index: 10000;
                font-family: 'Cairo', sans-serif;
                font-size: 14px;
                min-width: 300px;
                animation: slideIn 0.5s ease-out;
            ">
                <div style="display: flex; align-items: center; gap: 10px;">
                    <i style="font-size: 1.2rem;">🔄</i>
                    <div>
                        <strong>تحديث جديد متوفر!</strong><br>
                        <small>يتم تحديث الصفحة تلقائياً...</small>
                    </div>
                </div>
            </div>
            <style>
                @keyframes slideIn {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
            </style>
        `;
        
        document.body.appendChild(notification);
        
        // إزالة الإشعار بعد 3 ثواني
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 3000);
    }

    forceReload() {
        console.log('🔄 إعادة تحميل الصفحة...');
        window.location.reload(true);
    }

    // دالة لفرض تحديث فوري
    static forceUpdate() {
        window.location.reload(true);
    }
}

// تهيئة النظام عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    window.cacheBuster = new CacheBuster();
});

// إضافة دالة عامة للتحديث الفوري
window.forceUpdate = () => CacheBuster.forceUpdate();

console.log('📦 Advanced Cache Busting System Loaded');
