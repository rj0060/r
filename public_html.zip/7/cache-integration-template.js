/**
 * Template لإضافة Cache Busting لكل الصفحات
 * استخدم هذا Template في نهاية كل ملف HTML
 */

// Template للصفحات العادية
const regularPageTemplate = `
<!-- Cache Busting System -->
<script src="cache-busting.js"></script>
<script>
    // Initialize cache busting for regular pages
    const pageCacheBuster = new CacheBuster({
        checkInterval: 30000, // Check every 30 seconds
        showNotifications: true,
        autoRefresh: false, // Let users choose to refresh
        customMessage: 'تم تحديث الصفحة - تحديث متاح'
    });
    pageCacheBuster.start();
</script>
`;

// Template للصفحات الإدارية
const adminPageTemplate = `
<!-- Cache Busting System -->
<script src="cache-busting.js"></script>
<script>
    // Initialize cache busting for admin pages
    const adminCacheBuster = new CacheBuster({
        checkInterval: 10000, // Check every 10 seconds for faster admin updates
        showNotifications: true,
        autoRefresh: true, // Auto refresh for admins
        customMessage: 'تم تحديث النظام الإداري'
    });
    adminCacheBuster.start();
</script>
`;

// Template للصفحات الحيوية (مثل التقارير والبيانات)
const criticalPageTemplate = `
<!-- Cache Busting System -->
<script src="cache-busting.js"></script>
<script>
    // Initialize cache busting for critical pages
    const criticalCacheBuster = new CacheBuster({
        checkInterval: 15000, // Check every 15 seconds
        showNotifications: true,
        autoRefresh: false,
        customMessage: 'تم تحديث البيانات'
    });
    criticalCacheBuster.start();
</script>
`;

/**
 * Instructions for Integration:
 * 1. أضف أحد Templates أعلاه قبل </body> في كل ملف HTML
 * 2. اختر Template المناسب حسب نوع الصفحة:
 *    - regularPageTemplate: للصفحات العادية
 *    - adminPageTemplate: للصفحات الإدارية
 *    - criticalPageTemplate: للصفحات الحيوية
 * 3. تأكد من وجود cache-busting.js في نفس المجلد
 */
