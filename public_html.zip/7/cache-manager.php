<?php
/**
 * Auto Version Manager - مدير الإصدارات التلقائي
 * يضيف timestamps تلقائياً للملفات عند التحديث
 */

class CacheManager {
    private $versionFile = 'version.json';
    private $staticFiles = ['css', 'js'];
    
    public function __construct() {
        $this->updateVersions();
    }
    
    /**
     * تحديث إصدارات الملفات
     */
    public function updateVersions() {
        $version = time(); // استخدام timestamp كإصدار
        
        $versionData = [
            'version' => date('Y.m.d.H.i'),
            'timestamp' => $version,
            'files' => $this->scanFiles(),
            'lastUpdate' => date('c')
        ];
        
        file_put_contents($this->versionFile, json_encode($versionData, JSON_PRETTY_PRINT));
    }
    
    /**
     * فحص الملفات وإرجاع قائمة بها
     */
    private function scanFiles() {
        $files = [];
        
        foreach ($this->staticFiles as $ext) {
            $pattern = "*.{$ext}";
            $fileList = glob($pattern);
            
            foreach ($fileList as $file) {
                $files[$file] = filemtime($file);
            }
        }
        
        return $files;
    }
    
    /**
     * الحصول على إصدار ملف محدد
     */
    public function getFileVersion($filename) {
        if (!file_exists($this->versionFile)) {
            return time();
        }
        
        $data = json_decode(file_get_contents($this->versionFile), true);
        return isset($data['files'][$filename]) ? $data['files'][$filename] : time();
    }
    
    /**
     * إنشاء رابط مع إصدار
     */
    public function asset($filename) {
        $version = $this->getFileVersion($filename);
        return $filename . '?v=' . $version;
    }
}

// إنشاء مثيل من المدير
$cacheManager = new CacheManager();

/**
 * دالة مساعدة لاستخدامها في HTML
 */
function asset($filename) {
    global $cacheManager;
    return $cacheManager->asset($filename);
}

// تحديث الإصدارات عند كل طلب (يمكن تحسينه)
if (isset($_GET['update_cache'])) {
    $cacheManager->updateVersions();
    echo json_encode(['status' => 'success', 'message' => 'Cache updated successfully']);
    exit;
}
?>
