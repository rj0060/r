/**
 * ملف تعريف مخطط البيانات الموحد
 * يضمن التوافق بين الخادم (Google Apps Script) والموقع وجدول البيانات
 * 
 * @version 1.0
 * @author نظام إدارة المساعدات العائلية
 */

window.DATA_SCHEMA = {
    // أسماء الشيتات في Google Sheets
    SHEETS: {
        INDIVIDUALS: 'الأفراد',
        AID_RECORDS: 'المساعدات',
        ADMINS: 'المدراء',
        INDIVIDUALS_LOGIN_LOG: 'سجل دخول الأفراد',
        ADMINS_LOGIN_LOG: 'سجل دخول المدراء',
        ADMIN_ACTIONS_LOG: 'سجل عمليات المدراء',
        PASSWORD_RESET_REQUESTS: 'طلبات إعادة تعيين',
        SPECIAL_CASES: 'حالات خاصة',
        BIRTHS: 'مواليد اطفال',
        CHILDREN_CLOTHES: 'بنزط اطفال',
        MARTYRS: 'الشهداء',
        DEATHS: 'الوفيات',
        EDIT_REQUESTS: 'طلبات تعديل البيانات',
        NOTIFICATIONS: 'الإشعارات'
    },

    // أسماء الحقول المعيارية للأفراد
    INDIVIDUAL_FIELDS: {
        // الحقول الأساسية
        FULL_NAME: 'الاسم الكامل',
        ID_NUMBER: 'رقم الهوية',
        PHONE_NUMBER: 'رقم الجوال',
        RESIDENCE: 'مكان الإقامة',
        BRANCH: 'الفرع',
        STATUS: 'الحالة',
        
        // حقول الزوجة
        SPOUSE_ID: 'رقم هوية الزوجة',
        SPOUSE_NAME: 'اسم الزوجة الكامل',
        
        // حقول النظام
        REGISTRATION_DATE: 'تاريخ التسجيل',
        PASSWORD_SET: 'تم تعيين كلمة المرور',
        LAST_LOGIN: 'آخر دخول',
        CREATED_BY: 'أنشئ بواسطة',
        LAST_MODIFIED: 'آخر تعديل',
        MODIFIED_BY: 'عُدل بواسطة'
    },

    // القيم المعيارية للحالات
    STATUS_VALUES: {
        ACTIVE: 'نشط',
        INACTIVE: 'غير نشط'
    },

    // القيم المعيارية للفروع
    BRANCH_VALUES: [
        'ال احمد',
        'ال حامد', 
        'ال حمدان',
        'ال حماد'
    ],

    // أسماء الحقول للمساعدات
    AID_FIELDS: {
        AID_ID: 'معرف المساعدة',
        RECIPIENT_ID: 'رقم هوية المستفيد',
        RECIPIENT_NAME: 'اسم المستفيد',
        AID_TYPE: 'نوع المساعدة',
        AID_AMOUNT: 'مبلغ المساعدة',
        AID_DATE: 'تاريخ المساعدة',
        NOTES: 'ملاحظات',
        CREATED_BY: 'أنشئ بواسطة',
        CREATION_DATE: 'تاريخ الإنشاء'
    },

    // أنواع المساعدات المتاحة
    AID_TYPES: [
        'مساعدة مالية',
        'مساعدة عينية',
        'كسوة أطفال',
        'مساعدة طبية',
        'مساعدة تعليمية',
        'أخرى'
    ],

    // إعدادات API
    API: {
        ACTIONS: {
            // أعمال الأفراد
            GET_ALL_MEMBERS: 'getAllMembers',
            GET_USER_DATA: 'getUserData',
            UPDATE_MEMBER: 'updateMember',
            ADD_MEMBER: 'addMember',
            DELETE_MEMBER: 'deleteMember',
            
            // أعمال المساعدات
            GET_USER_AID_HISTORY: 'getUserAidHistory',
            GET_ALL_AID_RECORDS: 'getAllAidRecords',
            ADD_AID_RECORD: 'addAidRecord',
            
            // أعمال المدراء
            ADMIN_LOGIN: 'adminLogin',
            
            // أعمال المصادقة
            CHECK_PASSWORD_STATUS: 'checkPasswordStatus',
            USER_LOGIN_WITH_PASSWORD: 'userLoginWithPassword',
            SET_MEMBER_PASSWORD: 'setMemberPassword'
        },
        
        // حدود الـ API
        LIMITS: {
            MAX_PAGE_SIZE: 50,
            DEFAULT_PAGE_SIZE: 10,
            MAX_SEARCH_LENGTH: 100
        }
    },

    // دوال مساعدة للتحقق من صحة البيانات
    VALIDATORS: {
        /**
         * التحقق من صحة رقم الهوية الفلسطيني
         * @param {string} id - رقم الهوية
         * @returns {boolean}
         */
        isValidPalestinianID: function(id) {
            if (!id || typeof id !== 'string') return false;
            const cleanId = id.trim();
            return /^\d{9}$/.test(cleanId);
        },

        /**
         * التحقق من صحة رقم الجوال
         * @param {string} phone - رقم الجوال
         * @returns {boolean}
         */
        isValidPhoneNumber: function(phone) {
            if (!phone || typeof phone !== 'string') return false;
            const cleanPhone = phone.trim().replace(/[\s\-\(\)]/g, '');
            return /^(05\d{8}|972\d{9}|\+972\d{9})$/.test(cleanPhone);
        },

        /**
         * التحقق من صحة الحالة
         * @param {string} status - الحالة
         * @returns {boolean}
         */
        isValidStatus: function(status) {
            return Object.values(this.STATUS_VALUES).includes(status);
        },

        /**
         * التحقق من صحة الفرع
         * @param {string} branch - الفرع
         * @returns {boolean}
         */
        isValidBranch: function(branch) {
            return this.BRANCH_VALUES.includes(branch);
        }
    },

    // دوال تحويل البيانات لضمان التوافق
    CONVERTERS: {
        /**
         * تحويل كائن العضو للصيغة المعيارية
         * @param {Object} member - بيانات العضو
         * @returns {Object}
         */
        normalizeMember: function(member) {
            if (!member || typeof member !== 'object') return null;

            const schema = window.DATA_SCHEMA.INDIVIDUAL_FIELDS;
            
            return {
                [schema.FULL_NAME]: member[schema.FULL_NAME] || member.fullName || '',
                [schema.ID_NUMBER]: member[schema.ID_NUMBER] || member.idNumber || '',
                [schema.PHONE_NUMBER]: member[schema.PHONE_NUMBER] || member.phoneNumber || '',
                [schema.RESIDENCE]: member[schema.RESIDENCE] || member.residence || '',
                [schema.BRANCH]: member[schema.BRANCH] || member.branch || 'ال احمد',
                [schema.STATUS]: member[schema.STATUS] || member.status || 'نشط',
                [schema.SPOUSE_ID]: member[schema.SPOUSE_ID] || member.spouseId || '',
                [schema.SPOUSE_NAME]: member[schema.SPOUSE_NAME] || member.spouseName || '',
                [schema.REGISTRATION_DATE]: member[schema.REGISTRATION_DATE] || member.registrationDate || new Date().toISOString(),
                [schema.PASSWORD_SET]: member[schema.PASSWORD_SET] || member.passwordSet || 'لا',
                [schema.LAST_LOGIN]: member[schema.LAST_LOGIN] || member.lastLogin || '',
                [schema.CREATED_BY]: member[schema.CREATED_BY] || member.createdBy || '',
                [schema.LAST_MODIFIED]: member[schema.LAST_MODIFIED] || member.lastModified || '',
                [schema.MODIFIED_BY]: member[schema.MODIFIED_BY] || member.modifiedBy || ''
            };
        },

        /**
         * إنشاء معرف فريد للعائلة
         * @param {Object} member - بيانات العضو
         * @returns {string}
         */
        generateFamilyId: function(member) {
            const schema = window.DATA_SCHEMA.INDIVIDUAL_FIELDS;
            
            let idNumber = member[schema.ID_NUMBER] || member.idNumber || '';
            const fullName = member[schema.FULL_NAME] || member.fullName || '';
            const branch = member[schema.BRANCH] || member.branch || '';
            const residence = member[schema.RESIDENCE] || member.residence || '';
            
            // تحويل رقم الهوية إلى نص إذا لزم الأمر
            if (idNumber && typeof idNumber !== 'string') {
                idNumber = idNumber.toString();
            }
            
            // إنشاء معرف العائلة
            if (idNumber && idNumber.length >= 8) {
                const familyIdPrefix = idNumber.substring(0, 8);
                return `${familyIdPrefix}_${branch}_${residence}`;
            } else if (fullName) {
                return `${fullName}_${branch}_${residence}`;
            } else {
                return `unknown_${branch}_${residence}_${Date.now()}`;
            }
        }
    }
};

// تصدير للاستخدام في Node.js إذا لزم الأمر
if (typeof module !== 'undefined' && module.exports) {
    module.exports = window.DATA_SCHEMA;
}

console.log('✅ تم تحميل مخطط البيانات الموحد');
