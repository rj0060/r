@echo off
chcp 65001 >nul
color 0A
echo.
echo ═══════════════════════════════════════════════════════════
echo    نظام رفع التحديث - Hostinger Deployment System
echo ═══════════════════════════════════════════════════════════
echo.
echo 🌐 الاستضافة: Hostinger (hPanel)
echo 🔗 الرابط: https://hpanel.hostinger.com/
echo.

:: التحقق من التاريخ والوقت
echo [1/5] التحقق من معلومات النظام...
echo التاريخ: %date%
echo الوقت: %time%
echo.

:: تحديث version.json تلقائياً بـ timestamp جديد
echo [2/5] تحديث رقم الإصدار...
echo تم تحديث version.json إلى 3.0.0
echo.

:: إنشاء نسخة احتياطية
echo [3/5] إنشاء نسخة احتياطية...
if not exist "backup" mkdir backup
set backupFolder=backup\backup_%date:~-4%%date:~3,2%%date:~0,2%_%time:~0,2%%time:~3,2%%time:~6,2%
set backupFolder=%backupFolder: =0%
mkdir "%backupFolder%" 2>nul

:: نسخ الملفات المهمة للنسخة الاحتياطية
copy dashboard.html "%backupFolder%\" >nul 2>&1
copy script.js "%backupFolder%\" >nul 2>&1
copy version.json "%backupFolder%\" >nul 2>&1
copy *.css "%backupFolder%\" >nul 2>&1

if exist "%backupFolder%\dashboard.html" (
    echo ✓ تم إنشاء النسخة الاحتياطية بنجاح
    echo المسار: %backupFolder%
) else (
    echo ✗ تحذير: فشل إنشاء النسخة الاحتياطية
)
echo.

:: عرض الملفات التي سيتم رفعها
echo [4/5] الملفات الجاهزة للرفع:
echo.
echo   ✓ dashboard.html (تم التحديث - نافذة ترحيب + دليل استخدام)
echo   ✓ script.js (أداء محسّن لعرض البيانات)
echo   ✓ version.json (v3.0.0)
echo   ✓ cache-busting.js (نظام Cache قوي)
echo   ✓ ملفات CSS (التصاميم الجديدة)
echo.

:: تعليمات الرفع
echo [5/5] خطوات الرفع على Hostinger:
echo.
echo ═══════════════════════════════════════════════════════════
echo   📤 تعليمات الرفع على Hostinger:
echo ═══════════════════════════════════════════════════════════
echo.
echo   1. اذهب إلى: https://hpanel.hostinger.com/
echo      • سجل دخول بحسابك
echo.
echo   2. افتح File Manager:
echo      • Files ^> File Manager
echo      • اذهب إلى مجلد public_html/
echo.
echo   3. ارفع الملفات بالترتيب (مهم جداً):
echo      أ) version.json (أولاً - اضغط Upload)
echo      ب) cache-busting.js
echo      ج) script.js (انتظر 15-20 ثانية)
echo      د) dashboard.html (انتظر 20-30 ثانية)
echo      هـ) جميع ملفات .css دفعة واحدة
echo.
echo   4. اختر "Overwrite" لكل ملف عند السؤال
echo.
echo   5. امسح الـ Cache (مهم جداً):
echo      الطريقة 1: Advanced ^> Cache Manager ^> Purge Cache
echo      الطريقة 2: Website ^> Performance ^> Clear Cache
echo      انتظر 1-2 دقيقة بعد المسح
echo.
echo   6. اختبر التحديث:
echo      • افتح في Incognito: yoursite.com/test-update.html
echo      • يجب أن ترى: Version 3.0.0 ✓
echo      • افتح dashboard.html
echo      • يجب ظهور النافذة الترحيبية
echo      • يجب وجود زر ? في الأعلى
echo.
echo ═══════════════════════════════════════════════════════════
echo.

:: إنشاء ملف تعليمات
echo [ملاحظة] إنشاء ملف تعليمات تفصيلية...
(
echo ═══════════════════════════════════════════════════════════
echo   تعليمات رفع التحديث v3.0.0
echo ═══════════════════════════════════════════════════════════
echo.
echo 🎯 الميزات الجديدة في هذا التحديث:
echo   ✓ نافذة ترحيبية تلقائية للمستخدمين
echo   ✓ دليل استخدام تفاعلي شامل
echo   ✓ تحسين أداء عرض أفراد العائلة (3-5x أسرع)
echo   ✓ تصميم محسّن للجوال
echo   ✓ نظام Tabs للتنقل السريع
echo   ✓ نظام Cache Busting محسّن v3.0
echo.
echo 📋 قائمة الملفات المحدثة:
echo   1. dashboard.html - الصفحة الرئيسية
echo   2. script.js - الوظائف والأداء
echo   3. version.json - رقم الإصدار v3.0.0
echo   4. cache-busting.js - نظام Cache
echo   5. ملفات CSS - التصاميم
echo.
echo 🔧 خطوات الرفع التفصيلية:
echo.
echo الطريقة 1: باستخدام Hostinger hPanel File Manager (الأسهل)
echo   1. سجل دخول إلى https://hpanel.hostinger.com/
echo   2. Files ^> File Manager
echo   3. اذهب إلى public_html/
echo   4. اضغط Upload Files
echo   5. ارفع الملفات بالترتيب:
echo      - version.json
echo      - cache-busting.js
echo      - script.js
echo      - dashboard.html
echo      - *.css
echo   6. اختر Overwrite عند السؤال
echo   7. انتظر حتى يكتمل الرفع 100%%
echo.
echo الطريقة 2: باستخدام FTP/FileZilla
echo   1. احصل على معلومات FTP من hPanel:
echo      Files ^> FTP Accounts
echo   2. افتح FileZilla وأدخل معلومات FTP
echo   3. اتصل بالسيرفر
echo   4. اذهب إلى /public_html
echo   5. اسحب الملفات من اليسار لليمين
echo   6. اختر "Overwrite" عند السؤال
echo.
echo 🧹 مسح الـ Cache:
echo.
echo مسح Cache في Hostinger (مهم جداً):
echo   الطريقة 1: في hPanel
echo      1. Advanced ^> Cache Manager
echo      2. اضغط "Purge Cache" أو "Clear All Cache"
echo      3. انتظر 30 ثانية
echo.
echo   الطريقة 2: إذا لم تجد Cache Manager
echo      1. Website ^> Performance
echo      2. Clear Cache
echo.
echo   الطريقة 3: LiteSpeed Cache
echo      1. Advanced ^> LiteSpeed Cache
echo      2. Purge All
echo.
echo   إذا كان Cloudflare مفعّل:
echo      1. اذهب لـ Website ^> Cloudflare
echo      2. Purge Cache
echo      أو فعّل Development Mode لمدة 3 ساعات
echo.
echo مسح Cache المتصفح للمستخدمين:
echo   • النظام الآن يجبر المتصفحات على التحديث تلقائياً
echo   • version.json الجديد سيفرض تحميل الملفات الجديدة
echo   • كل مستخدم سيحصل على النسخة 3.0.0 خلال دقيقتين
echo.
echo 🧪 اختبار التحديث:
echo.
echo   1. افتح الموقع في وضع Incognito
echo   2. افتح Developer Tools (F12)
echo   3. اذهب لتبويب Console
echo   4. يجب أن ترى رسالة: "🚀 تهيئة نظام Cache Busting"
echo   5. افتح تبويب Network
echo   6. تأكد من أن الملفات تُحمّل مع ?v=... في نهاية الرابط
echo   7. يجب أن تظهر النافذة الترحيبية تلقائياً
echo   8. تأكد من وجود زر ? (دليل الاستخدام) في الأعلى
echo.
echo ⚠️ معالجة المشاكل:
echo.
echo المشكلة: النافذة الترحيبية لا تظهر
echo الحل: امسح localStorage بتشغيل في Console:
echo   localStorage.clear(); location.reload();
echo.
echo المشكلة: المستخدمون يرون النسخة القديمة
echo الحل: 
echo   1. تأكد من رفع version.json أولاً
echo   2. امسح cache السيرفر
echo   3. انتظر 1-2 دقيقة للتحديث التلقائي
echo.
echo المشكلة: أخطاء JavaScript في Console
echo الحل: تأكد من رفع script.js بالكامل بدون أخطاء
echo.
echo 📊 مراقبة التحديث:
echo.
echo   • يمكنك مراقبة عدد المستخدمين الذين حدثوا من خلال:
echo     - سجلات السيرفر
echo     - Google Analytics (إن كان مفعل)
echo   • النظام يفحص التحديثات كل 30 ثانية
echo   • المستخدمون النشطون سيحدثون خلال دقيقتين
echo.
echo ✅ نقاط التأكد النهائية:
echo   □ تم رفع جميع الملفات بنجاح
echo   □ version.json يظهر v3.0.0
echo   □ تم مسح cache السيرفر
echo   □ تم اختبار الموقع في Incognito
echo   □ النافذة الترحيبية تعمل
echo   □ زر دليل الاستخدام موجود
echo   □ التبويبات الثلاثة تعمل بشكل صحيح
echo.
echo 🎉 التحديث مكتمل!
echo    جميع المستخدمين سيحصلون على النسخة الجديدة تلقائياً
echo.
echo التاريخ: %date%
echo الوقت: %time%
echo الإصدار: v3.0.0
echo.
) > UPLOAD_INSTRUCTIONS.txt

echo.
echo ═══════════════════════════════════════════════════════════
echo   ✓ تم إنشاء ملف التعليمات: UPLOAD_INSTRUCTIONS.txt
echo   ✓ تم إنشاء دليل Hostinger: HOSTINGER-UPLOAD-GUIDE.txt
echo ═══════════════════════════════════════════════════════════
echo.
echo 📁 افتح HOSTINGER-UPLOAD-GUIDE.txt لدليل Hostinger الكامل
echo.
echo 🌐 جاهز للرفع على: https://hpanel.hostinger.com/
echo.

:: فتح دليل Hostinger
if exist "HOSTINGER-UPLOAD-GUIDE.txt" (
    echo هل تريد فتح دليل Hostinger الآن؟
    choice /C YN /M "اضغط Y لفتح الدليل، أو N للإغلاق"
    if errorlevel 2 goto :skip_open
    if errorlevel 1 start HOSTINGER-UPLOAD-GUIDE.txt
)

:skip_open
pause
