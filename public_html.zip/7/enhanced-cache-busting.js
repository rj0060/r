/**
 * Enhanced Cache Busting Manager - مدير محسن للتخزين المؤقت
 * يحل جميع مشاكل التخزين المؤقت في المتصفحات
 */

class CacheBustingManager {
    constructor() {
        this.version = new Date().getTime();
        this.init();
    }

    /**
     * تهيئة النظام
     */
    init() {
        // إضافة إصدارات للملفات الموجودة
        this.addVersionsToExistingFiles();
        
        // مراقبة تحميل ملفات جديدة
        this.observeNewFiles();
        
        // إضافة أزرار التحكم
        this.addControlButtons();
        
        console.log('Cache Busting Manager initialized with version:', this.version);
    }

    /**
     * إضافة إصدارات للملفات الموجودة
     */
    addVersionsToExistingFiles() {
        // معالجة ملفات CSS
        const cssLinks = document.querySelectorAll('link[rel="stylesheet"][href*=".css"]:not([href*="http"]):not([href*="cdn"])');
        cssLinks.forEach(link => {
            const href = link.getAttribute('href');
            if (!href.includes('?v=')) {
                link.setAttribute('href', `${href}?v=${this.version}`);
            }
        });

        // معالجة ملفات JavaScript
        const jsScripts = document.querySelectorAll('script[src*=".js"]:not([src*="http"]):not([src*="cdn"])');
        jsScripts.forEach(script => {
            const src = script.getAttribute('src');
            if (!src.includes('?v=')) {
                script.setAttribute('src', `${src}?v=${this.version}`);
            }
        });
    }

    /**
     * مراقبة إضافة ملفات جديدة
     */
    observeNewFiles() {
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'childList') {
                    mutation.addedNodes.forEach((node) => {
                        if (node.nodeType === 1) { // Element node
                            this.processNewNode(node);
                        }
                    });
                }
            });
        });

        observer.observe(document.head, { childList: true, subtree: true });
        observer.observe(document.body, { childList: true, subtree: true });
    }

    /**
     * معالجة العقد الجديدة
     */
    processNewNode(node) {
        // معالجة CSS links
        if (node.tagName === 'LINK' && node.getAttribute('rel') === 'stylesheet') {
            const href = node.getAttribute('href');
            if (href && href.includes('.css') && !href.includes('http') && !href.includes('?v=')) {
                node.setAttribute('href', `${href}?v=${this.version}`);
            }
        }

        // معالجة JavaScript scripts
        if (node.tagName === 'SCRIPT' && node.getAttribute('src')) {
            const src = node.getAttribute('src');
            if (src && src.includes('.js') && !src.includes('http') && !src.includes('?v=')) {
                node.setAttribute('src', `${src}?v=${this.version}`);
            }
        }

        // البحث داخل العقدة عن ملفات أخرى
        const cssLinks = node.querySelectorAll && node.querySelectorAll('link[rel="stylesheet"][href*=".css"]:not([href*="http"])');
        if (cssLinks) {
            cssLinks.forEach(link => {
                const href = link.getAttribute('href');
                if (!href.includes('?v=')) {
                    link.setAttribute('href', `${href}?v=${this.version}`);
                }
            });
        }

        const jsScripts = node.querySelectorAll && node.querySelectorAll('script[src*=".js"]:not([src*="http"])');
        if (jsScripts) {
            jsScripts.forEach(script => {
                const src = script.getAttribute('src');
                if (!src.includes('?v=')) {
                    script.setAttribute('src', `${src}?v=${this.version}`);
                }
            });
        }
    }

    /**
     * فرض إعادة تحميل جميع الملفات
     */
    forceReloadAll() {
        const newVersion = new Date().getTime();
        
        // إعادة تحميل CSS
        const cssLinks = document.querySelectorAll('link[rel="stylesheet"]');
        cssLinks.forEach(link => {
            const href = link.getAttribute('href');
            if (href && !href.includes('http')) {
                const baseHref = href.split('?')[0];
                link.setAttribute('href', `${baseHref}?v=${newVersion}`);
            }
        });

        // إعادة تحميل JavaScript (يتطلب إعادة تحميل الصفحة)
        setTimeout(() => {
            window.location.reload(true);
        }, 100);
    }

    /**
     * فرض إعادة تحميل CSS فقط
     */
    forceReloadCSS() {
        const newVersion = new Date().getTime();
        
        const cssLinks = document.querySelectorAll('link[rel="stylesheet"]');
        cssLinks.forEach(link => {
            const href = link.getAttribute('href');
            if (href && !href.includes('http')) {
                const baseHref = href.split('?')[0];
                link.setAttribute('href', `${baseHref}?v=${newVersion}`);
            }
        });

        console.log('CSS files reloaded with version:', newVersion);
    }

    /**
     * التحقق من التحديثات
     */
    async checkForUpdates() {
        try {
            const response = await fetch(`version.json?t=${Date.now()}`);
            const data = await response.json();
            
            if (data.timestamp > this.version) {
                console.log('New version available:', data.version);
                
                // إشعار المستخدم
                if (window.Toastify) {
                    Toastify({
                        text: "يتوفر تحديث جديد للموقع. انقر لتحديث الصفحة",
                        duration: 10000,
                        gravity: "top",
                        position: "center",
                        backgroundColor: "#4CAF50",
                        onClick: () => this.forceReloadAll()
                    }).showToast();
                } else {
                    if (confirm('يتوفر تحديث جديد للموقع. هل تريد تحديث الصفحة؟')) {
                        this.forceReloadAll();
                    }
                }
            }
        } catch (error) {
            console.warn('Could not check for updates:', error);
        }
    }

    /**
     * إضافة أزرار التحكم (للمطورين)
     */
    addControlButtons() {
        // إضافة أزرار فقط في وضع التطوير
        if (window.location.hostname === 'localhost' || window.location.hostname.includes('127.0.0.1')) {
            this.createDevControls();
        }
    }

    /**
     * إنشاء أزرار التحكم للمطورين
     */
    createDevControls() {
        const controlPanel = document.createElement('div');
        controlPanel.id = 'cache-control-panel';
        controlPanel.style.cssText = `
            position: fixed;
            top: 10px;
            right: 10px;
            background: #333;
            color: white;
            padding: 10px;
            border-radius: 5px;
            z-index: 10000;
            font-size: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        `;

        controlPanel.innerHTML = `
            <div style="margin-bottom: 5px;">Cache Control</div>
            <button onclick="cacheBusting.forceReloadCSS()" style="margin: 2px; padding: 5px; font-size: 10px;">Reload CSS</button>
            <button onclick="cacheBusting.forceReloadAll()" style="margin: 2px; padding: 5px; font-size: 10px;">Reload All</button>
            <button onclick="cacheBusting.checkForUpdates()" style="margin: 2px; padding: 5px; font-size: 10px;">Check Updates</button>
        `;

        document.body.appendChild(controlPanel);
    }

    /**
     * مسح التخزين المؤقت للمتصفح
     */
    clearBrowserCache() {
        // مسح localStorage
        localStorage.clear();
        
        // مسح sessionStorage
        sessionStorage.clear();
        
        // محاولة مسح Cache API إذا كان متاحاً
        if ('caches' in window) {
            caches.keys().then(names => {
                names.forEach(name => {
                    caches.delete(name);
                });
            });
        }

        console.log('Browser cache cleared');
    }
}

// إنشاء مثيل عام
let cacheBusting;

// تهيئة النظام عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
    cacheBusting = new CacheBustingManager();
    
    // جعل النظام متاح عالمياً
    window.cacheBusting = cacheBusting;
    
    // التحقق من التحديثات كل 5 دقائق
    setInterval(() => {
        cacheBusting.checkForUpdates();
    }, 5 * 60 * 1000);
});

// التحقق من التحديثات عند استعادة التركيز للنافذة
window.addEventListener('focus', () => {
    if (cacheBusting) {
        cacheBusting.checkForUpdates();
    }
});

// إضافة دالة مساعدة لتحديد الإصدار في HTML
window.getAssetVersion = function() {
    return new Date().getTime();
};
