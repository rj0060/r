/**
 * دالة تسجيل النشاطات في سجل الأنشطة
 * @param {string} activityType - نوع النشاط
 * @param {string} userId - رقم هوية المستخدم
 * @param {string} description - وصف النشاط
 */
function logActivity(activityType, userId, description) {
  try {
    const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    let logSheet = ss.getSheetByName('سجل الأنشطة');
    
    // إنشاء الشيت إذا لم يكن موجوداً
    if (!logSheet) {
      logSheet = ss.insertSheet('سجل الأنشطة');
      logSheet.appendRow(['التاريخ', 'نوع النشاط', 'رقم الهوية', 'الوصف']);
    }
    
    // إضافة السجل
    logSheet.appendRow([
      new Date(),
      activityType,
      userId,
      description
    ]);
    
    Logger.log(`تم تسجيل النشاط: ${activityType} - ${userId}`);
  } catch (error) {
    Logger.log('خطأ في تسجيل النشاط: ' + error.toString());
  }
}
