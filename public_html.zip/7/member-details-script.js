document.addEventListener('DOMContentLoaded', async function() {
    const urlParams = new URLSearchParams(window.location.search);
    const memberId = urlParams.get('id');

    if (!memberId) {
        console.error('Member ID not found in URL.');
        Toastify({
            text: "خطأ: لم يتم العثور على معرف الفرد.",
            duration: 4000,
            gravity: "top",
            position: "center",
            backgroundColor: "linear-gradient(to right, #ff6b6b, #feca57)",
        }).showToast();
        return;
    }

    // Function to calculate age
    function calculateAge(birthDate) {
        if (!birthDate) return 'غير محدد';
        try {
            const today = new Date();
            const birth = new Date(birthDate);
            let age = today.getFullYear() - birth.getFullYear();
            const monthDiff = today.getMonth() - birth.getMonth();
            if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
                age--;
            }
            return age >= 0 ? age : 'غير محدد';
        } catch (error) {
            return 'غير محدد';
        }
    }

    // Function to load member data
    async function loadMemberData(id) {
        try {
            // Assuming App.apiCall is available from script.js or app-config.js
            if (typeof App === 'undefined' || typeof App.apiCall !== 'function') {
                throw new Error('App.apiCall is not defined. Ensure script.js is loaded.');
            }

            const response = await App.apiCall({
                action: 'getMemberDetails', // New action for fetching single member details
                memberId: id
            });

            if (response && response.success && response.memberData) {
                const member = response.memberData;
                document.getElementById('memberNameHeader').textContent = member.fullName || member.name || 'غير محدد';
                document.getElementById('memberFullName').textContent = member.fullName || member.name || 'غير محدد';
                document.getElementById('memberIdNumberDisplay').textContent = `هوية: ${member.idNumber || '---'}`;

                document.getElementById('displayFullName').textContent = member.fullName || member.name || '---';
                document.getElementById('displayIdNumber').textContent = member.idNumber || '---';
                document.getElementById('displayBirthDate').textContent = member.birthDate || '---';
                document.getElementById('displayAge').textContent = calculateAge(member.birthDate);
                document.getElementById('displayGender').textContent = member.gender || '---';
                document.getElementById('displayRelation').textContent = member.relation || '---';
                document.getElementById('displayMaritalStatus').textContent = member.maritalStatus || '---';
                document.getElementById('displayEducation').textContent = member.education || '---';
                document.getElementById('displayProfession').textContent = member.profession || '---';

                // Populate additional fields if they exist
                document.getElementById('specialNeeds').value = member.specialNeeds || '';
                document.getElementById('specialNeedsType').value = member.specialNeedsType || '';
                document.getElementById('universityGraduate').value = member.universityGraduate || '';
                document.getElementById('graduationYear').value = member.graduationYear || '';
                document.getElementById('memberNotes').value = member.notes || '';

            } else {
                throw new Error(response?.message || 'فشل في تحميل بيانات الفرد.');
            }
        } catch (error) {
            console.error('Error loading member data:', error);
            Toastify({
                text: `خطأ في تحميل بيانات الفرد: ${error.message}`,
                duration: 5000,
                gravity: "top",
                position: "center",
                backgroundColor: "linear-gradient(to right, #ff6b6b, #feca57)",
            }).showToast();
        }
    }

    // Handle form submission for additional info
    document.getElementById('additionalMemberInfoForm').addEventListener('submit', async function(event) {
        event.preventDefault();

        const specialNeeds = document.getElementById('specialNeeds').value;
        const specialNeedsType = document.getElementById('specialNeedsType').value.trim();
        const universityGraduate = document.getElementById('universityGraduate').value;
        const graduationYear = document.getElementById('graduationYear').value.trim();
        const memberNotes = document.getElementById('memberNotes').value.trim();

        // Basic validation
        if (specialNeeds === 'نعم' && !specialNeedsType) {
            Toastify({
                text: "يرجى تحديد نوع الاحتياج الخاص.",
                duration: 3000,
                gravity: "top",
                position: "center",
                backgroundColor: "linear-gradient(to right, #ff6b6b, #feca57)",
            }).showToast();
            return;
        }
        if (universityGraduate === 'نعم' && !graduationYear) {
            Toastify({
                text: "يرجى إدخال سنة التخرج.",
                duration: 3000,
                gravity: "top",
                position: "center",
                backgroundColor: "linear-gradient(to right, #ff6b6b, #feca57)",
            }).showToast();
            return;
        }

        const submitBtn = this.querySelector('button[type="submit"]');
        const originalHTML = submitBtn.innerHTML;
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>جاري الحفظ...';

        try {
            const response = await App.apiCall({
                action: 'updateMemberAdditionalInfo', // New action for updating additional info
                memberId: memberId,
                updates: {
                    specialNeeds: specialNeeds,
                    specialNeedsType: specialNeedsType,
                    universityGraduate: universityGraduate,
                    graduationYear: graduationYear,
                    notes: memberNotes
                }
            });

            if (response && response.success) {
                Toastify({
                    text: "تم حفظ البيانات الإضافية بنجاح!",
                    duration: 3000,
                    gravity: "top",
                    position: "center",
                    backgroundColor: "linear-gradient(to right, #00b09b, #96c93d)",
                }).showToast();
                // Reload data to reflect changes
                loadMemberData(memberId);
            } else {
                throw new Error(response?.message || 'فشل في حفظ البيانات الإضافية.');
            }
        } catch (error) {
            console.error('Error saving additional info:', error);
            Toastify({
                text: `خطأ في حفظ البيانات: ${error.message}`,
                duration: 5000,
                gravity: "top",
                position: "center",
                backgroundColor: "linear-gradient(to right, #ff6b6b, #feca57)",
            }).showToast();
        } finally {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalHTML;
        }
    });

    // Initial load of member data
    loadMemberData(memberId);
});
