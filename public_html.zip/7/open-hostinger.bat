@echo off
color 0B
echo.
echo ═══════════════════════════════════════════════════════════
echo    🚀 فتح Hostinger hPanel
echo ═══════════════════════════════════════════════════════════
echo.
echo جاري فتح Hostinger في المتصفح...
echo.

:: فتح Hostinger hPanel
start https://hpanel.hostinger.com/

echo.
echo ✅ تم فتح Hostinger في المتصفح
echo.
echo 📋 خطوات سريعة:
echo   1. سجل دخول
echo   2. Files ^> File Manager
echo   3. اذهب لـ public_html/
echo   4. Upload Files
echo   5. ارفع بالترتيب: version.json ^> cache-busting.js ^> script.js ^> dashboard.html ^> CSS
echo   6. Advanced ^> Cache Manager ^> Purge Cache
echo.
echo 📖 افتح HOSTINGER-UPLOAD-GUIDE.txt للتعليمات الكاملة
echo.

timeout /t 5
