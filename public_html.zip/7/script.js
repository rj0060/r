/**
 * @file script.js
 * @description Frontend logic for the Family Aid System.
 * @version 10.0 - Final version with dedicated wounded registration page.
 */

document.addEventListener('DOMContentLoaded', () => {
    const App = {
    // The backend URL is loaded at runtime from (in order):
    // 1) window.APP_CONFIG?.WEB_APP_URL (set by hosting or a script tag)
    // 2) /app-config.json (local config file you can change without editing this file)
    // 3) fallback to the original Apps Script URL for backward compatibility
    WEB_APP_URL: null,
    // رابط افتراضي احتياطي (يستخدم فقط إذا لم يوجد app-config.js أو app-config.json)
    DEFAULT_WEB_APP_URL: 'APP_CONFIG',
    // NOTE: تمت إزالة التعاريف المكررة (cache, CACHE_DURATION) - الكاش المركزي الحديث يبدأ لاحقاً
        
        async testNewUrl() {
            const input = document.getElementById('newScriptUrl');
            const newUrl = input?.value?.trim();
            
            if (!newUrl) {
                this.showToast('يرجى إدخال رابط صحيح', false);
                return;
            }
            
            if (!newUrl.includes('script.google.com')) {
                this.showToast('الرابط يجب أن يكون من script.google.com', false);
                return;
            }
            
            this.showToast('جاري اختبار الرابط الجديد...', true);
            
            try {
                const response = await fetch(newUrl, { method: 'GET', mode: 'cors' });
                if (response.ok) {
                    const data = await response.json();
                    this.showDialog({
                        title: '✅ الرابط يعمل!',
                        message: `
                            <p>الرابط الجديد يعمل بشكل صحيح!</p>
                            <p><strong>إصدار الخادم:</strong> ${data.version || 'غير محدد'}</p>
                            <p>يمكنك الآن تحديث الرابط في ملف script.js</p>
                            <code style="word-break: break-all;">${newUrl}</code>
                        `,
                        type: 'success'
                    });
                } else {
                    throw new Error(`خطأ ${response.status}: ${response.statusText}`);
                }
            } catch (error) {
                this.showDialog({
                    title: '❌ الرابط لا يعمل',
                    message: `
                        <p>فشل في الاتصال بالرابط الجديد:</p>
                        <p class="text-danger">${error.message}</p>
                        <p>تأكد من أن الرابط صحيح وأن المشروع منشور بشكل صحيح.</p>
                    `,
                    type: 'error'
                });
            }
        },
        aidCategories: {
            "مساعدات مالية": ["نقد مباشر للعائلات المحتاجة", "دفع فواتير (كهرباء، ماء، إيجار)", "قروض حسنة أو صناديق دوارة"],
            "مساعدات غذائية": ["طرود غذائية أساسية", "وجبات جاهزة / مطبوخة", "توزيع مياه للشرب"],
            "مساعدات صحية": ["أدوية وعلاجات", "فحوصات طبية مجانية", "تغطية تكاليف العمليات", "أدوات مساعدة (نظارات، كراسي متحركة)"],
            "مساعدات تعليمية": ["منح دراسية", "توفير قرطاسية وحقائب مدرسية", "تغطية رسوم جامعية أو مدرسية", "دورات تدريبية وتأهيل مهني"],
            "مساعدات إغاثية (طارئة)": ["خيم وأغطية في حالات النزوح", "ملابس وأحذية", "أدوات نظافة وتعقيم", "تدخل عاجل في الكوارث"],
            "مساعدات سكنية": ["بناء أو ترميم منازل", "دفع إيجارات", "توفير أثاث أو أجهزة كهربائية"],
            "مساعدات تشغيلية": ["تمويل مشاريع صغيرة", "تدريب مهني", "أدوات عمل أو معدات إنتاج"]
        },
        searchTimeout: null,
        membersList: [],
        allCompletedAidRecords: [],
        allFutureAidRecords: [],
        currentFilteredFutureAid: [],
        futureAidCurrentPage: 1,
        futureAidPageSize: 10,
        
        // نظام الصفحات للوحة تحكم المستخدم
        userFutureAidPage: 1,
        userFutureAidPageSize: 5,
        userAidHistoryPage: 1,
        userAidHistoryPageSize: 5,
        
        // بيانات مؤقتة للصفحات
        allUserFutureAid: [],
        allUserAidHistory: [],
        
        // وظائف تغيير الصفحات
        changeUserFutureAidPage(page) {
            const totalPages = Math.ceil(this.allUserFutureAid.length / this.userFutureAidPageSize);
            if (page < 1 || page > totalPages) return;
            this.userFutureAidPage = page;
            this.renderFutureAidWithPagination();
            this.updateFutureAidPaginationDisplay();
            if (typeof updateFutureAidMobile === 'function') {
                updateFutureAidMobile();
            }
        },
        
        changeUserAidHistoryPage(page) {
            const totalPages = Math.ceil(this.allUserAidHistory.length / this.userAidHistoryPageSize);
            if (page < 1 || page > totalPages) return;
            this.userAidHistoryPage = page;
            this.renderAidHistoryWithPagination();
            this.updateAidHistoryPaginationDisplay();
            if (typeof updateAidHistoryMobile === 'function') {
                updateAidHistoryMobile();
            }
        },
        
        // وظائف تحديث عرض أزرار التصفح
        updateFutureAidPaginationDisplay() {
            const totalPages = Math.ceil(this.allUserFutureAid.length / this.userFutureAidPageSize);
            const pagination = document.getElementById('futureAidPagination');
            const currentPageEl = document.getElementById('futureAidCurrentPage');
            const totalPagesEl = document.getElementById('futureAidTotalPages');

            if (!pagination || !currentPageEl || !totalPagesEl) return;
            
            if (totalPages > 1) {
                pagination.style.display = 'flex';
                currentPageEl.textContent = this.userFutureAidPage;
                totalPagesEl.textContent = totalPages;
            } else {
                pagination.style.display = 'none';
            }
        },
        
        updateAidHistoryPaginationDisplay() {
            const totalPages = Math.ceil(this.allUserAidHistory.length / this.userAidHistoryPageSize);
            const pagination = document.getElementById('aidHistoryPagination');
            const currentPageEl = document.getElementById('aidHistoryCurrentPage');
            const totalPagesEl = document.getElementById('aidHistoryTotalPages');

            if (!pagination || !currentPageEl || !totalPagesEl) return;
            
            if (totalPages > 1) {
                pagination.style.display = 'flex';
                currentPageEl.textContent = this.userAidHistoryPage;
                totalPagesEl.textContent = totalPages;
            } else {
                pagination.style.display = 'none';
            }
        },
        
        setPasswordModal: null, loginPasswordModal: null, forgotPasswordModal: null,
        userLoginModal: null, adminLoginModal: null,
        bulkCompleteModal: null, printReportModalInstance: null, editMemberModalInstance: null,
        // نوافذ الأحداث الحياتية
        eventsLoginModal: null, eventsCreatePasswordModal: null, eventsForgotPasswordModal: null,

    // In-memory cache (volatile)
    cache: new Map(),
    cacheExpiry: 5 * 60 * 1000, // 5 minutes (memory)
    // Persistent cache (localStorage) shorter TTL for super fast perceived load
    persistentCacheTTL: 60 * 1000, // 60s for critical user views
    persistentCachePrefix: 'fasCache:',
    // Track in-flight API calls to prevent duplicate simultaneous fetches
    inFlightRequests: new Map(),

        // Cache management methods
        getCacheKey(action, payload) {
            // Create a unique key based on action and relevant payload parameters
            const relevantKeys = ['userId', 'token', 'searchTerm', 'page', 'pageSize'];
            const keyParts = [action];
            relevantKeys.forEach(key => {
                if (payload[key] !== undefined) {
                    keyParts.push(`${key}:${payload[key]}`);
                }
            });
            return keyParts.join('|');
        },

        getCachedResult(key) {
            const cached = this.cache.get(key);
            if (cached && Date.now() - cached.timestamp < this.cacheExpiry) {
                return cached.data;
            }
            if (cached) {
                this.cache.delete(key); // Remove expired cache
            }
            return null;
        },

        // ---------- Persistent Cache (localStorage) ----------
        _buildPersistentKey(key){ return this.persistentCachePrefix + key; },
        getPersistentCache(key){
            try {
                const raw = localStorage.getItem(this._buildPersistentKey(key));
                if (!raw) return null;
                const obj = JSON.parse(raw);
                if (!obj || !obj.t || !('d' in obj)) return null;
                if (Date.now() - obj.t > this.persistentCacheTTL) { localStorage.removeItem(this._buildPersistentKey(key)); return null; }
                return obj.d;
            } catch { return null; }
        },
        setPersistentCache(key, data){
            try { localStorage.setItem(this._buildPersistentKey(key), JSON.stringify({ t: Date.now(), d: data })); } catch {}
        },
        clearPersistentCache(){
            try {
                Object.keys(localStorage).forEach(k => { if (k.startsWith(this.persistentCachePrefix)) localStorage.removeItem(k); });
            } catch {}
        },

        setCachedResult(key, data) {
            this.cache.set(key, {
                data: data,
                timestamp: Date.now()
            });
        },

        clearCache() {
            this.cache.clear();
        },

        init() {
            this.initModals();

            // Load runtime config (app-config.json or window.APP_CONFIG) which may set WEB_APP_URL
            // Continue initialization after config is loaded so backend-dependent checks use the correct URL.
            this.loadConfig().then(() => {
                this.initPageBasedOnURL();
                this.checkServerStatus();
            }).catch(err => {
                console.warn('Failed to load app config, continuing with defaults', err);
                this.initPageBasedOnURL();
                this.checkServerStatus();
            });
        },

        // Try to load `window.APP_CONFIG`, then `/app-config.json`. If neither present, fall back to DEFAULT_WEB_APP_URL.
        async loadConfig() {
            try {
                // 1) window.APP_CONFIG
                if (window.APP_CONFIG && window.APP_CONFIG.WEB_APP_URL) {
                    this.WEB_APP_URL = window.APP_CONFIG.WEB_APP_URL;
                    console.log('Loaded WEB_APP_URL from window.APP_CONFIG');
                    return;
                }

                // 2) fetch local app-config.json
                const resp = await fetch('app-config.json', { cache: 'no-store' });
                if (resp.ok) {
                    const cfg = await resp.json();
                    if (cfg && cfg.WEB_APP_URL) {
                        this.WEB_APP_URL = cfg.WEB_APP_URL;
                        console.log('Loaded WEB_APP_URL from app-config.json');
                        return;
                    }
                }
            } catch (err) {
                console.warn('Unable to load app-config.json or window.APP_CONFIG', err);
            }

            // 3) fallback
            this.WEB_APP_URL = this.DEFAULT_WEB_APP_URL;
            console.log('Using DEFAULT_WEB_APP_URL');
        },
        
        initModals() {
            const getModal = (id) => document.getElementById(id) ? new bootstrap.Modal(document.getElementById(id)) : null;
            this.setPasswordModal = getModal('setPasswordModal');
            this.loginPasswordModal = getModal('loginPasswordModal');
            this.forgotPasswordModal = getModal('forgotPasswordModal');
            this.userLoginModal = getModal('userLoginModal');
            this.adminLoginModal = getModal('adminLoginModal');
            this.bulkCompleteModal = getModal('confirmBulkCompleteModal');
            this.printReportModalInstance = getModal('printReportModal');
            this.editMemberModalInstance = getModal('editMemberModal');
            // نوافذ الأحداث الحياتية
            this.eventsLoginModal = getModal('eventsLoginModal');
            this.eventsCreatePasswordModal = getModal('eventsCreatePasswordModal');
            this.eventsForgotPasswordModal = getModal('eventsForgotPasswordModal');
        },

        async initPageBasedOnURL() {
            const path = window.location.pathname.split('/').pop() || 'index.html';
            const token = sessionStorage.getItem('adminToken');
            const adminPages = ['admin.html', 'manage-members.html', 'manage-aid.html', 'aid-logs.html', 'reports.html', 'password-resets.html', 'superadmin.html', 'life-requests.html'];
            
            if (!token && adminPages.includes(path)) {
                window.location.href = 'index.html';
                return;
            }
            
            const pageInitializers = {
                'index.html': () => this.initIndexPage(),
                'dashboard.html': () => this.initDashboardPage(),
                'admin.html': () => this.initAdminDashboardPage(token),
                'manage-members.html': () => this.initManageMembersPage(token),
                'manage-aid.html': () => this.initManageAidPage(token),
                'aid-logs.html': async () => await this.initAidLogsPage(token),
                'reports.html': () => this.initReportsPage(token),
                'password-resets.html': () => this.initPasswordResetsPage(token),
                'superadmin.html': () => this.initSuperAdminPage(token),
                'wounded-form.html': () => this.initWoundedFormPage(),
                'special-cases.html': () => this.initSpecialCasesPage(),
                'manage-special-cases.html': () => this.initManageSpecialCasesPage(),
                'manage-family-members.html': () => this.initManageFamilyMembersPage(token), // New admin page
            };
            
            if (pageInitializers[path]) {
                await pageInitializers[path]();
            }
        },

        initManageSpecialCasesPage() {
            const token = sessionStorage.getItem('adminToken');
            if (!token) { window.location.href = 'index.html'; return; }
            // nothing else here - the page has its own script that calls App.postToServer
        },

        initManageFamilyMembersPage(token) {
            if (!token) { window.location.href = 'index.html'; return; }
            // The logic for fetching and rendering requests is already in the inline script of manage-family-members.html
            // We just need to ensure the global App object is ready and the fetch is triggered.
            console.log('Initializing manage-family-members.html with token:', token);
            // The inline script will call fetchAndRenderRequests on DOMContentLoaded
            // No additional logic needed here for now, as the page handles itself.
        },
        
        async apiCall(payload, showSuccessToast = false, useCache = false, usePersistent = true, backgroundRefresh = true) {
            const activeSubmitButton = (document.activeElement?.tagName === 'BUTTON' && document.activeElement.type === 'submit') ? document.activeElement : document.querySelector('button[type="submit"]:not(:disabled)');
            const isButtonTriggered = activeSubmitButton !== null;
            if (isButtonTriggered) this.toggleButtonSpinner(true, activeSubmitButton);

            // Check cache for read-only operations
            const cacheKey = useCache ? this.getCacheKey(payload.action, payload) : null;
            let persistentServed = false;
            if (cacheKey) {
                const mem = this.getCachedResult(cacheKey);
                if (mem) {
                    console.log('📋 استخدام كاش الذاكرة:', payload.action);
                    if (showSuccessToast && mem.message) this.showToast(mem.message, true);
                    return mem;
                }
                if (usePersistent) {
                    const persisted = this.getPersistentCache(cacheKey);
                    if (persisted) {
                        console.log('⚡ استخدام كاش التخزين المحلي (عرض مبكر):', payload.action);
                        persistentServed = true;
                        if (!backgroundRefresh) return persisted; // لا تحديث لاحق
                        // نطلق تحديث بالخلفية ونرجع نفس البيانات فوراً
                        this.apiCall(payload, false, useCache, false, false).catch(()=>{});
                        return persisted;
                    }
                }
            }

            console.log('🚀 إرسال طلب API:', payload.action);

            // منع تكرار نفس الطلب أثناء التنفيذ
            let inFlightKey = null;
            if (cacheKey) {
                inFlightKey = 'inflight:' + cacheKey;
                if (this.inFlightRequests.has(inFlightKey)) {
                    console.log('⏳ إعادة استخدام طلب قيد التنفيذ:', payload.action);
                    try {
                        const reused = await this.inFlightRequests.get(inFlightKey);
                        if (reused) return reused;
                    } catch (e) { /* ignore */ }
                }
            }

            try {
                const url = this.WEB_APP_URL || this.DEFAULT_WEB_APP_URL;
                const fetchPromise = fetch(url, {
                    method: 'POST',
                    mode: 'cors',
                    redirect: 'follow',
                    headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                    body: JSON.stringify(payload)
                });
                if (inFlightKey) this.inFlightRequests.set(inFlightKey, fetchPromise.then(r=>r));
                const response = await fetchPromise;

                console.log('📡 استجابة الخادم:', response.status, response.statusText);

                if (!response.ok) {
                    if (response.status === 404) {
                        throw new Error('رابط Google Apps Script غير صحيح أو لا يعمل');
                    } else if (response.status === 403) {
                        throw new Error('ليس لديك صلاحية للوصول إلى هذا الخادم');
                    } else if (response.status >= 500) {
                        throw new Error('خطأ في خادم Google Apps Script');
                    } else {
                        throw new Error(`خطأ في الشبكة: ${response.status} - ${response.statusText}`);
                    }
                }

                const result = await response.json();
                console.log('✅ نتيجة الطلب:', result);

                if (!result.success) throw new Error(result.message || 'حدث خطأ غير معروف في الخادم.');

                // Cache successful read operations
                if (cacheKey && result.success && !/add|update|delete|submit|create|approve|reject/i.test(payload.action)) {
                    this.setCachedResult(cacheKey, result);
                    if (usePersistent && !persistentServed) this.setPersistentCache(cacheKey, result);
                } else if (/add|update|delete|submit|create|approve|reject/i.test(payload.action)) {
                    // عملية كتابة: امسح الكاش المرتبط
                    if (cacheKey) {
                        this.cache.delete(cacheKey);
                        try { localStorage.removeItem(this._buildPersistentKey(cacheKey)); } catch {}
                    }
                }

                if (showSuccessToast && result.message) this.showToast(result.message, true);
                return result;

            } catch (error) {
                console.error('❌ فشل في API Call:', error);

                // رسائل خطأ مفصلة
                let errorMessage = error.message;
                if (error.name === 'TypeError' && error.message.includes('Failed to fetch')) {
                    errorMessage = '⚠️ فشل الاتصال بالخادم';

                    // إظهار نافذة مساعدة بعد ثانيتين
                    setTimeout(() => {
                        this.showScriptUrlHelp();
                    }, 2000);
                }

                this.showToast(errorMessage, false);
                return null;
            } finally {
                if (inFlightKey) this.inFlightRequests.delete(inFlightKey);
                if (isButtonTriggered) this.toggleButtonSpinner(false, activeSubmitButton);
            }
        },

        showScriptUrlHelp() {
            this.showDialog({
                title: '🔧 تعليمات إصلاح الاتصال بالخادم',
                message: `
                    <p>تاكد من اتصالك بالانترنت وان يكون سرعة الانترنت مناسبة.</p>
                `,
                type: 'warning',
                confirmText: 'فهمت'
            });
        },

        // Tolerant POST helper used by pages (preserves behavior from inline scripts)
        async postToServer(payload) {
            try {
                const url = this.WEB_APP_URL || this.DEFAULT_WEB_APP_URL;
                const response = await fetch(url, {
                    method: 'POST',
                    mode: 'cors',
                    redirect: 'follow',
                    headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                    body: JSON.stringify(payload)
                });

                const raw = await response.text();
                let data = null;
                try { data = raw ? JSON.parse(raw) : null; } catch { data = null; }

                if (!response.ok) {
                    const snippet = raw ? raw.substring(0, 200) : '';
                    const msg = (data && data.message) ? data.message : (snippet || `HTTP ${response.status}`);
                    console.error('postToServer error', { status: response.status, snippet, payload });
                    throw new Error(msg);
                }

                if (!data) {
                    const snippet = raw ? raw.substring(0, 200) : '';
                    const looksHtml = /^\s*<!DOCTYPE|^\s*<html|^\s*<HTML/i.test(snippet);
                    const authHint = /Authorization|login|Sign in|requires authentication|OAuth/i.test(snippet);
                    const hint = looksHtml && authHint
                        ? 'يبدو أن تطبيق Google Apps Script يحتاج إلى إعادة نشر مع منح الصلاحيات الجديدة (Drive). افتح Code.gs > Deploy > Manage deployments ثم Update مع Execute as: Me و Access: Anyone، ووافق على الصلاحيات.'
                        : '';
                    console.error('postToServer empty/non-JSON', { snippet, payload });
                    throw new Error(`رد الخادم غير صالح (فارغ أو ليس JSON). الحالة ${response.status}${hint ? `\n\n${hint}` : (snippet ? ` | المعاينة: ${snippet}` : '')}`);
                }

                return data;
            } catch (err) {
                // bubble up to caller to handle UI messages
                throw err;
            }
        },

        // Verify a person id against the family DB. Returns { exists: boolean, name: string }
        // Debounced to prevent excessive API calls
        verifyPersonById: (() => {
            let timeoutId = null;
            let lastId = null;
            let lastResult = null;

            return async function(id) {
                console.log('verifyPersonById called with ID:', id);
                
                if (!id) {
                    console.log('No ID provided, returning false');
                    return { exists: false, name: '' };
                }

                // Return cached result if same ID
                if (id === lastId && lastResult) {
                    console.log('Returning cached result for ID:', id, lastResult);
                    return lastResult;
                }

                // Clear previous timeout
                if (timeoutId) {
                    clearTimeout(timeoutId);
                }

                // Debounce the API call by 500ms
                return new Promise((resolve) => {
                    timeoutId = setTimeout(async () => {
                        try {
                            console.log('Making API call to getUserData for ID:', id);
                            // Primary: query general getUserData which is available
                            const fbData = await this.postToServer({ action: 'getUserData', userId: id });
                            console.log('getUserData response:', fbData);
                            
                            if (fbData && fbData.success && fbData.data) {
                                lastResult = { exists: true, name: fbData.data['الاسم الكامل'] || '' };
                                console.log('Person found:', lastResult);
                            } else {
                                lastResult = { exists: false, name: '' };
                                console.log('Person not found or no data');
                            }
                            lastId = id;
                            resolve(lastResult);
                        } catch (err) {
                            // On any error, return not found (caller may show messages)
                            console.error('verifyPersonById failed for ID:', id, err);
                            lastResult = { exists: false, name: '' };
                            lastId = id;
                            resolve(lastResult);
                        }
                    }, 500);
                });
            };
        })(),
        
                showToast(message, isSuccess = true) { Toastify({ text: message, duration: 4000, gravity: "top", position: "center", style: { background: isSuccess ? "#28a745" : "#dc3545", boxShadow: "none" } }).showToast(); },
        
                // Pretty modal dialog for success/error/info messages
                showDialog({ title = '', message = '', type = 'info', confirmText = 'حسناً', autoCloseMs = null } = {}) {
                        // Ensure container exists or create dynamically
                        let modalEl = document.getElementById('appDialogModal');
                        if (!modalEl) {
                                modalEl = document.createElement('div');
                                modalEl.id = 'appDialogModal';
                                modalEl.className = 'modal fade';
                                modalEl.tabIndex = -1;
                                modalEl.setAttribute('aria-hidden', 'true');
                                modalEl.innerHTML = `
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title d-flex align-items-center gap-2">
                                                        <i id="appDialogIcon" class="bi"></i>
                                                        <span id="appDialogTitle"></span>
                                                    </h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div id="appDialogMessage" class="fs-6"></div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button id="appDialogConfirm" type="button" class="btn btn-primary" data-bs-dismiss="modal">${confirmText}</button>
                                                </div>
                                            </div>
                                        </div>`;
                                document.body.appendChild(modalEl);
                        }
                        const iconEl = modalEl.querySelector('#appDialogIcon');
                        const titleEl = modalEl.querySelector('#appDialogTitle');
                        const msgEl = modalEl.querySelector('#appDialogMessage');
                        const headerEl = modalEl.querySelector('.modal-header');
                        const confirmBtn = modalEl.querySelector('#appDialogConfirm');

                        // Type styles
                        const typeMap = {
                                success: { header: 'bg-success text-white', icon: 'bi-check-circle-fill' },
                                danger: { header: 'bg-danger text-white', icon: 'bi-x-circle-fill' },
                                error: { header: 'bg-danger text-white', icon: 'bi-x-circle-fill' },
                                warning: { header: 'bg-warning-subtle', icon: 'bi-exclamation-triangle-fill' },
                                info: { header: 'bg-primary text-white', icon: 'bi-info-circle-fill' }
                        };
                        // Reset header classes and apply new
                        headerEl.className = 'modal-header';
                        const styleDef = typeMap[type] || typeMap.info;
                        headerEl.classList.add(...styleDef.header.split(' '));
                        iconEl.className = `bi ${styleDef.icon}`;

                        // Content
                        titleEl.textContent = title || (type === 'success' ? 'تم بنجاح' : type === 'danger' || type === 'error' ? 'حدث خطأ' : 'معلومة');
                        // تحسين عرض الرسائل: استخدام innerHTML للرسائل التي تحتوي على HTML
                        if (typeof message === 'string') {
                            if (message.includes('<')) {
                                msgEl.innerHTML = message;
                            } else {
                                msgEl.textContent = message;
                            }
                        } else { 
                            msgEl.innerHTML = ''; 
                            msgEl.appendChild(message); 
                        }
                        confirmBtn.textContent = confirmText || 'حسناً';

                        const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
                        modal.show();
                        if (autoCloseMs && Number.isFinite(+autoCloseMs)) {
                                setTimeout(() => modal.hide(), +autoCloseMs);
                        }
                },

           

        toggleButtonSpinner(show, button) { 
            const btn = button || document.querySelector('button[type="submit"]'); 
            if (!btn) return; 
            btn.disabled = show; 
            btn.querySelector('.spinner-border')?.classList.toggle('d-none', !show); 
            const buttonText = btn.querySelector('.button-text'); 
            if(buttonText) buttonText.style.opacity = show ? 0.5 : 1;
        },
        formatDateToEnglish(dateString) { if (!dateString) return '-'; try { const date = new Date(dateString); if (isNaN(date.getTime())) return 'Invalid Date'; return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`; } catch (error) { return dateString; } },
        
        async checkServerStatus() {
            const statusDiv = document.getElementById('server-status');
            if (!statusDiv) return; // لا يوجد عنصر في الصفحة الحالية

            // ضمان البنية الداخلية الموحدة مرة واحدة
            if (!statusDiv.querySelector('.status-dot') || !statusDiv.querySelector('.status-text')) {
                statusDiv.innerHTML = '<span class="status-dot"></span><span class="status-text">جاري فحص حالة الخادم...</span>';
            }

            const statusText = statusDiv.querySelector('.status-text');
            const statusDot  = statusDiv.querySelector('.status-dot');
            statusText.textContent = 'جاري فحص حالة الخادم...';
            statusDiv.classList.remove('online','offline');
            statusDot?.classList.remove('online','offline');

            console.log('جاري فحص حالة الخادم...', this.WEB_APP_URL);

            const result = { online: false, version: null, lastChecked: new Date(), error: null };

            try {
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 ثوانٍ حد أقصى
                const url = this.WEB_APP_URL || this.DEFAULT_WEB_APP_URL;
                const response = await fetch(url, { method: 'GET', mode: 'cors', cache: 'no-cache', signal: controller.signal });
                clearTimeout(timeoutId);

                console.log('استجابة الخادم:', response.status, response.statusText);

                if (!response.ok) throw new Error(`HTTP ${response.status}: ${response.statusText}`);

                let data = {};
                try { data = await response.json(); } catch { data = {}; }

                result.online = true;
                result.version = data.version || 'غير معروف';

                statusDiv.classList.add('online');
                statusDot?.classList.add('online');
                statusText.textContent = `الخادم متصل (إصدار ${result.version})`;
            } catch (error) {
                result.error = error.message || 'خطأ غير معروف';
                statusDiv.classList.add('offline');
                statusDot?.classList.add('offline');
                statusText.innerHTML = `
                    <div>⚠️ فشل الاتصال بالخادم</div>
                    <small class="text-muted d-block mt-1">${result.error}</small>
                    <button class="btn btn-sm btn-outline-warning mt-2" onclick="App.showScriptUrlHelp()">🔧 تعليمات الإصلاح</button>
                `;
                if (typeof Toastify !== 'undefined') {
                    Toastify({
                        text: '⚠️ تعذر الاتصال بالخادم، تحقق من رابط Google Apps Script',
                        duration: 6000,
                        gravity: 'top',
                        position: 'center',
                        style: { 
                            background: 'linear-gradient(to right,#ff6b6b,#ee5a52)',
                            direction: 'rtl' 
                        }
                    }).showToast();
                }
            }

            // حفظ الحالة في الكائن العام و إطلاق حدث للتطبيقات الأخرى
            this.serverStatus = result;
            document.dispatchEvent(new CustomEvent('server-status-changed', { detail: result }));
        },

        // بدء مراقبة حالة الخادم بشكل موحد عبر كل الصفحات
        startServerStatusMonitor(intervalMs = 60000) {
            if (this._serverStatusInterval) return; // منع التكرار
            this._serverStatusInterval = setInterval(() => this.checkServerStatus(), intervalMs);
        },

        initIndexPage() {
            document.getElementById('loginForm')?.addEventListener('submit', (e) => this.handleUserLogin(e));
            document.getElementById('adminLoginForm')?.addEventListener('submit', (e) => this.handleAdminLogin(e));
            document.getElementById('setPasswordForm')?.addEventListener('submit', (e) => this.handleModalSetPassword(e));
            document.getElementById('userPasswordForm')?.addEventListener('submit', (e) => this.handleModalLogin(e));
            document.getElementById('loginModalForgotPassword')?.addEventListener('click', (e) => this.handleForgotPassword(e));
            
            // المرحلة الأولى: التحقق من رقم الهوية
            document.getElementById('verifyUserIdBtn')?.addEventListener('click', async (e) => {
                const userId = document.getElementById('forgotPasswordUserId').value.trim();
                
                if (!userId) {
                    this.showToast('يرجى إدخال رقم الهوية', false);
                    return;
                }
                
                const btn = e.target;
                const spinner = document.getElementById('verifySpinner');
                const buttonText = btn.querySelector('.button-text');
                
                spinner?.classList.remove('d-none');
                btn.disabled = true;
                
                try {
                    // التحقق من وجود رقم الهوية والحصول على آخر رقمين من الهاتف
                    const verifyResult = await this.apiCall({ 
                        action: 'checkUserExists', 
                        userId: userId 
                    }, false);
                    
                    if (verifyResult && verifyResult.success) {
                        // الانتقال للمرحلة الثانية
                        document.getElementById('step1Container').classList.add('d-none');
                        document.getElementById('step2Container').classList.remove('d-none');
                        document.getElementById('forgotPasswordUserId2').value = userId;
                        
                        // تحديث رسالة النجاح مع آخر رقمين من الهاتف
                        const successAlert = document.querySelector('#step2Container .alert-success div');
                        if (successAlert && verifyResult.lastTwoDigits) {
                            successAlert.innerHTML = `
                                <strong>تم التحقق من رقم الهوية بنجاح!</strong>
                                <p class="mb-0 mt-1 small">الآن أدخل رقم هاتفك المسجل لدينا (ينتهي بـ: **${verifyResult.lastTwoDigits}) لإكمال العملية.</p>
                            `;
                        }
                        
                        document.getElementById('forgotPasswordPhone').focus();
                        this.showToast('تم التحقق من رقم الهوية بنجاح', true);
                    } else {
                        this.showToast('رقم الهوية غير موجود في النظام', false);
                    }
                } catch (error) {
                    const errorMessage = error?.message || 'رقم الهوية غير موجود في النظام';
                    this.showToast(errorMessage, false);
                } finally {
                    spinner?.classList.add('d-none');
                    btn.disabled = false;
                }
            });
            
            // زر العودة للمرحلة الأولى
            document.getElementById('backToStep1Btn')?.addEventListener('click', () => {
                document.getElementById('step1Container').classList.remove('d-none');
                document.getElementById('step2Container').classList.add('d-none');
                document.getElementById('forgotPasswordPhone').value = '';
            });
            
            // المرحلة الثانية: إعادة تعيين كلمة المرور
            document.getElementById('forgotPasswordForm')?.addEventListener('submit', async (e) => { 
                e.preventDefault(); 
                const userId = document.getElementById('forgotPasswordUserId2').value.trim();
                const phone = document.getElementById('forgotPasswordPhone').value.trim();
                
                if (!userId || !phone) {
                    this.showToast('يرجى إدخال رقم الهاتف', false);
                    return;
                }
                
                const spinner = document.getElementById('resetSpinner');
                const submitBtn = e.target.querySelector('button[type="submit"]');
                
                spinner?.classList.remove('d-none');
                submitBtn.disabled = true;
                
                try {
                    // التحقق من رقم الهاتف
                    const verifyResult = await this.apiCall({ 
                        action: 'verifyUserByPhone', 
                        userId: userId, 
                        phone: phone 
                    }, false);
                    
                    if (!verifyResult || !verifyResult.success) {
                        const errorMessage = verifyResult?.message || 'رقم الهاتف غير صحيح';
                        this.showToast(errorMessage, false);
                        return;
                    }
                    
                    // مسح كلمة المرور
                    const resetResult = await this.apiCall({ 
                        action: 'resetUserPassword', 
                        userId: userId 
                    }, true);
                    
                    if (resetResult && resetResult.success) {
                        this.forgotPasswordModal.hide();
                        
                        // إعادة تعيين النموذج
                        document.getElementById('step1Container').classList.remove('d-none');
                        document.getElementById('step2Container').classList.add('d-none');
                        document.getElementById('forgotPasswordUserId').value = '';
                        document.getElementById('forgotPasswordPhone').value = '';
                        
                        // عرض رسالة نجاح
                        this.showToast('✅ تم مسح كلمة المرور بنجاح! يمكنك الآن تسجيل الدخول وإنشاء كلمة مرور جديدة.', true);
                        
                        // تعبئة بيانات تسجيل الدخول
                        setTimeout(() => {
                            document.getElementById('userId').value = userId;
                            document.getElementById('spouseId').value = '0';
                        }, 1000);
                    }
                } catch (error) {
                    const errorMessage = error?.message || 'حدث خطأ. يرجى المحاولة مرة أخرى.';
                    this.showToast(errorMessage, false);
                } finally {
                    spinner?.classList.add('d-none');
                    submitBtn.disabled = false;
                }
            });
            
            // event listeners للأحداث الحياتية
            document.getElementById('eventsLoginForm')?.addEventListener('submit', (e) => this.handleEventsLogin(e));
            document.getElementById('eventsForgotPasswordForm')?.addEventListener('submit', (e) => this.handleEventsForgotPassword(e));
            document.getElementById('eventsCreatePasswordLink')?.addEventListener('click', (e) => this.showEventsCreatePassword(e));
            document.getElementById('eventsLoginForgotPassword')?.addEventListener('click', (e) => this.showEventsForgotPassword(e));
            document.getElementById('goToUserAreaBtn')?.addEventListener('click', (e) => this.goToUserArea(e));
        },

        initWoundedFormPage() {
            // فحص تسجيل الدخول للأحداث الحياتية
            const eventsUserId = sessionStorage.getItem('eventsLoggedInUserId');
            const eventsUserName = sessionStorage.getItem('eventsLoggedInUserName');
            
            if (!eventsUserId || !eventsUserName) {
                // إذا لم يكن المستخدم مسجل دخول للأحداث، العودة للصفحة الرئيسية
                this.showToast('يجب تسجيل الدخول أولاً للوصول إلى سجل الأحداث الحياتية.', false);
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 1500);
                return;
            }
            
            // عرض رسالة ترحيب للمستخدم المسجل
            this.showToast(`مرحباً بك، ${eventsUserName}. يمكنك الآن إدارة الأحداث الحياتية.`, true);
            
            const form = document.getElementById('woundedForm');
            form?.addEventListener('submit', async (e) => {
                e.preventDefault();
    
                const fileToBase64 = (file) => new Promise((resolve, reject) => {
                    if (!file) {
                        resolve(null);
                        return;
                    }
                    const reader = new FileReader();
                    reader.readAsDataURL(file);
                    reader.onload = () => {
                        const result = reader.result;
                        const base64Data = result.substring(result.indexOf(',') + 1);
                        resolve({ name: file.name, mimeType: file.type, data: base64Data });
                    };
                    reader.onerror = error => reject(error);
                });
    
                try {
                    this.toggleButtonSpinner(true, form.querySelector('button[type="submit"]'));
    
                    const medicalReportFile = document.getElementById('medicalReport').files[0];
                    const injuryPhotoFile = document.getElementById('injuryPhoto').files[0];
                    
                    const [medicalReportData, injuryPhotoData] = await Promise.all([
                        fileToBase64(medicalReportFile),
                        fileToBase64(injuryPhotoFile)
                    ]);
    
                    const payload = {
                        action: 'addWoundedCase',
                        fullName: form.fullName.value,
                        idNumber: form.idNumber.value,
                        phone: form.phone.value,
                        familySize: form.familySize.value,
                        injuryDate: form.injuryDate.value,
                        injuryType: form.injuryType.value,
                        injuryCause: form.injuryCause.value,
                        needs: form.needs.value,
                        notes: form.notes.value,
                        medicalReport: medicalReportData,
                        injuryPhoto: injuryPhotoData
                    };
    
                    const response = await fetch(this.WEB_APP_URL, {
                        method: 'POST',
                        mode: 'cors',
                        redirect: 'follow',
                        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                        body: JSON.stringify(payload)
                    });
    
                    if (!response.ok) throw new Error(`خطأ في الشبكة: ${response.statusText}`);
    
                    const result = await response.json();
                    if (!result.success) throw new Error(result.message || 'حدث خطأ غير معروف في الخادم.');
                    
                    this.showToast(result.message, true);
                    form.reset();
                    window.scrollTo(0, 0);
    
                } catch (error) {
                    console.error('Submission Failed:', error);
                    this.showToast(error.message, false);
                } finally {
                    this.toggleButtonSpinner(false, form.querySelector('button[type="submit"]'));
                }
            });

            // Additional logic from wounded-form.html
            const injuryFormSection = document.getElementById('injury-form');
            const searchInput = document.getElementById('searchInput');
            const grid = document.getElementById('cardsGrid');

            // Local injury form handling removed; use the dedicated injuries.html page and global handler.

            if (location.hash === '#injury-form') {
                window.location.href = 'injuries.html';
            }

            document.querySelectorAll('a[href="#injury-form"]').forEach(a => a.addEventListener('click', function(e) {
                e.preventDefault();
                window.location.href = 'injuries.html';
            }));

            const closeInjury = document.getElementById('closeInjury');
            if (closeInjury) {
                closeInjury.addEventListener('click', function() {
                    if (injuryFormSection) {
                        injuryFormSection.style.display = 'none';
                        history.replaceState(null, '', window.location.pathname);
                    }
                });
            }

            const demoInjuryForm = document.getElementById('demoInjuryForm');
            if (demoInjuryForm) {
                demoInjuryForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    alert('تم حفظ بيانات الإصابة (عرض تجريبي)');
                    if (injuryFormSection) {
                        injuryFormSection.style.display = 'none';
                        history.replaceState(null, '', window.location.pathname);
                    }
                    this.reset();
                });
            }

            if (searchInput && grid) {
                searchInput.addEventListener('input', function() {
                    const query = searchInput.value.trim().toLowerCase();
                    Array.from(grid.children).forEach(card => {
                        const text = (card.innerText || '').toLowerCase();
                        card.style.display = text.includes(query) ? 'block' : 'none';
                    });
                });
            }
            
            // تحميل طلبات المستخدم
            this.loadUserRequests();
            
            // تهيئة نافذة تقديم الطلب
            this.initAddRequestModal();
            
            // معالج زر تسجيل الخروج
            const logoutBtn = document.getElementById('logoutBtn');
            if (logoutBtn) {
                logoutBtn.addEventListener('click', () => {
                    sessionStorage.removeItem('eventsLoggedInUserId');
                    sessionStorage.removeItem('eventsLoggedInUserName');
                    this.showToast('تم تسجيل الخروج بنجاح', true);
                    setTimeout(() => {
                        window.location.href = 'index.html';
                    }, 1000);
                });
            }
        },

        async loadUserRequests() {
            const userId = sessionStorage.getItem('eventsLoggedInUserId');
            const userName = sessionStorage.getItem('eventsLoggedInUserName');
            
            if (!userId) {
                console.error('No user logged in for events');
                return;
            }
            
            try {
                const result = await this.apiCall({
                    action: 'getUserRequests',
                    userId: userId
                });
                
                if (result?.success && result.requests) {
                    this.displayUserRequests(result.requests, userName);
                } else {
                    console.error('Failed to load user requests:', result?.message);
                    this.displayUserRequests([], userName);
                }
            } catch (error) {
                console.error('Error loading user requests:', error);
                this.displayUserRequests([], userName);
            }
        },
        
        displayUserRequests(requests, userName) {
            // العثور على الجدول في صفحة wounded-form.html
            const tableBody = document.querySelector('#eventsTable tbody');
            if (!tableBody) {
                console.error('Events table not found');
                return;
            }
            
            // مسح الجدول الحالي
            tableBody.innerHTML = '';
            
            if (requests.length === 0) {
                // عرض رسالة عدم وجود طلبات
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td colspan="6" class="text-center py-4 text-muted">
                        <i class="fas fa-info-circle mb-2"></i><br>
                        لا توجد طلبات مقدمة حتى الآن
                    </td>
                `;
                tableBody.appendChild(row);
                return;
            }
            
            // عرض الطلبات
            requests.forEach(request => {
                const row = document.createElement('tr');
                
                // تحديد لون الحالة
                const statusClass = this.getStatusClass(request['حالة الطلب']);
                const statusIcon = this.getStatusIcon(request['حالة الطلب']);
                
                row.innerHTML = `
                    <td>${request['معرف الطلب'] || '-'}</td>
                    <td>
                        <strong>${request['نوع الطلب'] || '-'}</strong><br>
                        <small class="text-muted">${request['عنوان الطلب'] || '-'}</small>
                    </td>
                    <td>
                        <small>${this.formatDate(request['تاريخ التقديم'])}</small>
                    </td>
                    <td>
                        <span class="badge ${statusClass}">
                            <i class="${statusIcon}"></i>
                            ${request['حالة الطلب'] || 'قيد المراجعة'}
                        </span>
                    </td>
                    <td>
                        ${request['ملاحظات الإدارة'] || '-'}
                        ${request['اسم المراجع'] ? `<br><small class="text-muted">بواسطة: ${request['اسم المراجع']}</small>` : ''}
                    </td>
                    <td>
                        <button class="btn btn-sm btn-outline-primary" onclick="App.showRequestDetails('${request['معرف الطلب']}')">
                            <i class="fas fa-eye"></i> عرض
                        </button>
                    </td>
                `;
                tableBody.appendChild(row);
            });
        },
        
        getStatusClass(status) {
            switch (status) {
                case 'مقبول': return 'bg-success';
                case 'مرفوض': return 'bg-danger';
                case 'قيد المراجعة': return 'bg-warning';
                case 'يحتاج تعديل': return 'bg-info';
                default: return 'bg-secondary';
            }
        },
        
        getStatusIcon(status) {
            switch (status) {
                case 'مقبول': return 'fas fa-check';
                case 'مرفوض': return 'fas fa-times';
                case 'قيد المراجعة': return 'fas fa-clock';
                case 'يحتاج تعديل': return 'fas fa-edit';
                default: return 'fas fa-question';
            }
        },
        
        formatDate(dateString) {
            if (!dateString) return '-';
            try {
                const date = new Date(dateString);
                return date.toLocaleDateString('ar-EG', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric'
                });
            } catch (error) {
                return dateString;
            }
        },
        
        showRequestDetails(requestId) {
            // يمكن تطوير هذه الدالة لعرض تفاصيل أكثر للطلب
            this.showToast(`عرض تفاصيل الطلب رقم: ${requestId}`, true);
        },

        // التعامل مع نافذة تقديم الطلب الجديد
        initAddRequestModal() {
            const addRequestBtn = document.getElementById('addRequestBtn');
            const addRequestModal = document.getElementById('addRequestModal');
            const addRequestForm = document.getElementById('addRequestForm');
            
            if (addRequestBtn && addRequestModal) {
                this.addRequestModal = new bootstrap.Modal(addRequestModal);
                
                addRequestBtn.addEventListener('click', () => {
                    this.addRequestModal.show();
                });
                
                if (addRequestForm) {
                    addRequestForm.addEventListener('submit', (e) => this.handleAddRequest(e));
                }
            }
        },
        
        async handleAddRequest(e) {
            e.preventDefault();
            
            const userId = sessionStorage.getItem('eventsLoggedInUserId');
            if (!userId) {
                this.showToast('يجب تسجيل الدخول أولاً', false);
                return;
            }
            
            const form = e.target;
            const formData = new FormData(form);
            
            const requestData = {
                action: 'addUserRequest',
                userId: userId,
                requestType: form.querySelector('#requestType').value,
                title: form.querySelector('#requestTitle').value,
                details: form.querySelector('#requestDetails').value,
                attachments: '' // يمكن تطوير رفع الملفات لاحقاً
            };
            
            // التحقق من البيانات المطلوبة
            if (!requestData.requestType || !requestData.title || !requestData.details) {
                this.showToast('يرجى ملء جميع الحقول المطلوبة', false);
                return;
            }
            
            const btn = form.querySelector('button[type="submit"]');
            this.toggleButtonSpinner(true, btn);
            
            try {
                const result = await this.apiCall(requestData, true);
                
                if (result?.success) {
                    this.showToast('تم تقديم الطلب بنجاح! ستتم مراجعته من قبل الإدارة.', true);
                    this.addRequestModal.hide();
                    form.reset();
                    
                    // إعادة تحميل الطلبات لإظهار الطلب الجديد
                    setTimeout(() => {
                        this.loadUserRequests();
                    }, 1000);
                } else {
                    this.showToast(result?.message || 'فشل في تقديم الطلب', false);
                }
            } catch (error) {
                console.error('Error submitting request:', error);
                this.showToast('حدث خطأ أثناء تقديم الطلب', false);
            } finally {
                this.toggleButtonSpinner(false, btn);
            }
        },

        initDashboardPage() { const userId = localStorage.getItem('loggedInUserId'); if (!userId) { window.location.href = 'index.html'; return; } this.loadUserData(userId); },
        async handleUserLogin(e) { 
            e.preventDefault(); 
            const form = e.target; 
            const userId = form.querySelector('#userId').value.trim(); 
            const spouseId = form.querySelector('#spouseId').value.trim(); 
            const errorBox = document.getElementById('loginError');
            errorBox?.classList.add('d-none');
            if (!userId || !spouseId) {
                if (errorBox) { errorBox.textContent = 'يرجى إدخال رقم الهوية وهوية الزوجة (أو 0 للحالات الخاصة).'; errorBox.classList.remove('d-none'); }
                return;
            }
            const btn = form.querySelector('button[type="submit"]');
            this.toggleButtonSpinner(true, btn);
            const result = await this.apiCall({ action: 'checkPasswordStatus', id: userId, spouse_id: spouseId });
            this.toggleButtonSpinner(false, btn);
            if (!result) {
                if (errorBox) { errorBox.textContent = 'فشل التحقق. تحقق من البيانات أو حاول لاحقاً.'; errorBox.classList.remove('d-none'); }
                return;
            }
            // حالات النجاح
            if (result.message === 'password_required') {
                // إظهار نافذة إعداد كلمة المرور
                document.getElementById('modalUserId').value = userId;
                this.userLoginModal.hide();
                this.setPasswordModal.show();
                return;
            }
            if (result.message === 'password_exists') {
                document.getElementById('loginModalUserId').value = userId;
                document.getElementById('loginModalSpouseId').value = spouseId;
                this.userLoginModal.hide();
                this.loginPasswordModal.show();
                return;
            }
            // أخطاء محتملة
            let msg = 'تعذر إتمام التحقق. تأكد من صحة البيانات.';
            const m = (result.message || '').toLowerCase();
            if (m.includes('not') && m.includes('found')) msg = 'لم يتم العثور على حساب بهذه البيانات. تأكد من رقم الهوية. إذا كانت الحالة أرملة / مطلقة ضع 0 في خانة هوية الزوجة.';
            else if (m.includes('spouse') || m.includes('زوج')) msg = 'رقم هوية الزوجة غير مطابق. إذا كانت الحالة أرملة / مطلقة ضع 0.';
            if (errorBox) { errorBox.textContent = msg; errorBox.classList.remove('d-none'); }
        },
        async handleModalSetPassword(e) {
            e.preventDefault();
            const userId = document.getElementById('modalUserId').value;
            const newPassword = document.getElementById('modalNewPassword').value;
            const confirmPassword = document.getElementById('modalConfirmPassword').value;
            if (newPassword !== confirmPassword) {
                this.showToast('كلمة المرور وتأكيدها غير متطابقين.', false);
                return;
            }
            if (newPassword.length < 6) {
                this.showToast('كلمة المرور يجب أن لا تقل عن 6 أحرف.', false);
                return;
            }
            const result = await this.apiCall({ action: 'setMemberPassword', userId: userId, password: newPassword }, true);
            if (result) {
                this.setPasswordModal.hide();
                localStorage.setItem('loggedInUserId', userId);
                localStorage.setItem('loggedInUserName', result.userName);
                console.log('✅ تم حفظ loggedInUserId بعد تعيين كلمة المرور:', userId);
                window.location.href = 'dashboard.html';
            }
        },
        async handleModalLogin(e) { 
            e.preventDefault(); 
            const userId = document.getElementById('loginModalUserId').value;
            const spouseId = document.getElementById('loginModalSpouseId').value;
            const password = document.getElementById('loginModalPassword').value;
            const errorBox = document.getElementById('passwordError');
            errorBox?.classList.add('d-none');
            const btn = e.target.querySelector('button[type="submit"]');
            this.toggleButtonSpinner(true, btn);
            const result = await this.apiCall({ action: 'userLoginWithPassword', id: userId, spouse_id: spouseId, password: password });
            this.toggleButtonSpinner(false, btn);
            if (!result) { if (errorBox) { errorBox.textContent = 'تعذر الاتصال بالخادم حالياً.'; errorBox.classList.remove('d-none'); } return; }
            if (!result.success) {
                let msg = result.message || 'بيانات الدخول غير صحيحة.';
                const m = msg.toLowerCase();
                if (m.includes('password') || m.includes('كلمة')) msg = 'كلمة المرور غير صحيحة.';
                else if (m.includes('spouse')) msg = 'رقم هوية الزوجة غير صحيح أو لا يطابق السجلات.';
                else if (m.includes('not') && m.includes('found')) msg = 'لم يتم العثور على الحساب.';
                if (errorBox) { errorBox.textContent = msg; errorBox.classList.remove('d-none'); }
                return;
            }
            // نجاح
            this.loginPasswordModal.hide();
            this.showToast(`أهلاً بك، ${result.user_name}`, true);
            localStorage.setItem('loggedInUserId', result.user_id);
            localStorage.setItem('loggedInUserName', result.user_name);
            setTimeout(() => { window.location.href = 'dashboard.html'; }, 800);
        },
    async handleAdminLogin(e) { 
        e.preventDefault(); 
        if (this.adminLoginModal) try { this.adminLoginModal.hide(); } catch(_){}
        const result = await this.apiCall({ action: 'adminLogin', username: document.getElementById('username').value, password: document.getElementById('password').value }); 
        if (result) {
            this.showToast("تم تسجيل الدخول بنجاح.", true);
            sessionStorage.setItem('adminToken', result.token);
            sessionStorage.setItem('adminRole', result.role);
            // Redirect to superadmin page when role indicates super admin, otherwise to the regular admin page
            if (result.role === 'superadmin') {
                window.location.href = 'superadmin.html';
            } else {
                window.location.href = 'admin.html';
            }
        }
    },
        async handleForgotPassword(e) { e.preventDefault(); this.loginPasswordModal.hide(); this.forgotPasswordModal.show(); },
        
        // دوال التعامل مع تسجيل الدخول للأحداث الحياتية
        async handleEventsLogin(e) {
            e.preventDefault();
            const form = e.target;
            const userId = form.querySelector('#eventsUserId').value.trim();
            const password = form.querySelector('#eventsPassword').value.trim();
            const errorBox = document.getElementById('eventsLoginError');
            
            errorBox?.classList.add('d-none');
            
            if (!userId || !password) {
                if (errorBox) {
                    errorBox.textContent = 'يرجى إدخال رقم الهوية وكلمة المرور.';
                    errorBox.classList.remove('d-none');
                }
                return;
            }
            
            const btn = form.querySelector('button[type="submit"]');
            this.toggleButtonSpinner(true, btn);
            
            // التحقق من كلمة المرور للأحداث الحياتية
            const result = await this.apiCall({ 
                action: 'eventsLoginWithPassword', 
                id: userId, 
                password: password 
            });
            this.toggleButtonSpinner(false, btn);
            
            if (!result || !result.success) {
                let msg = 'بيانات الدخول غير صحيحة أو لا يوجد حساب بهذه البيانات.';
                if (result?.message) {
                    const m = result.message.toLowerCase();
                    if (m.includes('password') || m.includes('كلمة')) {
                        msg = 'كلمة المرور غير صحيحة.';
                    } else if (m.includes('not') && m.includes('found') || m.includes('لم يتم العثور')) {
                        msg = 'لم يتم العثور على حساب بهذا الرقم.';
                    } else if (m.includes('تعيين') || m.includes('إنشاء') || m.includes('مساحتك')) {
                        msg = 'لم يتم إنشاء كلمة مرور لهذا الحساب بعد. يرجى الذهاب لـ "مساحتك الخاصة في العائلة" لإنشاء كلمة مرور.';
                    }
                }
                if (errorBox) {
                    errorBox.textContent = msg;
                    errorBox.classList.remove('d-none');
                }
                return;
            }
            
            // نجح تسجيل الدخول - التوجه لصفحة الأحداث
            this.eventsLoginModal.hide();
            this.showToast(`أهلاً بك، ${result.user_name}. جاري التوجه لسجل الأحداث...`, true);
            
            // حفظ بيانات المستخدم
            sessionStorage.setItem('eventsLoggedInUserId', result.user_id);
            sessionStorage.setItem('eventsLoggedInUserName', result.user_name);
            
            setTimeout(() => {
                window.location.href = 'wounded-form.html';
            }, 1200);
            sessionStorage.setItem('eventsLoggedInUserName', result.user_name);
            
            setTimeout(() => {
                window.location.href = 'wounded-form.html';
            }, 1200);
        },
        
        goToUserArea(e) {
            e.preventDefault();
            this.eventsCreatePasswordModal.hide();
            this.eventsLoginModal.hide();
            
            // عرض نافذة "مساحتك الخاصة في العائلة"
            setTimeout(() => {
                this.userLoginModal.show();
            }, 300);
        },
        
        async handleEventsForgotPassword(e) {
            e.preventDefault();
            const form = e.target;
            const userId = form.querySelector('#eventsForgotPasswordUserId').value.trim();
            const reason = form.querySelector('#eventsForgotPasswordReason').value.trim();
            
            if (!userId) {
                this.showToast('يرجى إدخال رقم الهوية.', false);
                return;
            }
            
            const btn = form.querySelector('button[type="submit"]');
            this.toggleButtonSpinner(true, btn);
            
            const result = await this.apiCall({ 
                action: 'requestPasswordReset', 
                userId: userId,
                reason: reason || 'طلب استعادة كلمة المرور من سجل الأحداث الحياتية'
            }, true);
            
            this.toggleButtonSpinner(false, btn);
            
            if (result) {
                this.eventsForgotPasswordModal.hide();
                this.showToast('تم إرسال طلب استعادة كلمة المرور بنجاح. ستتم مراجعته من قبل الإدارة.', true);
            }
        },
        
        showEventsCreatePassword(e) {
            e.preventDefault();
            this.eventsLoginModal.hide();
            this.eventsCreatePasswordModal.show();
        },
        
        showEventsForgotPassword(e) {
            e.preventDefault();
            this.eventsLoginModal.hide();
            this.eventsForgotPasswordModal.show();
        },
        
        // محاولة عرض مبكر لأي مجموعة بيانات باستخدام الكاش المستمر
        _tryEarlyRender(action, payload, accessorFn, renderFn) {
            try {
                const key = this.getCacheKey(action, { action, ...payload });
                const persisted = this.getPersistentCache(key);
                if (persisted && accessorFn(persisted)) {
                    console.log(`⚡ عرض مبكر من الكاش: ${action}`);
                    renderFn(accessorFn(persisted));
                    return true;
                }
            } catch (e) { /* ignore */ }
            return false;
        },

        async loadDashboardData(userId, { fast = true, force = false } = {}) {
            if (!userId) return;
            if (this._loadingDashboard && !force) {
                console.log('⏳ تجاهل طلب تحميل جديد، ما زال السابق قيد التنفيذ');
                return;
            }
            this._loadingDashboard = true;
            const startTs = performance.now();

            // إذا كان تحديث إجباري احذف الكاشات المتعلقة بالمستخدم
            if (force) {
                try {
                    const actions = ['getUserData','getUserAidHistory','getUserFutureAid'];
                    actions.forEach(a => {
                        const key = this.getCacheKey(a, { action: a, userId });
                        this.cache.delete(key);
                        try { localStorage.removeItem(this._buildPersistentKey(key)); } catch {}
                    });
                    console.log('♻️ تم مسح كاش لوحة التحكم (تحديث إجباري)');
                } catch(e) { console.warn('Failed clearing dashboard cache', e); }
            }

            // Skeleton placeholders (في حال كانت الجداول فارغة)
            const injectSkeleton = (id, cols = 4, rows = 2) => {
                const body = document.getElementById(id);
                if (!body) return;
                if (body.dataset.filled) return; // لا تعيد الكتابة إذا تم ملؤه
                const skeletonRow = `<tr class="placeholder-glow">${'<td><span class=\"placeholder col-8\"></span></td>'.repeat(cols)}</tr>`;
                body.innerHTML = Array.from({ length: rows }).map(()=>skeletonRow).join('');
            };
            injectSkeleton('aidHistoryTableBody');
            injectSkeleton('futureAidTableBody');

            // عرض مبكر لكل قسم من الكاش إن وجد
            if (!force) {
                this._tryEarlyRender('getUserData', { userId }, r => r.data, d => this.renderUserInfo(d));
                this._tryEarlyRender('getUserAidHistory', { userId }, r => r.data, d => {
                    this.allUserAidHistory = d.sort((a, b) => new Date(b['تاريخ الاستلام']) - new Date(a['تاريخ الاستلام']));
                    this.renderAidHistoryWithPagination();
                });
                this._tryEarlyRender('getUserFutureAid', { userId }, r => r.data, d => {
                    this.allUserFutureAid = d.sort((a, b) => new Date(b['تاريخ الاستلام المتوقع'] || b['تاريخ الاستلام']) - new Date(a['تاريخ الاستلام المتوقع'] || a['تاريخ الاستلام']));
                    this.renderFutureAidWithPagination();
                });
            }
            // الإشعارات (ليس لها ريندر خاص هنا في الصفحة لكن قد يحدث تحديث خارجي)

            // جلب متوازي
            const useCache = !force;
            const usePersistent = !force;
            const backgroundRefresh = !force;
            const promises = [
                this.apiCall({ action: 'getUserData', userId }, false, useCache, usePersistent, backgroundRefresh),
                this.apiCall({ action: 'getUserAidHistory', userId }, false, useCache, usePersistent, backgroundRefresh),
                this.apiCall({ action: 'getUserFutureAid', userId }, false, useCache, usePersistent, backgroundRefresh),
                this.apiCall({ action: 'getFamilyMembers', userId }, false, useCache, usePersistent, backgroundRefresh), // Fetch family members
                fast ? Promise.resolve(null) : this.getUserNotifications(userId)
            ];

            try {
                const [userDataResult, aidHistoryResult, futureAidResult, familyMembersResult, notificationsResult] = await Promise.all(promises);
                
                // تشخيص البيانات المستلمة من الخادم
                console.log('📡 البيانات المستلمة من getUserData:', userDataResult);
                console.log('📡 البيانات الفعلية:', userDataResult?.data);
                console.log('📡 المفاتيح المتاحة:', userDataResult?.data ? Object.keys(userDataResult.data) : 'لا توجد بيانات');
                
                if (userDataResult?.data) this.renderUserInfo(userDataResult.data);
                if (aidHistoryResult?.data) {
                    // ترتيب حسب التاريخ (الأحدث أولاً) 
                    this.allUserAidHistory = aidHistoryResult.data.sort((a, b) => new Date(b['تاريخ الاستلام']) - new Date(a['تاريخ الاستلام']));
                    this.userAidHistoryPage = 1;
                    this.renderAidHistoryWithPagination();
                }
                if (futureAidResult?.data) {
                    // ترتيب حسب التاريخ (الأحدث أولاً)
                    this.allUserFutureAid = futureAidResult.data.sort((a, b) => new Date(b['تاريخ الاستلام المتوقع'] || b['تاريخ الاستلام']) - new Date(a['تاريخ الاستلام المتوقع'] || a['تاريخ الاستلام']));
                    this.userFutureAidPage = 1;
                    this.renderFutureAidWithPagination();
                }
                if (familyMembersResult?.success && familyMembersResult.familyMembers) {
                    this.renderFamilyMembers(familyMembersResult.familyMembers);
                } else {
                    this.renderFamilyMembers([]); // Show empty state if no family members or error
                }
                if (notificationsResult?.notifications) {
                    // أطلق حدث لتحديث أي واجهة إشعارات مفتوحة
                    document.dispatchEvent(new CustomEvent('user-notifications-loaded', { detail: notificationsResult.notifications }));
                }
            } catch (err) {
                console.error('❌ فشل تحميل بيانات لوحة التحكم:', err);
            } finally {
                this._loadingDashboard = false;
                const dur = (performance.now() - startTs).toFixed(0);
                console.log(`✅ اكتمال تحميل لوحة التحكم في ${dur}ms`);
            }
        },

        // الحفاظ على التوافق مع الاستدعاءات القديمة
        async loadUserData(userId, force = false) {
            return this.loadDashboardData(userId, { fast: !force, force: force });
        },
        // تحديث إجباري يتجاوز الكاش ويجلب البيانات من الخادم
        async refreshDashboard(userId) {
            await this.loadDashboardData(userId, { fast: false, force: true });
            this.showToast('تم التحديث من الخادم', true);
        },
        
    renderUserInfo(data) {
            // Log للتطوير فقط - يمكن إزالته في الإنتاج
            if (window.DEBUG_MODE) {
                console.log('🔍 renderUserInfo - البيانات المستلمة:', data);
                console.log('🔍 جميع مفاتيح البيانات:', Object.keys(data));
                console.log('🔍 جميع قيم البيانات:');
                Object.keys(data).forEach(key => {
                    console.log(`   "${key}": "${data[key]}"`);
                });
                console.log('🔍 الاسم الكامل من البيانات:', data['الاسم الكامل']);
            }
            
            // ✅ الحل النهائي: الاعتماد على مفتاح "الاسم الكامل" من العمود B
            let fullName = data['الاسم الكامل'] ? String(data['الاسم الكامل']).trim() : '';
            
            // إذا كان العمود B فارغاً، ابحث في "اسم صاحب الحساب" كبديل
            if (!fullName || fullName === '') {
                console.warn('⚠️ العمود B (الاسم الكامل) فارغ، البحث في اسم صاحب الحساب...');
                fullName = data['اسم صاحب الحساب'] ? String(data['اسم صاحب الحساب']).trim() : '';
                
                if (fullName && fullName !== '') {
                    console.log(`✅ تم العثور على الاسم في "اسم صاحب الحساب": "${fullName}"`);
                    console.warn('💡 تنبيه: يرجى نسخ هذا الاسم إلى العمود B في Google Sheets');
                }
            } else {
                console.log(`✅ تم العثور على الاسم من العمود B: "${fullName}"`);
            }
            
            // إذا لم يُعثر على اسم في أي من المكانين، استخدم رقم الهوية
            if (!fullName || fullName === '') {
                const idNumber = data['رقم الهوية'] || data['رقم الهويه'];
                fullName = idNumber ? `مستخدم ${idNumber}` : 'عضو العائلة';
                console.log('⚠️ لم يتم العثور على الاسم، استخدام:', fullName);
            }
            
            if (window.DEBUG_MODE) console.log('🔍 الاسم الكامل بعد المعالجة:', fullName);
            
            document.getElementById('userName').textContent = fullName;
            document.getElementById('userTitle').textContent = `رقم الهوية: ${data['رقم الهوية'] || '---'}`;
            
            // حفظ الاسم الكامل في localStorage للاستخدام لاحقاً
            if (fullName && fullName !== 'عضو العائلة') {
                localStorage.setItem('loggedInUserName', fullName);
                if (window.DEBUG_MODE) console.log('✅ تم حفظ الاسم الكامل:', fullName);
            }
            
            // البيانات الشخصية الأساسية
            const basicInfoSection = document.getElementById('basicInfo');
            const basicFields = [
                { key: 'الاسم الكامل', label: 'الاسم الكامل', icon: 'person-fill' },
                { key: 'رقم الهوية', label: 'رقم الهوية', icon: 'person-badge' },
                { key: 'تاريخ الميلاد', label: 'تاريخ الميلاد', icon: 'calendar-event' },
                { key: 'العمر', label: 'العمر', icon: 'hourglass-split' },
                { key: 'الجنس', label: 'الجنس', icon: 'gender-ambiguous' },
                { key: 'الحالة الاجتماعية', label: 'الحالة الاجتماعية', icon: 'heart-fill' }
            ];
            
            basicInfoSection.innerHTML = this.renderInfoSection(basicFields, data);
            
            // بيانات الاتصال والعنوان
            const contactInfoSection = document.getElementById('contactInfo');
            const contactFields = [
                { key: 'رقم الهاتف', label: 'رقم الهاتف', icon: 'telephone-fill' },
                { key: 'رقم جوال بديل', label: 'رقم جوال بديل', icon: 'phone' },
                { key: 'البريد الإلكتروني', label: 'البريد الإلكتروني', icon: 'envelope-fill' },
                { key: 'العنوان', label: 'العنوان', icon: 'house-fill' },
                { key: 'مكان النزوح الحالي', label: 'مكان النزوح الحالي', icon: 'geo-alt' },
                { key: 'الفرع', label: 'الفرع', icon: 'diagram-3' },
                { key: 'رقم الواتساب', label: 'رقم الواتساب', icon: 'whatsapp' }
                // removed 'المدينة' و 'المحافظة' per request
            ];
            
            contactInfoSection.innerHTML = this.renderInfoSection(contactFields, data);
            
            // بيانات العمل والتعليم
            const workEducationSection = document.getElementById('workEducationInfo');
            const workEducationFields = [
                { key: 'المهنة', label: 'المهنة', icon: 'briefcase-fill' },
                { key: 'مكان العمل', label: 'مكان العمل', icon: 'building-gear' },
                { key: 'الحالة المهنية', label: 'الحالة المهنية', icon: 'person-workspace' },
                { key: 'المؤهل العلمي', label: 'المؤهل العلمي', icon: 'mortarboard-fill' },
                { key: 'التخصص', label: 'التخصص', icon: 'journal-bookmark-fill' }
            ];
            
            workEducationSection.innerHTML = this.renderInfoSection(workEducationFields, data);
            
            // بيانات العائلة
            const familyInfoSection = document.getElementById('familyInfo');
            const familyFields = [
                // removed 'اسم الزوج' per UX request
                { key: 'اسم الزوجة', label: 'اسم الزوجة', icon: 'person-heart' },
                { key: 'تاريخ ميلاد الزوجة', label: 'تاريخ ميلاد الزوجة', icon: 'calendar-heart' },
                // removed 'رقم هوية الزوج' per UX request
                { key: 'رقم هوية الزوجة', label: 'رقم هوية الزوجة', icon: 'person-badge-fill' },
                { key: 'عدد أفراد الأسرة', label: 'عدد أفراد الأسرة', icon: 'people-fill' },
                { key: 'معرف العائلة', label: 'معرف العائلة', icon: 'hash' }
                // removed 'عدد الأطفال الذكور' و 'عدد الأطفال الإناث' per request
            ];
            
            familyInfoSection.innerHTML = this.renderInfoSection(familyFields, data);
            
            // المعلومات البنكية
            const bankingInfoSection = document.getElementById('bankingInfo');
            const bankingFields = [
                { key: 'البنك', label: 'البنك', icon: 'bank2' },
                { key: 'رقم الحساب البنكي', label: 'رقم الحساب / رقم الجوال', icon: 'credit-card-2-front-fill' },
                { key: 'اسم صاحب الحساب', label: 'اسم صاحب الحساب', icon: 'person-check-fill' }
            ];
            
            if (bankingInfoSection) {
                bankingInfoSection.innerHTML = this.renderInfoSection(bankingFields, data);
            }
            
            // ملء نموذج التعديل بالبيانات الحالية
            this.populateEditForm(data);

            // تفعيل التعديل الفوري داخل البطاقات
            try { this.enableInlineEditing(); } catch(_){}
        },
        
        renderInfoSection(fields, data) {
                // حقول غير قابلة للتعديل من الواجهة الأمامية
                const FRONTEND_READONLY_FIELDS = new Set([
                    'الاسم الكامل',
                    'رقم الهوية',
                    'العمر',
                    'الجنس',
                    'الحالة الاجتماعية',
                    'اسم الزوجة',
                    'رقم هوية الزوجة',
                    'عدد أفراد الأسرة',
                    'معرف العائلة'
                    // عدد الأطفال الذكور وعدد الأطفال الإناث الآن قابلة للتعديل
                ]);
                const getFieldValue = (dataObj, key) => {
                    if (!dataObj) return '-';
                    const val = (dataObj[key] !== undefined && dataObj[key] !== null && String(dataObj[key]).toString().trim() !== '') ? dataObj[key] : null;
                    if (val) return val;

                    // synonyms mapping
                    const synonyms = {
                        'تاريخ الميلاد': ['تاريخ الميلاد', 'birth_date', 'birthdate', 'DOB'],
                        'تاريخ ميلاد الزوجة': ['تاريخ ميلاد الزوجة', 'تاريخ ميلاد الزوجه', 'wife_birth_date'],
                        'العمر': ['العمر', 'age'],
                        'الجنس': ['الجنس', 'النوع', 'gender'],
                        'عدد الأطفال الذكور': ['عدد الأطفال الذكور', 'عدد الذكور', 'عدد ذكور'],
                        'عدد الأطفال الإناث': ['عدد الأطفال الإناث', 'عدد الإناث', 'عدد الاناث', 'عدد اناث'],
                        'رقم الهاتف': ['رقم الهاتف', 'رقم الجوال', 'رقم الهاتف المحمول', 'الهاتف'],
                        'رقم الجوال': ['رقم الجوال', 'رقم الهاتف', 'رقم الهاتف المحمول', 'الهاتف'],
                        'رقم هاتف بديل': ['رقم هاتف بديل', 'رقم جوال بديل', 'الهاتف البديل'],
                        'رقم جوال بديل': ['رقم جوال بديل', 'رقم هاتف بديل', 'الهاتف البديل'],
                        'العنوان': ['العنوان', 'مكان الإقامة', 'address'],
                        'مكان الإقامة': ['مكان الإقامة', 'العنوان', 'residence']
                    };

                    const keysToTry = synonyms[key] || [key];
                    for (const k of keysToTry) {
                        if (dataObj[k] !== undefined && dataObj[k] !== null && String(dataObj[k]).toString().trim() !== '') return dataObj[k];
                    }
                    return '-';
                };

                return fields.map(field => {
                    let value = getFieldValue(data, field.key);
                    
                    // تشخيص للتطوير فقط
                    if (window.DEBUG_MODE && field.key === 'الاسم الكامل') {
                        console.log('🔍 تشخيص عرض الاسم الكامل في البطاقة:');
                        console.log('   القيمة من getFieldValue:', value);
                        console.log('   البيانات الأصلية:', data);
                        console.log('   data["الاسم الكامل"]:', data['الاسم الكامل']);
                    }
                    
                    if ((field.key === 'تاريخ الميلاد' || field.key === 'تاريخ الميلاد') && value !== '-') {
                        try { value = this.formatDateToEnglish(value); } catch (e) { /* ignore */ }
                    }

                    // Inline edit affordance: include a small pencil button and data-field-key for handlers
                    const readOnly = FRONTEND_READONLY_FIELDS.has(field.key);
                    const controls = readOnly
                        ? `<span class="ms-2 small text-muted" title="غير قابل للتعديل"><i class="bi bi-lock-fill"></i></span>`
                        : `<button type="button" class="btn btn-outline-primary btn-sm inline-edit-btn" title="تعديل" data-field-key="${field.key}">
                                <i class="bi bi-pencil-square me-1"></i> <span>تعديل</span>
                           </button>`;

                    return `
                        <div class="col-md-6 col-lg-4 mb-3">
                            <div class="info-item">
                                <i class="bi bi-${field.icon} info-icon"></i>
                                <span class="info-label">${field.label}</span>
                                <div class="info-value" data-field-key="${field.key}">
                                    <span class="value-text">${value}</span>
                                    ${controls}
                                </div>
                            </div>
                        </div>
                    `;
                }).join('');
        },
        
        populateEditForm(data) {
            // ملء نموذج التعديل بالبيانات الحالية
            const editFields = {
                'editPhone': 'رقم الهاتف',
                'editEmail': 'البريد الإلكتروني', 
                'editAddress': 'العنوان',
                'editCity': 'المدينة',
                'editProvince': 'المحافظة',
                'editAltPhone': 'رقم هاتف بديل',
                'editProfession': 'المهنة',
                'editWorkPlace': 'مكان العمل',
                'editEducation': 'المؤهل العلمي',
                'editFamilySize': 'عدد أفراد الأسرة',
                'editFamilyId': 'معرف العائلة',
                'editBank': 'البنك',
                'editAccountNumber': 'رقم الحساب البنكي',
                'editAccountHolderName': 'اسم صاحب الحساب'
            };
            
            for (const [fieldId, dataKey] of Object.entries(editFields)) {
                const element = document.getElementById(fieldId);
                if (element) {
                    element.value = data[dataKey] || '';
                }
            }
                        // إعادة تفعيل زر تعديل البيانات بعد تحديث البيانات
                        setTimeout(() => {
                            const editBtn = document.getElementById('editUserDataBtn');
                            if (editBtn) {
                                editBtn.onclick = function() {
                                    document.getElementById('editPhoneModal').value = document.getElementById('contactPhone')?.textContent || '';
                                    let birthValue = '-';
                                    const birthEl = Array.from(document.querySelectorAll('.info-label')).find(e => e.textContent.includes('تاريخ الميلاد'));
                                    if (birthEl) {
                                        birthValue = birthEl.nextElementSibling?.textContent || '';
                                    }
                                    document.getElementById('editBirthModal').value = birthValue !== '-' ? birthValue : '';
                                    document.getElementById('editLocationModal').value = document.getElementById('contactLocation')?.textContent || '';
                                    const modal = new bootstrap.Modal(document.getElementById('editUserDataModal'));
                                    modal.show();
                                };
                            }
                            const saveBtn = document.getElementById('saveUserDataBtn');
                            if (saveBtn) {
                                saveBtn.onclick = function() {
                                    document.getElementById('contactPhone').textContent = document.getElementById('editPhoneModal').value;
                                    document.getElementById('contactLocation').textContent = document.getElementById('editLocationModal').value;
                                    let birthValue = document.getElementById('editBirthModal').value;
                                    const birthEl = Array.from(document.querySelectorAll('.info-label')).find(e => e.textContent.includes('تاريخ الميلاد'));
                                    if (birthEl && birthEl.nextElementSibling) {
                                        birthEl.nextElementSibling.textContent = birthValue;
                                    }
                                    const modal = bootstrap.Modal.getInstance(document.getElementById('editUserDataModal'));
                                    modal.hide();
                                    App.showToast('تم تعديل البيانات بنجاح!', true);
                                };
                            }
                        }, 100);
        },

        // Enable in-line editing on rendered info sections (basic, contact, work/edu, family, banking)
        enableInlineEditing() {
            const userId = localStorage.getItem('loggedInUserId');
            if (!userId) return;

            const READONLY_BLOCK = new Set([
                'الاسم الكامل','رقم الهوية','العمر','الجنس','الحالة الاجتماعية','اسم الزوجة','رقم هوية الزوجة','عدد أفراد الأسرة','معرف العائلة','عدد الأطفال الذكور','عدد الأطفال الإناث'
            ]);

            const containers = ['basicInfo','contactInfo','workEducationInfo','familyInfo','bankingInfo']
                .map(id => document.getElementById(id))
                .filter(Boolean);

            // Event delegation per container to keep it light
            containers.forEach(container => {
                if (container._inlineEditBound) return; // prevent double-binding
                container.addEventListener('click', async (e) => {
                    const btn = e.target.closest('.inline-edit-btn');
                    if (!btn) return;

                    const fieldKey = btn.getAttribute('data-field-key');
                    if (READONLY_BLOCK.has(fieldKey)) {
                        // تجاهل التحرير لهذه الحقول
                        if (typeof App?.showToast === 'function') {
                            App.showToast('هذا الحقل غير قابل للتعديل', false);
                        }
                        return;
                    }
                    const valueWrap = btn.closest('.info-value');
                    const infoItem = btn.closest('.info-item');
                    const valueSpan = valueWrap.querySelector('.value-text');
                    const original = (valueSpan?.textContent || '').trim();

                    // Build editor UI - حالات خاصة للحقول ذات القوائم المنسدلة
                    let input;
                    if (fieldKey === 'الفرع') {
                        // قائمة منسدلة للفرع
                        input = document.createElement('select');
                        input.className = 'form-select form-select-sm';
                        input.innerHTML = `
                            <option value="">اختر الفرع</option>
                            <option value="ال حامد">ال حامد</option>
                            <option value="ال احمد">ال احمد</option>
                            <option value="ال حماد">ال حماد</option>
                            <option value="ال حمدان">ال حمدان</option>
                        `;
                        input.value = original === '-' ? '' : original;
                    } else if (fieldKey === 'البنك') {
                        // قائمة منسدلة للبنك
                        input = document.createElement('select');
                        input.className = 'form-select form-select-sm';
                        input.innerHTML = `
                            <option value="">اختر البنك</option>
                            <option value="البنك الوطني الإسلامي">البنك الوطني الإسلامي</option>
                            <option value="بنك فلسطين">بنك فلسطين</option>
                            <option value="البنك العربي">البنك العربي</option>
                            <option value="بنك الإسكان للتجارة والتمويل">بنك الإسكان للتجارة والتمويل</option>
                            <option value="محفظة جوال باي">محفظة جوال باي</option>
                            <option value="محفظة بال باي">محفظة بال باي</option>
                            <option value="أخرى">أخرى</option>
                        `;
                        input.value = original === '-' ? '' : original;
                    } else if (fieldKey === 'المحافظة') {
                        // قائمة منسدلة للمحافظة
                        input = document.createElement('select');
                        input.className = 'form-select form-select-sm';
                        input.innerHTML = `
                            <option value="">اختر المحافظة</option>
                            <option value="غزة">غزة</option>
                            <option value="الشمال">شمال غزة</option>
                            <option value="الوسطى">الوسطى</option>
                            <option value="خانيونس">خان يونس</option>
                            <option value="رفح">رفح</option>
                        `;
                        input.value = original === '-' ? '' : original;
                    } else if (fieldKey === 'الحالة المهنية') {
                        // قائمة منسدلة للحالة المهنية
                        input = document.createElement('select');
                        input.className = 'form-select form-select-sm';
                        input.innerHTML = `
                            <option value="">اختر الحالة</option>
                            <option value="يعمل">يعمل</option>
                            <option value="لا يعمل">لا يعمل</option>
                            <option value="متقاعد">متقاعد</option>
                            <option value="طالب">طالب</option>
                            <option value="ربة منزل">ربة منزل</option>
                        `;
                        input.value = original === '-' ? '' : original;
                    } else if (fieldKey === 'المؤهل العلمي') {
                        // قائمة منسدلة للمؤهل العلمي
                        input = document.createElement('select');
                        input.className = 'form-select form-select-sm';
                        input.innerHTML = `
                            <option value="">اختر المؤهل</option>
                            <option value="ابتدائية">ابتدائية</option>
                            <option value="إعدادية">إعدادية</option>
                            <option value="ثانوية عامة">ثانوية عامة</option>
                            <option value="دبلوم">دبلوم</option>
                            <option value="بكالوريوس">بكالوريوس</option>
                            <option value="ماجستير">ماجستير</option>
                            <option value="دكتوراه">دكتوراه</option>
                        `;
                        input.value = original === '-' ? '' : original;
                    } else {
                        // حقل إدخال عادي
                        input = document.createElement('input');
                        input.className = 'form-control form-control-sm';
                        input.value = original === '-' ? '' : original;
                        // Special cases: date, phone, email, number
                        if (/تاريخ/.test(fieldKey)) input.type = 'date';
                        else if (/الهاتف|الجوال|واتساب/.test(fieldKey)) input.type = 'tel';
                        else if (/البريد/.test(fieldKey)) input.type = 'email';
                        else if (/عدد|العمر|الدخل|رقم/.test(fieldKey) && !/هوية|حساب/.test(fieldKey)) {
                            input.type = 'number';
                            input.min = '0';
                            input.step = '1';
                        }
                        else input.type = 'text';
                    }
                    
                    input.dir = 'rtl';
                    input.style.maxWidth = '100%';

                    const actions = document.createElement('div');
                    actions.className = 'inline-actions d-flex gap-2 mt-2';
                    actions.style.width = '100%';
                    
                    const saveBtn = document.createElement('button');
                    saveBtn.type = 'button';
                    saveBtn.className = 'btn btn-success inline-action-save';
                    saveBtn.innerHTML = '<i class="bi bi-check2 me-1"></i><span class="btn-label">حفظ</span>';
                    // تحسين للموبايل - زر كامل العرض
                    saveBtn.style.flex = '1';
                    saveBtn.style.minHeight = '52px';
                    saveBtn.style.fontSize = '18px';
                    saveBtn.style.fontWeight = 'bold';
                    saveBtn.style.width = '100%';
                    
                    actions.appendChild(saveBtn);

                    // Replace content
                    valueWrap.innerHTML = '';
                    valueWrap.appendChild(input);
                    valueWrap.appendChild(actions);
                    if (infoItem) { infoItem.classList.add('editing-inline-active'); }
                    input.focus();
                    try { if (window.innerWidth <= 576 && infoItem) { infoItem.scrollIntoView({ behavior: 'smooth', block: 'center' }); } } catch {}

                    const restore = (newVal = null) => {
                        valueWrap.innerHTML = '';
                        const span = document.createElement('span');
                        span.className = 'value-text';
                        span.textContent = (newVal && newVal !== '') ? newVal : (original || '-');
                        const pencil = document.createElement('button');
                        pencil.type = 'button';
                        pencil.className = 'btn btn-outline-primary btn-sm inline-edit-btn';
                        pencil.title = 'تعديل';
                        pencil.setAttribute('aria-label', 'تعديل');
                        pencil.setAttribute('data-field-key', fieldKey);
                        pencil.innerHTML = '<i class="bi bi-pencil-square me-1"></i><span>تعديل</span>';
                        valueWrap.setAttribute('data-field-key', fieldKey);
                        valueWrap.append(span, pencil);
                        if (infoItem) { infoItem.classList.remove('editing-inline-active'); }
                    };

                    // إمكانية الإلغاء بالضغط خارج الحقل أو ESC
                    input.addEventListener('keydown', (e) => {
                        if (e.key === 'Escape') restore();
                    });

                    saveBtn.addEventListener('click', async () => {
                        const newVal = input.value;
                        if (newVal === original || newVal.trim() === '') {
                            restore();
                            return;
                        }
                        // Busy state
                        saveBtn.disabled = true; input.disabled = true;
                        saveBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> جارِ الحفظ...';
                        try {
                            console.log(`📤 تحديث حقل "${fieldKey}" من "${original}" إلى "${newVal}"`);
                            const res = await this.apiCall({ action: 'updateUserProfile', userId, profileData: { [fieldKey]: newVal } });
                            if (res && res.success) {
                                console.log('✅ تم حفظ التعديل بنجاح');
                                // Refresh caches and UI
                                try { this.clearCache(); } catch {}
                                restore(newVal);
                                this.showToast('✅ تم حفظ التعديل بنجاح', true);
                                // إعادة تحميل البيانات من السيرفر لضمان التحديث الكامل
                                console.log('🔄 إعادة تحميل البيانات من السيرفر...');
                                await this.loadUserData(userId, true); // force reload
                            } else {
                                this.showToast(res?.message || 'فشل حفظ التعديل', false);
                                restore();
                            }
                        } catch (err) {
                            console.error('❌ خطأ في الحفظ:', err);
                            this.showToast('خطأ في الحفظ: ' + (err?.message || err), false);
                            restore();
                        }
                    });
                });
                container._inlineEditBound = true;
            });
        },

        async loadUserEditRequests(userId) {
            try {
                const result = await this.apiCall({ action: 'getUserEditRequests', userId });
                if (result && result.success) {
                    // ترتيب حسب التاريخ (الأحدث أولاً)
                    this.allUserEditRequests = result.requests.sort((a, b) => {
                        const dateA = new Date(a.requestDate);
                        const dateB = new Date(b.requestDate);
                        return dateB - dateA;
                    });
                    this.userEditRequestsPage = 1; // إعادة تعيين الصفحة للأولى
                    this.renderUserEditRequestsWithPagination();
                }
            } catch (error) {
                console.error('خطأ في جلب طلبات التعديل:', error);
            }
        },

        renderUserEditRequestsWithPagination() {
            // فحص وجود الجدول أولاً
            if (!document.getElementById('editRequestsTableBody')) {
                return; // الجدول غير موجود في هذه الصفحة
            }
            
            if (!this.allUserEditRequests || this.allUserEditRequests.length === 0) {
                if (typeof this.renderUserEditRequests === 'function') {
                    this.renderUserEditRequests([]);
                }
                return;
            }
            
            const startIndex = (this.userEditRequestsPage - 1) * this.userEditRequestsPageSize;
            const endIndex = startIndex + this.userEditRequestsPageSize;
            const paginatedRequests = this.allUserEditRequests.slice(startIndex, endIndex);
            
            if (typeof this.renderUserEditRequests === 'function') {
                this.renderUserEditRequests(paginatedRequests);
            }
            if (typeof this.renderEditRequestsPagination === 'function') {
                this.renderEditRequestsPagination();
            }
            if (typeof this.updateEditRequestsPaginationDisplay === 'function') {
                this.updateEditRequestsPaginationDisplay();
            }
        },

        renderUserEditRequests(requests) {
            const tableBody = document.getElementById('editRequestsTableBody');
            if (!tableBody) {
                // الجدول غير موجود في هذه الصفحة - هذا طبيعي في dashboard.html
                return;
            }

            if (this.allUserEditRequests.length === 0) {
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="10" class="text-center text-muted py-4">
                            <i class="bi bi-inbox me-2"></i>لا توجد طلبات تعديل
                        </td>
                    </tr>
                `;
                document.getElementById('editRequestsPagination')?.remove();
                return;
            }

            tableBody.innerHTML = requests.map((request, index) => {
                const statusClass = request.status === 'مقبول' ? 'status-approved' : 
                                  request.status === 'مرفوض' ? 'status-rejected' : 'status-pending';
                
                // التأكد من وجود البيانات مع قيم افتراضية
                const requestId = request.requestId || request.id || '-';
                const nationalId = request.nationalId || this.userData?.nationalId || '-';
                const userName = request.userName || this.userData?.name || '-';
                const requestDate = request.requestDate || '-';
                const reason = request.reason || '-';
                const requestedChanges = request.requestedChanges || request.changes || '-';
                const status = request.status || 'معلق';
                const adminNotes = request.adminNotes || request.notes || '-';
                const reviewDate = request.reviewDate || request.responseDate || '-';
                const reviewer = request.reviewer || request.adminName || '-';
                
                return `
                    <tr>
                        <td><strong>${requestId}</strong></td>
                        <td>${nationalId}</td>
                        <td>${userName}</td>
                        <td>${requestDate}</td>
                        <td>${reason}</td>
                        <td>${requestedChanges}</td>
                        <td><span class="${statusClass}">${status}</span></td>
                        <td>${adminNotes}</td>
                        <td>${reviewDate}</td>
                        <td>${reviewer}</td>
                    </tr>
                `;
            }).join('');
        },

        renderEditRequestsPagination() {
            // تحقق من وجود الجدول أولاً
            const tableBody = document.querySelector('#editRequestsTableBody');
            if (!tableBody) {
                // الجدول غير موجود في هذه الصفحة - هذا طبيعي في dashboard.html
                return;
            }
            
            const totalPages = Math.ceil(this.allUserEditRequests.length / this.userEditRequestsPageSize);
            if (totalPages <= 1) {
                document.getElementById('editRequestsPagination')?.remove();
                return;
            }
            
            const paginationContainer = tableBody.closest('.data-table-card');
            if (!paginationContainer) {
                console.warn('لم يتم العثور على حاوي الجدول لإضافة التصفح');
                return;
            }
            
            let paginationHtml = '';

            // إزالة التصفح القديم إن وجد
            document.getElementById('editRequestsPagination')?.remove();

            if (totalPages > 1) {
                paginationHtml = `
                    <div id="editRequestsPagination" class="d-flex justify-content-center align-items-center mt-3 mb-3">
                        <button class="btn btn-outline-primary btn-sm me-2" onclick="App.changeEditRequestsPage(${this.userEditRequestsPage - 1})" 
                                ${this.userEditRequestsPage === 1 ? 'disabled' : ''}>
                            <i class="bi bi-chevron-right"></i> السابق
                        </button>
                        <span class="mx-3">صفحة ${this.userEditRequestsPage} من ${totalPages}</span>
                        <button class="btn btn-outline-primary btn-sm ms-2" onclick="App.changeEditRequestsPage(${this.userEditRequestsPage + 1})" 
                                ${this.userEditRequestsPage === totalPages ? 'disabled' : ''}>
                            التالي <i class="bi bi-chevron-left"></i>
                        </button>
                    </div>
                `;
            }

            paginationContainer.insertAdjacentHTML('beforeend', paginationHtml);
        },

        changeEditRequestsPage(newPage) {
            const totalPages = Math.ceil(this.allUserEditRequests.length / this.userEditRequestsPageSize);
            if (newPage >= 1 && newPage <= totalPages) {
                this.userEditRequestsPage = newPage;
                this.renderUserEditRequestsWithPagination();
                // تحديث العرض على الجوال
                if (typeof updateMobileView === 'function') {
                    setTimeout(updateMobileView, 50);
                }
            }
        },

        renderFutureAidWithPagination() {
            const startIndex = (this.userFutureAidPage - 1) * this.userFutureAidPageSize;
            const endIndex = startIndex + this.userFutureAidPageSize;
            const paginatedAid = this.allUserFutureAid.slice(startIndex, endIndex);
            
            this.renderFutureAid(paginatedAid);
            this.renderFutureAidPagination();
            this.updateFutureAidPaginationDisplay();
        },

        renderFutureAid(futureAid) {
            const tableBody = document.getElementById('futureAidTableBody');
            if (!tableBody) return;
            
            if (this.allUserFutureAid.length === 0) { 
                tableBody.innerHTML = `
                    <tr class="no-data-row">
                        <td colspan="4">
                            <div class="empty-table-message">
                                <i class="bi bi-calendar-check"></i>
                                <h6>لا توجد مساعدات مجدولة</h6>
                                <p>لا توجد مساعدات مجدولة حالياً. سيتم عرض المساعدات المقبلة هنا عند جدولتها.</p>
                            </div>
                        </td>
                    </tr>
                `; 
                document.getElementById('futureAidPagination')?.remove();
                
                // تنظيف mobile cards إذا كان موجود
                const mobileCards = document.getElementById('futureAidMobileCards');
                if (mobileCards) {
                    mobileCards.innerHTML = `
                        <div class="mobile-empty-state">
                            <i class="bi bi-calendar-check"></i>
                            <h5>لا توجد مساعدات مجدولة</h5>
                            <p>سيتم عرض المساعدات المقبلة هنا عند جدولتها</p>
                        </div>
                    `;
                }
                return; 
            }
            
            // عرض الجدول التقليدي
            tableBody.innerHTML = futureAid.map(item => `
                <tr>
                    <td>${item['نوع المساعدة']}</td>
                    <td>${this.formatDateToEnglish(item['تاريخ الاستلام'])}</td>
                    <td>${item['مصدر المساعدة'] || '-'}</td>
                    <td>${item['ملاحظات'] || '-'}</td>
                </tr>
            `).join('');
            
            // عرض البطاقات للجوال - تصميم احترافي جديد
            const mobileCards = document.getElementById('futureAidMobileCards');
            if (mobileCards) {
                mobileCards.innerHTML = futureAid.map((item, index) => `
                    <div class="mobile-card">
                        <div class="mobile-card-header">
                            <h6 class="mobile-card-title">
                                <i class="bi bi-gift-fill"></i>
                                ${item['نوع المساعدة']}
                            </h6>
                            <span class="mobile-card-badge">
                                <i class="bi bi-calendar-event"></i>
                                قريباً
                            </span>
                        </div>
                        <div class="mobile-card-body">
                            <div class="mobile-card-row">
                                <span class="mobile-card-label">
                                    <i class="bi bi-calendar3"></i>
                                    تاريخ الاستلام
                                </span>
                                <span class="mobile-card-value">
                                    ${this.formatDateToEnglish(item['تاريخ الاستلام'])}
                                </span>
                            </div>
                            <div class="mobile-card-row">
                                <span class="mobile-card-label">
                                    <i class="bi bi-building"></i>
                                    المصدر
                                </span>
                                <span class="mobile-card-value">
                                    ${item['مصدر المساعدة'] || 'غير محدد'}
                                </span>
                            </div>
                            ${item['ملاحظات'] && item['ملاحظات'] !== '-' ? `
                            <div class="mobile-card-row">
                                <span class="mobile-card-label">
                                    <i class="bi bi-chat-text"></i>
                                    ملاحظات
                                </span>
                                <span class="mobile-card-value">
                                    ${item['ملاحظات']}
                                </span>
                            </div>
                            ` : ''}
                        </div>
                    </div>
                `).join('');
            }
        },

        renderFutureAidPagination() {
            const totalPages = Math.ceil(this.allUserFutureAid.length / this.userFutureAidPageSize);
            
            // إزالة التصفح القديم إن وجد
            document.getElementById('futureAidPagination')?.remove();
            
            if (totalPages <= 1) {
                return;
            }

            const paginationContainer = document.querySelector('#futureAidTableBody').closest('.data-table-card');
            let paginationHtml = '';

            if (totalPages > 1) {
                const startItem = ((this.userFutureAidPage - 1) * this.userFutureAidPageSize) + 1;
                const endItem = Math.min(this.userFutureAidPage * this.userFutureAidPageSize, this.allUserFutureAid.length);
                
                paginationHtml = `
                    <div id="futureAidPagination" class="d-flex justify-content-center align-items-center mt-3 mb-3 p-3">
                        <button class="btn btn-outline-primary btn-sm me-2" onclick="App.changeFutureAidPage(${this.userFutureAidPage - 1})" 
                                ${this.userFutureAidPage === 1 ? 'disabled' : ''}>
                            <i class="bi bi-chevron-right"></i> السابق
                        </button>
                        <div class="text-center mx-3">
                            <span class="fw-bold text-primary">صفحة ${this.userFutureAidPage} من ${totalPages}</span>
                            <br>
                            <small class="text-muted">عرض ${startItem}-${endItem} من ${this.allUserFutureAid.length} مساعدة</small>
                        </div>
                        <button class="btn btn-outline-primary btn-sm ms-2" onclick="App.changeFutureAidPage(${this.userFutureAidPage + 1})" 
                                ${this.userFutureAidPage === totalPages ? 'disabled' : ''}>
                            التالي <i class="bi bi-chevron-left"></i>
                        </button>
                    </div>
                `;
            }

            paginationContainer.insertAdjacentHTML('beforeend', paginationHtml);
        },

        changeFutureAidPage(newPage) {
            const totalPages = Math.ceil(this.allUserFutureAid.length / this.userFutureAidPageSize);
            if (newPage >= 1 && newPage <= totalPages) {
                this.userFutureAidPage = newPage;
                this.renderFutureAidWithPagination();
                // تحديث العرض على الجوال
                if (typeof updateMobileView === 'function') {
                    setTimeout(updateMobileView, 50);
                }
            }
        },
        
        renderCompletedAid(history) {
            const tableBody = document.getElementById('aidHistoryTableBody');
            if (!tableBody) return;
            
            if (this.allUserAidHistory.length === 0) { 
                tableBody.innerHTML = `
                    <tr class="no-data-row">
                        <td colspan="4">
                            <div class="empty-table-message">
                                <i class="bi bi-card-checklist"></i>
                                <h6>لا يوجد سجل مساعدات</h6>
                                <p>لا يوجد سجل مساعدات مكتملة لعرضه. سيظهر هنا تاريخ المساعدات التي تم استلامها.</p>
                            </div>
                        </td>
                    </tr>
                `; 
                document.getElementById('aidHistoryPagination')?.remove();
                
                // تنظيف mobile cards إذا كان موجود
                const mobileCards = document.getElementById('aidHistoryMobileCards');
                if (mobileCards) {
                    mobileCards.innerHTML = `
                        <div class="mobile-empty-state">
                            <i class="bi bi-card-checklist"></i>
                            <h5>لا يوجد سجل مساعدات</h5>
                            <p>لا يوجد سجل مساعدات مكتملة لعرضه</p>
                        </div>
                    `;
                }
                return; 
            }
            
            tableBody.innerHTML = history.map(item => `
                <tr>
                    <td>${item['نوع المساعدة']}</td>
                    <td>${this.formatDateToEnglish(item['تاريخ الاستلام'])}</td>
                    <td>${item['مصدر المساعدة'] || '-'}</td>
                    <td>${item['ملاحظات'] || '-'}</td>
                </tr>
            `).join('');
            
            // عرض البطاقات للجوال - تصميم احترافي جديد
            const mobileCards = document.getElementById('aidHistoryMobileCards');
            if (mobileCards) {
                mobileCards.innerHTML = history.map((item, index) => `
                    <div class="mobile-card">
                        <div class="mobile-card-header">
                            <h6 class="mobile-card-title">
                                <i class="bi bi-check-circle-fill"></i>
                                ${item['نوع المساعدة']}
                            </h6>
                            <span class="mobile-card-badge" style="background: var(--gradient-success);">
                                <i class="bi bi-check2"></i>
                                مكتملة
                            </span>
                        </div>
                        <div class="mobile-card-body">
                            <div class="mobile-card-row">
                                <span class="mobile-card-label">
                                    <i class="bi bi-calendar-check"></i>
                                    تاريخ الاستلام
                                </span>
                                <span class="mobile-card-value status-success">
                                    ${this.formatDateToEnglish(item['تاريخ الاستلام'])}
                                </span>
                            </div>
                            <div class="mobile-card-row">
                                <span class="mobile-card-label">
                                    <i class="bi bi-building"></i>
                                    المصدر
                                </span>
                                <span class="mobile-card-value">
                                    ${item['مصدر المساعدة'] || 'غير محدد'}
                                </span>
                            </div>
                            ${item['ملاحظات'] && item['ملاحظات'] !== '-' ? `
                            <div class="mobile-card-row">
                                <span class="mobile-card-label">
                                    <i class="bi bi-chat-text"></i>
                                    ملاحظات
                                </span>
                                <span class="mobile-card-value">
                                    ${item['ملاحظات']}
                                </span>
                            </div>
                            ` : ''}
                        </div>
                    </div>
                `).join('');
            }
        },

        renderAidHistoryPagination() {
            const totalPages = Math.ceil(this.allUserAidHistory.length / this.userAidHistoryPageSize);
            
            // إزالة التصفح القديم إن وجد
            document.getElementById('aidHistoryPagination')?.remove();
            
            if (totalPages <= 1) {
                return;
            }

            const paginationContainer = document.querySelector('#aidHistoryTableBody').closest('.data-table-card');
            let paginationHtml = '';

            if (totalPages > 1) {
                const startItem = ((this.userAidHistoryPage - 1) * this.userAidHistoryPageSize) + 1;
                const endItem = Math.min(this.userAidHistoryPage * this.userAidHistoryPageSize, this.allUserAidHistory.length);
                
                paginationHtml = `
                    <div id="aidHistoryPagination" class="d-flex justify-content-center align-items-center mt-3 mb-3 p-3">
                        <button class="btn btn-outline-primary btn-sm me-2" onclick="App.changeAidHistoryPage(${this.userAidHistoryPage - 1})" 
                                ${this.userAidHistoryPage === 1 ? 'disabled' : ''}>
                            <i class="bi bi-chevron-right"></i> السابق
                        </button>
                        <div class="text-center mx-3">
                            <span class="fw-bold text-primary">صفحة ${this.userAidHistoryPage} من ${totalPages}</span>
                            <br>
                            <small class="text-muted">عرض ${startItem}-${endItem} من ${this.allUserAidHistory.length} مساعدة</small>
                        </div>
                        <button class="btn btn-outline-primary btn-sm ms-2" onclick="App.changeAidHistoryPage(${this.userAidHistoryPage + 1})" 
                                ${this.userAidHistoryPage === totalPages ? 'disabled' : ''}>
                            التالي <i class="bi bi-chevron-left"></i>
                        </button>
                    </div>
                `;
            }

            paginationContainer.insertAdjacentHTML('beforeend', paginationHtml);
        },
        
        renderAidHistoryWithPagination() {
            const startIndex = (this.userAidHistoryPage - 1) * this.userAidHistoryPageSize;
            const endIndex = startIndex + this.userAidHistoryPageSize;
            const paginatedHistory = this.allUserAidHistory.slice(startIndex, endIndex);
            
            this.renderAidHistory(paginatedHistory);
            this.renderAidHistoryPagination();
            this.updateAidHistoryPaginationDisplay();
        },
        
        renderAidHistory(aidHistory) {
            const tableBody = document.getElementById('aidHistoryTableBody');
            const mobileCards = document.getElementById('aidHistoryMobileCards');
            if (!tableBody) return;
            
            if (this.allUserAidHistory.length === 0) {
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="4" class="text-center text-muted py-4">
                            <i class="bi bi-card-checklist me-2"></i>لا يوجد سجل مساعدات
                        </td>
                    </tr>
                `;
                if (mobileCards) {
                    mobileCards.innerHTML = `
                        <div class="mobile-empty-state">
                            <i class="bi bi-card-checklist"></i>
                            <h6>لا يوجد سجل مساعدات</h6>
                            <p>لا يوجد سجل مساعدات حتى الآن.</p>
                        </div>
                    `;
                }
                document.getElementById('aidHistoryPagination')?.remove();
                return;
            }
            
            // عرض الجدول التقليدي
            tableBody.innerHTML = aidHistory.map(aid => `
                <tr>
                    <td>${aid['نوع المساعدة']}</td>
                    <td>${this.formatDateToEnglish(aid['تاريخ الاستلام'])}</td>
                    <td>${aid['مصدر المساعدة'] || '-'}</td>
                    <td>${aid['ملاحظات'] || '-'}</td>
                </tr>
            `).join('');
            
            // عرض البطاقات للجوال
            if (mobileCards) {
                mobileCards.innerHTML = aidHistory.map((aid, index) => `
                    <div class="mobile-card history-card">
                        <div class="mobile-card-header">
                            <i class="bi bi-card-checklist"></i>
                            ${aid['نوع المساعدة']}
                        </div>
                        <div class="mobile-card-content">
                            <div class="mobile-card-item">
                                <span class="mobile-card-label">
                                    <i class="bi bi-calendar-check me-1"></i>تاريخ الاستلام
                                </span>
                                <div class="mobile-card-value mobile-card-date">
                                    ${this.formatDateToEnglish(aid['تاريخ الاستلام'])}
                                </div>
                            </div>
                            <div class="mobile-card-item">
                                <span class="mobile-card-label">
                                    <i class="bi bi-building me-1"></i>مصدر المساعدة
                                </span>
                                <div class="mobile-card-value">${aid['مصدر المساعدة'] || 'غير محدد'}</div>
                            </div>
                        </div>
                        ${aid['ملاحظات'] && aid['ملاحظات'] !== '-' ? `
                            <div class="mobile-card-actions">
                                <small class="text-muted">
                                    <i class="bi bi-chat-left-text me-1"></i>
                                    ${aid['ملاحظات']}
                                </small>
                            </div>
                        ` : ''}
                    </div>
                `).join('');
            }
        },

        changeAidHistoryPage(newPage) {
            const totalPages = Math.ceil(this.allUserAidHistory.length / this.userAidHistoryPageSize);
            if (newPage >= 1 && newPage <= totalPages) {
                this.userAidHistoryPage = newPage;
                this.renderAidHistoryWithPagination();
                // تحديث العرض على الجوال
                if (typeof updateMobileView === 'function') {
                    setTimeout(updateMobileView, 50);
                }
            }
        },

        initAdminDashboardPage(token) { 
            if (sessionStorage.getItem('adminRole') === 'superadmin') document.getElementById('superadmin-link')?.classList.remove('d-none'); 
            this.loadAdminStats(token); 
        },
        async loadAdminStats(token) {
            const statsResult = await this.apiCall({ action: 'getAdminStats', token });
            if (statsResult?.stats) {
                document.getElementById('totalMembers').textContent = statsResult.stats.totalIndividuals;
                document.getElementById('totalFamilies').textContent = statsResult.stats.totalFamilies;
                document.getElementById('totalAid').textContent = statsResult.stats.totalAid;
                document.getElementById('totalDivorced').textContent = statsResult.stats.divorced || 0;
                document.getElementById('totalMartyrs').textContent = statsResult.stats.martyrs || 0;
                document.getElementById('totalWounded').textContent = statsResult.stats.wounded || 0;
                document.getElementById('branchAhmad').textContent = statsResult.stats.branchAhmad || 0;
                document.getElementById('branchHamed').textContent = statsResult.stats.branchHamed || 0;
                document.getElementById('branchHamdan').textContent = statsResult.stats.branchHamdan || 0;
                document.getElementById('branchHammad').textContent = statsResult.stats.branchHammad || 0;
            }
        },

        initManageMembersPage(token) {
            const editMemberModalElement = document.getElementById('editMemberModal');
            document.getElementById('memberSearchInput')?.addEventListener('input', () => { 
                clearTimeout(this.searchTimeout); 
                this.searchTimeout = setTimeout(() => this.handleMemberSearch(token), 500); 
            });
            document.getElementById('membersTableBody')?.addEventListener('click', e => {
                if (e.target.closest('.print-member-btn')) this.handlePrintMemberReport(e, token);
                if (e.target.closest('.reset-password-btn')) this.handleResetPassword(e, token);
            });
            document.getElementById('startPrintBtn')?.addEventListener('click', () => { 
                setTimeout(() => window.print(), 250); 
            });
            editMemberModalElement?.addEventListener('show.bs.modal', (event) => {
                const button = event.relatedTarget;
                const memberData = JSON.parse(button.dataset.member);
                document.getElementById('editMemberId').value = memberData['رقم الهوية'];
                document.getElementById('editFullName').value = memberData['الاسم الكامل'];
                document.getElementById('editPhoneNumber').value = memberData['رقم الجوال'];
                document.getElementById('editResidence').value = memberData['مكان الإقامة'];
                document.getElementById('editSpouseId').value = memberData['رقم هوية الزوجة'];
                document.getElementById('editSpouseFullName').value = memberData['اسم الزوجة رباعي'];
            });
            document.getElementById('editMemberForm')?.addEventListener('submit', async (e) => {
                e.preventDefault();
                const form = e.target;
                const memberId = form.editMemberId.value;
                const memberData = {
                    'الاسم الكامل': form.editFullName.value, 'رقم الجوال': form.editPhoneNumber.value,
                    'مكان الإقامة': form.editResidence.value, 'رقم هوية الزوجة': form.editSpouseId.value,
                    'اسم الزوجة رباعي': form.editSpouseFullName.value,
                };
                const result = await this.apiCall({
                    action: 'updateMember', token: token,
                    memberId: memberId, memberData: memberData
                }, true);
                if (result) { this.editMemberModalInstance.hide(); this.handleMemberSearch(token); }
            });
        },
        async handleMemberSearch(token) {
            const tableBody = document.getElementById('membersTableBody');
            const searchTerm = document.getElementById('memberSearchInput').value;
            if (!searchTerm) { tableBody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">يرجى استخدام البحث لعرض الأفراد...</td></tr>'; document.getElementById('membersTotalCount').textContent = 'نتائج البحث: 0'; return; }
            tableBody.innerHTML = '<tr><td colspan="5" class="text-center">جاري البحث...</td></tr>';
            const result = await this.apiCall({ action: 'getAllMembers', token, searchTerm, page: 1, pageSize: 50 });
            this.renderMembersTable(result ? result.members : [], result ? result.total : 0);
        },
        renderMembersTable(members, total) {
            const tableBody = document.getElementById('membersTableBody');
            document.getElementById('membersTotalCount').textContent = `نتائج البحث: ${total}`;
            if (!members || members.length === 0) { tableBody.innerHTML = '<tr><td colspan="5" class="text-center">لا يوجد أفراد يطابقون البحث.</td></tr>'; return; }
            tableBody.innerHTML = members.map(member => `<tr><td>${member['الاسم الكامل']}</td><td>${member['رقم الهوية']}</td><td>${member['رقم الجوال'] || '-'}</td><td>${member['مكان الإقامة'] || '-'}</td><td><div class="btn-group"><button class="btn btn-sm btn-info" data-member='${JSON.stringify(member)}' data-bs-toggle="modal" data-bs-target="#editMemberModal" title="تعديل"><i class="bi bi-pencil-square"></i></button><button class="btn btn-sm btn-warning reset-password-btn" data-id="${member['رقم الهوية']}" title="مسح كلمة المرور"><i class="bi bi-key-fill"></i></button><button class="btn btn-sm btn-secondary print-member-btn" data-id="${member['رقم الهوية']}" title="طباعة تقرير"><i class="bi bi-printer-fill"></i></button></div></td></tr>`).join('');
        },
        async handlePrintMemberReport(e, token) {
            const userId = e.target.closest('.print-member-btn').dataset.id;
            this.showToast('جاري تجهيز التقرير...', true);
            const [userDataResult, aidHistoryResult, futureAidResult] = await Promise.all([
                this.apiCall({ action: 'getUserData', userId, token }, false, true),
                this.apiCall({ action: 'getUserAidHistory', userId, token }, false, true),
                this.apiCall({ action: 'getUserFutureAid', userId, token }, false, true)
            ]);
            if (userDataResult && aidHistoryResult && futureAidResult) {
                document.getElementById('printReportContent').innerHTML = this.generateReportHTML(userDataResult.data, aidHistoryResult.data, futureAidResult.data);
                this.printReportModalInstance?.show();
            } else { this.showToast('فشل تحميل كامل بيانات التقرير.', false); }
        },
        generateReportHTML(userData, aidHistory, futureAid) {
            const createTable = (title, icon, data, headers) => `<h5 class="report-section-title"><i class="bi bi-${icon} me-2"></i>${title}</h5><table class="table table-bordered table-sm mb-4"><thead><tr>${headers.map(h => `<th>${h.label}</th>`).join('')}</tr></thead><tbody>${data.length > 0 ? data.map(item => `<tr>${headers.map(h => `<td>${item[h.key] ? (h.isDate ? this.formatDateToEnglish(item[h.key]) : item[h.key]) : '-'}</td>`).join('')}</tr>`).join('') : `<tr><td colspan="${headers.length}" class="text-center text-muted">لا توجد بيانات</td></tr>`}</tbody></table>`;
            const userInfoHtml = `<div class="row report-info-grid">${Object.entries({'الاسم الكامل': userData['الاسم الكامل'], 'رقم الهوية': userData['رقم الهوية'], 'رقم الجوال': userData['رقم الجوال'], 'مكان الإقامة': userData['مكان الإقامة'], 'اسم الزوجة': userData['اسم الزوجة رباعي'], 'رقم هوية الزوجة': userData['رقم هوية الزوجة']}).map(([label, value]) => `<div class="col-6"><div class="info-box"><strong>${label}:</strong><span>${value || '-'}</span></div></div>`).join('')}</div>`;
            return `<div class="report-header"><img src="logo.webp" alt="شعار"><div><h1>تقرير بيانات فرد</h1><p>عائلة أبو رجيلة (قديح)</p></div></div><h5 class="report-section-title"><i class="bi bi-person-fill me-2"></i>البيانات الشخصية</h5>${userInfoHtml}${createTable('سجل المساعدات المكتملة', 'card-list', aidHistory, [{label: 'نوع المساعدة', key: 'نوع المساعدة'}, {label: 'تاريخ الاستلام', key: 'تاريخ الاستلام', isDate: true}, {label: 'المصدر', key: 'مصدر المساعدة'}])}${createTable('المساعدات المستقبلية المجدولة', 'calendar-check', futureAid, [{label: 'نوع المساعدة', key: 'نوع المساعدة'}, {label: 'تاريخ الاستلام', key: 'تاريخ الاستلام', isDate: true}, {label: 'المصدر', key: 'مصدر المساعدة'}])}<div class="report-footer"><p>تاريخ الطباعة: ${new Date().toLocaleDateString('ar-EG')}</p><p>نظام عائلة أبو رجيلة (قديح) © 2025</p></div>`;
        },
        async handleResetPassword(e, token) { const userId = e.target.closest('.reset-password-btn').dataset.id; const confirmed = await this.showConfirmationModal(`هل أنت متأكد من مسح كلمة مرور المستخدم ${userId}؟`); if (confirmed) await this.apiCall({ action: 'clearMemberPassword', token, userId }, true); },

        initManageAidPage(token) {
             document.getElementById('addAidForm')?.addEventListener('submit', e => this.handleAddAid(e, token));
             document.getElementById('bulkUploadForm')?.addEventListener('submit', e => this.handleAidFileUpload(e, token));
             document.getElementById('exportTemplateBtn')?.addEventListener('click', () => this.exportAidTemplateToExcel());
             document.getElementById('aidMemberSearch')?.addEventListener('input', () => this.handleAidMemberSearch(token));
             document.getElementById('clearSearchBtn')?.addEventListener('click', () => { document.getElementById('aidMemberSearch').value = ''; this.populateBeneficiaryList([]); });
             this.populateAidCategories();
        },
        populateAidCategories() {
            const categorySelect = document.getElementById('aidCategory'), typeSelect = document.getElementById('aidType');
            if(!categorySelect || !typeSelect) return;
            for (const category in this.aidCategories) { const option = document.createElement('option'); option.value = category; option.textContent = category; categorySelect.appendChild(option); }
            categorySelect.addEventListener('change', () => { typeSelect.innerHTML = '<option value="" disabled selected>-- اختر النوع الفرعي --</option>'; typeSelect.disabled = true; if (categorySelect.value && this.aidCategories[categorySelect.value]) { this.aidCategories[categorySelect.value].forEach(subType => { const option = document.createElement('option'); option.value = subType; option.textContent = subType; typeSelect.appendChild(option); }); typeSelect.disabled = false; } });
        },
        async handleAidMemberSearch(token) { const searchTerm = document.getElementById('aidMemberSearch').value.toLowerCase(); if (searchTerm.length < 2) { this.populateBeneficiaryList([]); return; } const result = await this.apiCall({ action: 'getAllMembers', token, searchTerm, page: 1, pageSize: 50 }); if (result?.members) { this.membersList = result.members.map(member => ({ id: member['رقم الهوية'], name: member['الاسم الكامل'] })); this.populateBeneficiaryList(this.membersList); } },
        populateBeneficiaryList(members) { const selectList = document.getElementById('aidMemberSelect'); selectList.innerHTML = members.length === 0 ? '<option disabled selected>لا توجد نتائج</option>' : members.map(m => `<option value="${m.id}">${m.name} | ${m.id}</option>`).join(''); if(members.length > 0) selectList.value = members[0].id; },
        async handleAddAid(e, token) {
            e.preventDefault(); const form = e.target;
            const aidData = {
                aidMemberId: form.aidMemberSelect?.value,
                aidType: form.aidType?.value,
                aidStatus: form.aidStatus?.value,
                aidDate: form.aidDate?.value,
                aidSource: form.aidSource?.value,
                aidNotes: form.aidNotes?.value,
                programCategory: form.programCategory?.value,
                lifecycleStage: form.lifecycleStage?.value,
                quantity: form.quantity?.value,
                unit: form.unit?.value,
                estimatedValue: form.estimatedValue?.value,
                deliveryMethod: form.deliveryMethod?.value,
                deliveryStatus: form.deliveryStatus?.value
            };
            if (!aidData.aidMemberId || !aidData.aidType) { this.showToast('الرجاء اختيار مستفيد ونوع المساعدة.', false); return; }
            const result = await this.apiCall({ ...aidData, action: 'addAid', token }, true);
            if (result) { form.reset(); form.aidType.innerHTML = '<option value="" disabled selected>-- اختر النوع الفرعي --</option>'; form.aidType.disabled = true; this.populateBeneficiaryList([]); }
        },
        async handleAidFileUpload(e, token) { e.preventDefault(); const file = e.target.xlsxFile.files[0]; if (!file) { this.showToast('الرجاء اختيار ملف.', false); return; } const reader = new FileReader(); reader.onload = async (event) => { const result = await this.apiCall({ action: 'bulkAddAidFromXLSX', token, fileContent: btoa(event.target.result) }, true); if (result) e.target.reset(); }; reader.readAsBinaryString(file); },
        exportAidTemplateToExcel() { const headers = ['معرف المستفيد', 'نوع المساعدة', 'تاريخ الاستلام', 'مصدر المساعدة', 'ملاحظات', 'حالة المساعدة']; const exampleRow = ['123456789', 'نقد مباشر للعائلات المحتاجة', '2025-09-06', 'قسائم/دهش/عضوية', 'Completed']; const wb = XLSX.utils.book_new(); const ws = XLSX.utils.aoa_to_sheet([headers, exampleRow]); XLSX.utils.book_append_sheet(wb, ws, "قالب المساعدات"); XLSX.writeFile(wb, "قالب-المساعدات.xlsx"); },
        
        async initAidLogsPage(token) {
            await this.fetchAidDataAndPopulateTables(token);
            this.loadFutureAidData();
            document.getElementById('futureAidSearchInput')?.addEventListener('input', () => this.loadFutureAidData());
            document.getElementById('completedAidSearchInput')?.addEventListener('input', () => this.loadCompletedAidData());
            document.getElementById('futureAidPageSizeSelect')?.addEventListener('change', (e) => { this.futureAidPageSize = parseInt(e.target.value, 10); this.futureAidCurrentPage = 1; this.loadFutureAidData(); });
            document.getElementById('futureAidPagination')?.addEventListener('click', (e) => { if (e.target.dataset.page) { this.futureAidCurrentPage = parseInt(e.target.dataset.page, 10); this.loadFutureAidData(); } });
            document.getElementById('futureAidsTableBody')?.addEventListener('click', e => { if (e.target.closest('.complete-aid-btn')) this.handleCompleteSingleAid(e, token); });
            document.getElementById('completeAllAidBtn')?.addEventListener('click', () => this.bulkCompleteModal?.show());
            document.getElementById('confirmBulkProcessBtn')?.addEventListener('click', () => this.handleConfirmBulkProcess(token));
        },
        async fetchAidDataAndPopulateTables(token) {
            const aidResult = await this.apiCall({ action: 'getAllAidRecords', token });
            if (aidResult?.data) {
                this.allFutureAidRecords = aidResult.data.filter(aid => String(aid['حالة المساعدة']).trim() === 'Future');
                this.allCompletedAidRecords = aidResult.data.filter(aid => String(aid['حالة المساعدة']).trim() === 'Completed');
            }
        },
        loadFutureAidData() {
            const searchTerm = document.getElementById('futureAidSearchInput')?.value.toLowerCase() || '';
            let filteredRecords = this.allFutureAidRecords.filter(r => (r['اسم المستفيد'] || '').toLowerCase().includes(searchTerm) || (r['نوع المساعدة'] || '').toLowerCase().includes(searchTerm));
            this.currentFilteredFutureAid = filteredRecords;
            document.getElementById('futureAidTotalCount').textContent = `إجمالي السجلات: ${filteredRecords.length}`;
            const paginatedRecords = filteredRecords.slice((this.futureAidCurrentPage - 1) * this.futureAidPageSize, this.futureAidCurrentPage * this.futureAidPageSize);
            this.renderFutureAidTable(paginatedRecords, searchTerm);
        },
        loadCompletedAidData() {
            const searchTerm = document.getElementById('completedAidSearchInput')?.value.toLowerCase() || '';
            const filteredRecords = this.allCompletedAidRecords.filter(r => (r['اسم المستفيد'] || '').toLowerCase().includes(searchTerm) || (r['نوع المساعدة'] || '').toLowerCase().includes(searchTerm));
            this.renderCompletedAidTable(filteredRecords, searchTerm);
        },
        renderFutureAidTable(records, searchTerm) {
            const tableBody = document.getElementById('futureAidsTableBody');
            if (records.length === 0) {
                const message = searchTerm ? 'لا توجد سجلات تطابق البحث.' : 'لا توجد مساعدات مستقبلية حالياً.';
                tableBody.innerHTML = `<tr><td colspan="6" class="text-center text-muted">${message}</td></tr>`;
            } else {
                tableBody.innerHTML = records.map(aid => `<tr data-beneficiary-id="${aid['معرف المستفيد']}"><td>${aid['اسم المستفيد'] || '-'}</td><td>${aid['معرف المستفيد']}</td><td>${aid['نوع المساعدة']}</td><td>${this.formatDateToEnglish(aid['تاريخ الاستلام'])}</td><td>${aid['مصدر المساعدة'] || '-'}</td><td><button class="btn btn-sm btn-success complete-aid-btn" data-id="${aid['معرف المساعدة']}"><i class="bi bi-check-lg"></i></button></td></tr>`).join('');
            }
        },
        renderCompletedAidTable(records, searchTerm) {
            const tableBody = document.getElementById('completedAidsTableBody');
            if (!searchTerm) {
                tableBody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">يرجى استخدام البحث لعرض السجلات...</td></tr>';
            } else if (records.length === 0) {
                tableBody.innerHTML = '<tr><td colspan="5" class="text-center">لا توجد سجلات تطابق البحث.</td></tr>';
            } else {
                tableBody.innerHTML = records.map(aid => `<tr><td>${aid['اسم المستفيد'] || '-'}</td><td>${aid['معرف المستفيد']}</td><td>${aid['نوع المساعدة']}</td><td>${this.formatDateToEnglish(aid['تاريخ الاستلام'])}</td><td>${aid['مصدر المساعدة'] || '-'}</td></tr>`).join('');
            }
        },
        async handleCompleteSingleAid(e, token) {
            const button = e.target.closest('.complete-aid-btn');
            const aidId = button.dataset.id;
            const tableRow = button.closest('tr');
        
            const confirmed = await this.showConfirmationModal('هل أنت متأكد من تسليم هذه المساعدة؟');
            if (confirmed) {
                button.disabled = true;
                button.innerHTML = `<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>`;
                const result = await this.apiCall({ action: 'updateAidStatus', token, aidId, newStatus: 'Completed' });
                if (result) {
                    this.showToast('تم تحديث الحالة بنجاح!', true);
                    tableRow.style.opacity = '0';
                    setTimeout(() => {
                        tableRow.remove();
                        const totalCountEl = document.getElementById('futureAidTotalCount');
                        const currentCount = parseInt(totalCountEl.textContent.split(': ')[1] || '0', 10);
                        totalCountEl.textContent = `إجمالي السجلات: ${Math.max(0, currentCount - 1)}`;
                    }, 300);
                } else {
                    button.disabled = false;
                    button.innerHTML = `<i class="bi bi-check-lg"></i>`;
                }
            }
        },
        async handleConfirmBulkProcess(token) {
            const allFilteredBeneficiaryIds = this.currentFilteredFutureAid.map(record => String(record['معرف المستفيد']));
            const exceptions = document.getElementById('exceptionIdsTextarea').value.split('\n').map(id => id.trim()).filter(id => id);
            const beneficiaryIdsToComplete = allFilteredBeneficiaryIds.filter(id => !exceptions.includes(id));
            if (beneficiaryIdsToComplete.length === 0 && exceptions.length === 0) { this.showToast('لم يتم تحديد أي إجراء.', false); return; }
            const result = await this.apiCall({ action: 'bulkProcessAid', token, beneficiaryIdsToComplete, aidRecordsToDelete: exceptions }, true);
            if (result) {
                this.bulkCompleteModal.hide();
                await this.fetchAidDataAndPopulateTables(token);
                this.loadFutureAidData();
            }
        },

        initReportsPage(token) {
            document.getElementById('reportForm')?.addEventListener('submit', e => this.handleReportGeneration(e, token));
            document.getElementById('exportReportBtn')?.addEventListener('click', () => this.exportReportToExcel());
        },
        async handleReportGeneration(e, token) {
            e.preventDefault();
            const startDate = document.getElementById('startDate').value;
            const endDate = document.getElementById('endDate').value;
            if (!startDate || !endDate) { this.showToast('الرجاء تحديد تاريخ البدء والانتهاء.', false); return; }
            const result = await this.apiCall({ action: 'generateReport', token, reportType: 'aidByDateRange', filters: { startDate, endDate } });
            if (result?.data) this.renderReportResults(result.data);
        },
        renderReportResults(data) {
            const tableBody = document.getElementById('reportTableBody');
            const exportBtn = document.getElementById('exportReportBtn');
            const resultsContainer = document.getElementById('reportResults');
            if (data.length === 0) {
                tableBody.innerHTML = '<tr><td colspan="5" class="text-center">لا توجد بيانات لهذه الفترة.</td></tr>';
                exportBtn.style.display = 'none';
            } else {
                tableBody.innerHTML = data.map(record => `<tr><td>${record['اسم المستفيد']}</td><td>${record['معرف المستفيد']}</td><td>${record['نوع المساعدة']}</td><td>${this.formatDateToEnglish(record['تاريخ الاستلام'])}</td><td>${record['مصدر المساعدة']}</td></tr>`).join('');
                exportBtn.style.display = 'inline-block';
            }
            resultsContainer.classList.remove('d-none');
        },
        exportReportToExcel() {
            const table = document.getElementById('reportResults').querySelector('table');
            if (!table) { this.showToast('لا توجد بيانات للتصدير.', false); return; }
            const wb = XLSX.utils.table_to_book(table, {sheet: "تقرير المساعدات"});
            XLSX.writeFile(wb, "تقرير-المساعدات.xlsx");
        },

        initPasswordResetsPage(token) {
            this.fetchResetRequests(token);
            document.getElementById('resetRequestsTableBody')?.addEventListener('click', e => this.handleClearPassword(e, token));
        },
        async fetchResetRequests(token) {
            const response = await fetch(`${this.WEB_APP_URL}?action=getResets`, { method: 'GET' });
            const result = await response.json();
            if (result && Array.isArray(result)) {
                const tableBody = document.getElementById('resetRequestsTableBody');
                tableBody.innerHTML = result.length === 0 ? '<tr><td colspan="5" class="text-center">لا يوجد طلبات جديدة.</td></tr>' : result.map(req => `
                    <tr>
                        <td>${req['التاريخ والوقت'] ? new Date(req['التاريخ والوقت']).toLocaleString() : '-'}</td>
                        <td>${req['رقم الهوية'] || '-'}</td>
                        <td>${req['اسم الأدمن'] || '-'}</td>
                        <td>${req['حالة الطلب'] || 'قيد الانتظار'}</td>
                        <td>
                            ${req['حالة الطلب'] === 'تمت الموافقة' ? '<span class="badge bg-success">تمت الموافقة</span>' : `<button class="btn btn-sm btn-success approve-reset-btn" data-userid="${req['رقم الهوية']}"><i class="bi bi-check-circle-fill me-1"></i> موافقة</button>`}
                        </td>
                    </tr>
                `).join('');
            }
        },
        async handleClearPassword(e, token) {
            const button = e.target.closest('.approve-reset-btn');
            if (!button) return;
            const userid = button.dataset.userid;
            const admin = sessionStorage.getItem('adminName') || 'غير محدد';
            const confirmed = await this.showConfirmationModal(`هل أنت متأكد من الموافقة على طلب إعادة تعيين المرور للهوية ${userid}؟ سيتم تسجيل اسم الأدمن: ${admin}`);
            if (confirmed) {
                const response = await fetch(this.WEB_APP_URL, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: 'approveReset', id: userid, admin })
                });
                const result = await response.json();
                if (result.success) {
                    this.showToast('تمت الموافقة وتسجيل اسم الأدمن بنجاح!', true);
                    this.fetchResetRequests(token);
                } else {
                    this.showToast('فشل في تحديث الطلب.', false);
                }
            }
        },
        
        async showConfirmationModal(message) {
            return new Promise(resolve => {
                const confirmationModalEl = document.getElementById('confirmationModal');
                if (!confirmationModalEl) {
                    this.showToast('خطأ: نافذة التأكيد غير موجودة.', false);
                    resolve(false);
                    return;
                }
                const confirmationModal = new bootstrap.Modal(confirmationModalEl);
                const confirmBtn = document.getElementById('confirmActionBtn');
                const modalBody = document.getElementById('confirmationModalBody');
                
                modalBody.textContent = message;
                confirmationModal.show();

                const confirmHandler = () => {
                    confirmationModal.hide();
                    resolve(true);
                };
                
                confirmBtn.addEventListener('click', confirmHandler, { once: true });

                confirmationModalEl.addEventListener('hidden.bs.modal', () => {
                    resolve(false);
                }, { once: true });
            });
        },

        initSuperAdminPage(token) {
            if (sessionStorage.getItem('adminRole') !== 'superadmin') { window.location.href = 'admin.html'; return; }
            this.renderCreateAdminForm();
            this.loadAdmins(token);
            document.getElementById('createAdminForm').addEventListener('submit', (e) => this.handleCreateAdminSubmit(e, token));
            document.getElementById('adminsTable').addEventListener('click', (e) => { if (e.target.closest('.toggle-status-btn')) this.handleStatusChange(e, token); });
        },
        renderCreateAdminForm() { document.getElementById('createAdminForm').innerHTML = `<div class="row"><div class="col-md-4 mb-3"><label for="newUsername" class="form-label">اسم المستخدم</label><input type="text" class="form-control" id="newUsername" required></div><div class="col-md-4 mb-3"><label for="newPassword" class="form-label">كلمة المرور</label><input type="password" class="form-control" id="newPassword" required></div><div class="col-md-4 mb-3"><label for="newRole" class="form-label">الصلاحية</label><select id="newRole" class="form-select" required><option value="admin">Admin</option><option value="superadmin">Super Admin</option></select></div></div><button type="submit" class="btn btn-primary">إنشاء حساب</button>`; },
        async handleCreateAdminSubmit(e, token) { e.preventDefault(); const result = await this.apiCall({ action: 'createAdmin', token, username: document.getElementById('newUsername').value, password: document.getElementById('newPassword').value, role: document.getElementById('newRole').value }, true); if (result) { e.target.reset(); this.loadAdmins(token); } },
        async loadAdmins(token) { const tableBody = document.getElementById('adminsTable'); tableBody.innerHTML = '<tr><td colspan="5" class="text-center">جاري التحميل...</td></tr>'; const result = await this.apiCall({ action: 'getAdmins', token }); if (result?.admins) this.renderAdminsTable(result.admins); else tableBody.innerHTML = '<tr><td colspan="5" class="text-center text-danger">فشل تحميل القائمة.</td></tr>'; },
        renderAdminsTable(admins) { document.getElementById('adminsTable').innerHTML = admins.map(admin => `<tr><td>${admin['اسم المستخدم']}</td><td><span class="badge bg-primary">${admin['الصلاحية']}</span></td><td>${this.formatDateToEnglish(admin['تاريخ الإنشاء'])}</td><td><span class="badge bg-${admin['الحالة'] === 'Active' ? 'success' : 'danger'}">${admin['الحالة'] === 'Active' ? 'نشط' : 'غير نشط'}</span></td><td><button class="btn btn-sm btn-${admin['الحالة'] === 'Active' ? 'danger' : 'success'} toggle-status-btn" data-username="${admin['اسم المستخدم']}" data-status="${admin['الحالة']}"><i class="bi bi-person-${admin['الحالة'] === 'Active' ? 'x' : 'check'}-fill"></i> ${admin['الحالة'] === 'Active' ? 'إلغاء تنشيط' : 'تنشيط'}</button></td></tr>`).join(''); },
        async handleStatusChange(event, token) { const button = event.target.closest('.toggle-status-btn'); const username = button.dataset.username; const newStatus = button.dataset.status === 'Active' ? 'Inactive' : 'Active'; const confirmed = await this.showConfirmationModal(`هل أنت متأكد من تغيير حالة المدير ${username} إلى ${newStatus === 'Active' ? 'نشط' : 'غير نشط'}؟`); if (confirmed) { const result = await this.apiCall({ action: 'updateAdminStatus', token, username, newStatus }, true); if (result) this.loadAdmins(token); } },

        /* ======================= SMS Broadcast ======================= */
        _smsAllRecipients: [], _smsFiltered: [], _smsSelectedIds: new Set(),
        initSmsBroadcastPage(token){
            // عناصر
            const branchFilter = document.getElementById('smsBranchFilter');
            const statusFilter = document.getElementById('smsStatusFilter');
            const searchInput = document.getElementById('smsSearch');
            const clearBtn = document.getElementById('smsClearSearch');
            const listEl = document.getElementById('recipientsList');
            const selectAll = document.getElementById('smsSelectAll');
            const refreshBtn = document.getElementById('refreshRecipients');
            const msgArea = document.getElementById('smsMessage');
            const previewBox = document.getElementById('smsPreviewBox');
            const charInfo = document.getElementById('charInfo');
            const statsEl = document.getElementById('smsCharStats');
            const insertNameBtn = document.getElementById('insertNameBtn');
            const insertIdBtn = document.getElementById('insertIdBtn');
            const clearMsgBtn = document.getElementById('clearMsgBtn');
            const previewBtn = document.getElementById('previewSmsBtn');
            const scheduleInput = document.getElementById('smsScheduleAt');
            const sendBtn = document.getElementById('sendSmsBtn');
            const sendSpinner = document.getElementById('smsSendSpinner');
            const costBtn = document.getElementById('estimateCostBtn');
            const costEl = document.getElementById('costEstimation');

            // تحميل الفروع من المخطط الموحد
            if(window.DATA_SCHEMA?.BRANCH_VALUES){ window.DATA_SCHEMA.BRANCH_VALUES.forEach(b=>{ const o=document.createElement('option'); o.value=b; o.textContent=b; branchFilter.appendChild(o); }); }

            const recalcCharStats = ()=>{
                const txt = msgArea.value || '';
                const length = [...txt].length; // نشر لتعامل مع Unicode
                // 70 أول جزء عربي، بعده 67
                const firstSeg = 70, nextSeg = 67;
                let segments = 0;
                if(length<=firstSeg) segments = length>0?1:0; else segments = 1 + Math.ceil((length-firstSeg)/nextSeg);
                charInfo.textContent = `${length} / 70 (${segments})`;
                statsEl.innerHTML = `<span class="${length<=firstSeg? 'ok': (segments<=3?'warn':'over')}">Segments: ${segments}</span>`;
            };

            const applyFilter = ()=>{
                const branch = branchFilter.value; const status = statusFilter.value; const term = searchInput.value.trim().toLowerCase();
                this._smsFiltered = this._smsAllRecipients.filter(r=>{
                    const name = (r.fullName||'').toLowerCase();
                    const id = (r.idNumber||'').toString();
                    const phone = (r.phone||'').toString();
                    const matchesTerm = !term || name.includes(term) || id.includes(term) || phone.includes(term);
                    const matchesBranch = !branch || r.branch===branch;
                    const matchesStatus = !status || r.status===status;
                    return matchesTerm && matchesBranch && matchesStatus;
                });
                renderList();
            };

            const renderList = ()=>{
                listEl.innerHTML = this._smsFiltered.length? '' : '<div class="text-center text-muted p-3 small">لا نتائج</div>';
                const frag = document.createDocumentFragment();
                this._smsFiltered.forEach(rec=>{
                    const row = document.createElement('div'); row.className='recipient-row d-flex align-items-center px-2 py-1';
                    const checked = this._smsSelectedIds.has(rec.idNumber)? 'checked':'';
                    row.innerHTML = `<div class="form-check me-2"><input class="form-check-input sms-rec" data-id="${rec.idNumber}" type="checkbox" ${checked}></div><div class="flex-grow-1 small"><strong>${rec.fullName||'-'}</strong><div class="text-muted" style="font-size:.65rem">${rec.idNumber} • ${rec.phone||'بدون رقم'} • ${rec.branch||'-'}</div></div>`;
                    frag.appendChild(row);
                });
                listEl.appendChild(frag);
                updateSelectedCount();
            };

            const updateSelectedCount = ()=>{
                document.getElementById('selectedCount').textContent = `${this._smsSelectedIds.size} مختار`;
                // ضبط حالة تحديد الكل
                if(this._smsFiltered.length){
                    const allSelected = this._smsFiltered.every(r=> this._smsSelectedIds.has(r.idNumber));
                    selectAll.checked = allSelected;
                } else selectAll.checked = false;
            };

            const fetchRecipients = async ()=>{
                listEl.innerHTML = '<div class="text-center text-muted p-3 small">جاري التحميل...</div>';
                const result = await this.apiCall({ action:'getAllMembers', token, searchTerm:'', page:1, pageSize:300 }, false, false);
                if(result?.members){
                    this._smsAllRecipients = result.members.map(m=>{
                        const n = window.DATA_SCHEMA?.CONVERTERS?.normalizeMember? window.DATA_SCHEMA.CONVERTERS.normalizeMember(m): m;
                        const S = window.DATA_SCHEMA?.INDIVIDUAL_FIELDS || {};
                        const phone = n[S?.PHONE_NUMBER] || n['رقم الهاتف'] || n['رقم الجوال'] || n.phoneNumber || n.phone || '';
                        return {
                            idNumber: n[S?.ID_NUMBER] || n['رقم الهوية'] || n.idNumber || '',
                            fullName: n[S?.FULL_NAME] || n['الاسم الكامل'] || n.fullName || '',
                            phone,
                            branch: n[S?.BRANCH] || n['الفرع'] || n.branch || '',
                            status: n[S?.STATUS] || n['الحالة'] || n.status || 'نشط'
                        };
                    }).filter(r=> r.phone); // استبعاد بدون رقم
                    this._smsFiltered = [...this._smsAllRecipients];
                    renderList();
                } else {
                    listEl.innerHTML = '<div class="text-danger text-center p-3 small">فشل تحميل الأرقام</div>';
                }
            };

            // إدراج متغيرات
            const insertToken = tokenTxt => { const start = msgArea.selectionStart; const end = msgArea.selectionEnd; const val = msgArea.value; msgArea.value = val.slice(0,start)+tokenTxt+val.slice(end); msgArea.focus(); msgArea.selectionStart = msgArea.selectionEnd = start + tokenTxt.length; msgArea.dispatchEvent(new Event('input')); };

            // إرسال / جدولة
            const handleSend = async ()=>{
                const messageTemplate = msgArea.value.trim();
                if(!messageTemplate){ this.showToast('النص فارغ', false); return; }
                if(!this._smsSelectedIds.size){ this.showToast('اختر مستلمين أولاً', false); return; }
                const scheduleAt = scheduleInput.value; // ISO
                const recipients = this._smsAllRecipients.filter(r=> this._smsSelectedIds.has(r.idNumber));
                // توليد رسائل فردية باستبدال المتغيرات
                const payloadMessages = recipients.map(r=> ({ idNumber: r.idNumber, phone: r.phone, message: messageTemplate.replace(/\{name\}/g, r.fullName).replace(/\{id\}/g, r.idNumber) }));
                sendSpinner.classList.remove('d-none'); sendBtn.disabled=true; sendBtn.querySelector('.btn-text').textContent='جاري الإرسال...';
                const action = scheduleAt? 'scheduleSMSBroadcast' : 'sendSMSBroadcast';
                const result = await this.apiCall({ action, token, messages: payloadMessages, scheduleAt }, false);
                if(result?.success){ this.showToast(scheduleAt? 'تم جدولة الإرسال':'تم إرسال الرسائل', true); }
                else this.showToast(result?.message || 'فشل الإرسال', false);
                sendSpinner.classList.add('d-none'); sendBtn.disabled=false; sendBtn.querySelector('.btn-text').textContent='إرسال / جدولة';
            };

            // حساب التكلفة (تقديري)
            const estimateCost = ()=>{
                const txt = msgArea.value || ''; const length = [...txt].length; const first = 70, next=67; let segments=0; if(length<=first) segments= length?1:0; else segments = 1 + Math.ceil((length-first)/next); const count = this._smsSelectedIds.size; const totalSegments = segments * count; const assumedSegmentCost = 0.05; // تقديري بالدولار / مثال
                costEl.textContent = `عدد الأجزاء الإجمالي: ${totalSegments} | تقدير التكلفة ≈ ${(totalSegments*assumedSegmentCost).toFixed(2)} USD (تقديري)`;
            };

            // Events
            branchFilter.addEventListener('change', applyFilter);
            statusFilter.addEventListener('change', applyFilter);
            searchInput.addEventListener('input', ()=>{ clearTimeout(this.searchTimeout); this.searchTimeout = setTimeout(applyFilter, 300); });
            clearBtn.addEventListener('click', ()=>{ searchInput.value=''; applyFilter(); searchInput.focus(); });
            selectAll.addEventListener('change', ()=>{
                if(selectAll.checked){ this._smsFiltered.forEach(r=> this._smsSelectedIds.add(r.idNumber)); }
                else { this._smsFiltered.forEach(r=> this._smsSelectedIds.delete(r.idNumber)); }
                renderList();
            });
            listEl.addEventListener('change', e=>{
                if(e.target.classList.contains('sms-rec')){ const id = e.target.dataset.id; if(e.target.checked) this._smsSelectedIds.add(id); else this._smsSelectedIds.delete(id); updateSelectedCount(); }
            });
            refreshBtn.addEventListener('click', fetchRecipients);
            msgArea.addEventListener('input', ()=>{ recalcCharStats(); });
            insertNameBtn.addEventListener('click', ()=> insertToken('{name}'));
            insertIdBtn.addEventListener('click', ()=> insertToken('{id}'));
            clearMsgBtn.addEventListener('click', ()=>{ msgArea.value=''; msgArea.dispatchEvent(new Event('input')); previewBox.textContent='—'; });
            previewBtn.addEventListener('click', ()=>{
                const example = this._smsFiltered[0];
                if(!example){ previewBox.textContent='لا يوجد مستلم'; return; }
                previewBox.textContent = (msgArea.value||'').replace(/\{name\}/g, example.fullName).replace(/\{id\}/g, example.idNumber) || '—';
            });
            costBtn.addEventListener('click', estimateCost);
            sendBtn.addEventListener('click', handleSend);

            fetchRecipients();
            recalcCharStats();
        },

        initSpecialCasesPage() {
            const specialCaseForm = document.getElementById('specialCaseForm');
            if (specialCaseForm) {
                specialCaseForm.addEventListener('submit', async function(e) {
                    e.preventDefault();
                    if (!this.checkValidity()) {
                        this.reportValidity();
                        return;
                    }
                    const payload = {
                        action: 'addSpecialCase',
                        name: document.getElementById('caseName').value,
                        idNumber: document.getElementById('caseId').value,
                        phone: document.getElementById('casePhone').value,
                        caseType: document.getElementById('caseType').value,
                        priority: document.getElementById('casePriority').value,
                        date: document.getElementById('caseDate').value,
                        notes: document.getElementById('caseNotes').value
                    };
                    try {
                        const btn = this.querySelector('button[type="submit"]');
                        btn.disabled = true;
                        const res = await fetch(App.WEB_APP_URL, {
                            method: 'POST',
                            mode: 'cors',
                            headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                            body: JSON.stringify(payload)
                        });
                        const result = await res.json();
                        if (!result.success) throw new Error(result.message || 'خطأ في الخادم');
                        App.showToast(result.message, true);
                        this.reset();
                    } catch (err) {
                        App.showToast('فشل الإرسال: ' + (err.message || err), false);
                    } finally {
                        this.querySelector('button[type="submit"]').disabled = false;
                    }
                });

                const resetCase = document.getElementById('resetCase');
                if (resetCase) {
                    resetCase.addEventListener('click', function() {
                        specialCaseForm.reset();
                    });
                }
            }
        },

        // Update user profile function
        async updateUserProfile(userId, profileData) {
            try {
                const payload = {
                    action: 'updateUserProfile',
                    userId: userId,
                    profileData: profileData
                };
                const result = await this.postToAPI(payload, false);
                if (result && result.success) {
                    this.showToast('تم تحديث البيانات الشخصية بنجاح', true);
                    // Reload user data to show updated information
                    if (typeof this.loadUserData === 'function') {
                        this.loadUserData(userId);
                    }
                    return true;
                } else {
                    throw new Error(result?.message || 'فشل في تحديث البيانات');
                }
            } catch (error) {
                console.error('Error updating profile:', error);
                this.showToast('خطأ في تحديث البيانات: ' + error.message, false);
                return false;
            }
        },

        // Global API call function for all pages
        async postToAPI(payload, showSuccessToast = true, activeSubmitButton = null) {
            const isButtonTriggered = activeSubmitButton !== null;
            if (isButtonTriggered) this.toggleButtonSpinner(true, activeSubmitButton);
            try {
                const response = await fetch(this.WEB_APP_URL, { 
                    method: 'POST', 
                    mode: 'cors', 
                    redirect: 'follow', 
                    headers: { 'Content-Type': 'text/plain;charset=utf-8' }, 
                    body: JSON.stringify(payload) 
                });
                if (!response.ok) throw new Error(`خطأ في الشبكة: ${response.statusText}`);
                const result = await response.json();
                if (!result.success) throw new Error(result.message || 'حدث خطأ غير معروف في الخادم.');
                if (showSuccessToast && result.message) this.showToast(result.message, true);
                return result;
            } catch (error) { 
                console.error('API Call Failed:', error); 
                this.showToast(error.message, false); 
                return null; 
            } finally { 
                if (isButtonTriggered) this.toggleButtonSpinner(false, activeSubmitButton); 
            }
        },

        // وظائف الإشعارات
        async getUserNotifications(userId) {
            try {
                const result = await this.apiCall({
                    action: 'getUserNotifications',
                    userId: userId
                });
                return result;
            } catch (error) {
                console.error('خطأ في جلب الإشعارات:', error);
                return null;
            }
        },

        // Helper function to convert file to Base64
        fileToBase64: (file) => new Promise((resolve, reject) => {
            if (!file) {
                resolve(null);
                return;
            }
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => {
                const result = reader.result;
                const base64Data = result.substring(result.indexOf(',') + 1);
                resolve({ name: file.name, mimeType: file.type, data: base64Data });
            };
            reader.onerror = error => reject(error);
        }),

        async getFamilyMembers(userId) {
            try {
                const result = await this.apiCall({
                    action: 'getFamilyMembers',
                    userId: userId
                }, false, true); // Use cache for displaying family members
                return result;
            } catch (error) {
                console.error('خطأ في جلب أفراد العائلة:', error);
                return null;
            }
        },

        async getFamilyMembersApproved(userId) {
            try {
                const result = await this.apiCall({
                    action: 'getFamilyMembers',
                    userId: userId
                }, false, true); // Use cache for displaying approved family members
                
                // فلترة الأفراد المعتمدة فقط
                if (result && result.familyMembers && Array.isArray(result.familyMembers)) {
                    const approvedMembers = result.familyMembers.filter(member => 
                        member.status === 'معتمد' || member.status === 'موافق عليه' || 
                        member.status === 'approved' || member.status === 'معتمد من الإدارة'
                    );
                    return { ...result, familyMembers: approvedMembers };
                }
                
                return result;
            } catch (error) {
                console.error('خطأ في جلب الأفراد المعتمدين:', error);
                return null;
            }
        },

        // دوال أفراد العائلة
        showAddFamilyMemberModal() {
            const modal = new bootstrap.Modal(document.getElementById('addFamilyMemberModal'));
            modal.show();
        },

        // Admin notification helpers (centralized)
        async getAdminNotifications(token) {
            if (!token) return null;
            try {
                const result = await this.apiCall({ action: 'getAdminNotifications', token });
                return result;
            } catch (error) {
                console.error('خطأ في جلب إشعارات الأدمن:', error);
                return null;
            }
        },

        async markAdminNotificationAsRead(notificationId, token) {
            if (!notificationId || !token) return null;
            try {
                const result = await this.apiCall({ action: 'markAdminNotificationAsRead', notificationId, token }, true);
                return result;
            } catch (error) {
                console.error('خطأ في تمييز إشعار الأدمن كمقروء:', error);
                return null;
            }
        },

        async markAllAdminNotificationsAsRead(token) {
            if (!token) return null;
            try {
                const result = await this.apiCall({ action: 'markAllAdminNotificationsAsRead', token }, true);
                return result;
            } catch (error) {
                console.error('خطأ في تمييز جميع إشعارات الأدمن كمقروءة:', error);
                return null;
            }
        },

        async markNotificationAsRead(notificationId) {
            try {
                const result = await this.apiCall({
                    action: 'markNotificationAsRead',
                    notificationId: notificationId
                });
                return result;
            } catch (error) {
                console.error('خطأ في تمييز الإشعار كمقروء:', error);
                return null;
            }
        },

        async markAllNotificationsAsRead(userId) {
            try {
                const result = await this.apiCall({
                    action: 'markAllNotificationsAsRead',
                    userId: userId
                });
                return result;
            } catch (error) {
                console.error('خطأ في تمييز جميع الإشعارات كمقروءة:', error);
                return null;
            }
        }
    };

    // Expose globally for pages with inline scripts (e.g., births.html)
    window.App = App;
    App.init();
    // بدء مراقبة حالة الخادم كل 60 ثانية (يمكن تعديل الفترة لاحقاً)
    App.startServerStatusMonitor(60000);

    // إضافة مستمعات الأحداث لأزرار أفراد العائلة
    document.addEventListener('DOMContentLoaded', function() {
        // Attach submit event listener to the form, not the button
        document.getElementById('addFamilyMemberForm')?.addEventListener('submit', (e) => {
            e.preventDefault(); // Prevent default form submission
            App.submitFamilyMemberRequest();
        });
    });

    App.loadFamilyMembers = async function(userId) {
        const container = document.getElementById('familyMembersContainer');
        if (!container) return;

        container.innerHTML = `
            <div class="family-loading-container">
                <div class="family-loading-header">
                    <div class="skeleton skeleton-title"></div>
                    <div class="skeleton skeleton-button"></div>
                </div>
                <div class="family-loading-cards">
                    ${Array.from({length: 3}, (_, i) => `
                        <div class="family-loading-card" style="animation-delay: ${i * 0.1}s;">
                            <div class="family-loading-card-header">
                                <div class="skeleton skeleton-avatar"></div>
                                <div class="skeleton skeleton-name"></div>
                                <div class="skeleton skeleton-status"></div>
                            </div>
                            <div class="family-loading-card-body">
                                <div class="skeleton skeleton-detail"></div>
                                <div class="skeleton skeleton-detail"></div>
                                <div class="skeleton skeleton-detail"></div>
                            </div>
                        </div>
                    `).join('')}
                </div>
                <div class="loading-text">
                    <i class="bi bi-arrow-clockwise spin-animation me-2"></i>
                    جاري تحميل أفراد العائلة...
                </div>
            </div>
            <style>
                .family-loading-container {
                    padding: 20px;
                    background: linear-gradient(135deg, #fff 0%, #f8f9ff 100%);
                    border-radius: 16px;
                    border: 2px solid rgba(103, 126, 234, 0.1);
                }
                .family-loading-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-bottom: 24px;
                }
                .family-loading-card {
                    background: rgba(103, 126, 234, 0.05);
                    border-radius: 12px;
                    padding: 16px;
                    margin-bottom: 12px;
                    animation: pulseLoad 1.5s ease-in-out infinite;
                }
                .family-loading-card-header {
                    display: flex;
                    align-items: center;
                    gap: 12px;
                    margin-bottom: 12px;
                }
                .family-loading-card-body {
                    display: grid;
                    gap: 8px;
                }
                .skeleton {
                    background: linear-gradient(90deg, rgba(103, 126, 234, 0.1) 25%, rgba(103, 126, 234, 0.2) 50%, rgba(103, 126, 234, 0.1) 75%);
                    background-size: 200% 100%;
                    animation: shimmer 2s ease-in-out infinite;
                    border-radius: 8px;
                }
                .skeleton-title { height: 24px; width: 150px; }
                .skeleton-button { height: 36px; width: 100px; }
                .skeleton-avatar { height: 40px; width: 40px; border-radius: 50%; }
                .skeleton-name { height: 20px; width: 120px; }
                .skeleton-status { height: 24px; width: 80px; }
                .skeleton-detail { height: 16px; width: 100%; }
                .loading-text {
                    text-align: center;
                    color: var(--primary-color);
                    font-weight: 600;
                    margin-top: 16px;
                }
                .spin-animation {
                    animation: spin 1s linear infinite;
                }
                @keyframes pulseLoad {
                    0%, 100% { opacity: 1; }
                    50% { opacity: 0.7; }
                }
                @keyframes shimmer {
                    0% { background-position: -200% 0; }
                    100% { background-position: 200% 0; }
                }
                @keyframes spin {
                    from { transform: rotate(0deg); }
                    to { transform: rotate(360deg); }
                }
            </style>
        `;

        try {
            // Load both pending requests and approved members
            const [pendingResult, approvedResult] = await Promise.all([
                App.getFamilyMembers(userId),
                App.getFamilyMembersApproved(userId)
            ]);
            
            let allMembers = [];
            
            // Add pending/processing requests
            if (pendingResult?.success && pendingResult.familyMembers) {
                allMembers = [...pendingResult.familyMembers];
            }
            
            // Add approved members with proper status
            if (approvedResult?.success && approvedResult.approvedMembers) {
                const approvedMembers = approvedResult.approvedMembers.map(member => ({
                    ...member,
                    // Map approved member fields to match family member format
                    requestId: member.approvedId,
                    status: 'معتمد',
                    requestDate: member.approvalDate,
                    adminNotes: member.adminNotes || '',
                    reviewer: member.approvedBy || ''
                }));
                allMembers = [...allMembers, ...approvedMembers];
            }
            
            App.renderFamilyMembers(allMembers);
        } catch (error) {
            console.error('Error loading family members:', error);
            App.renderFamilyMembers([]); // Show empty state on error
        }
    };

    // تحسين الأداء: cache للأيقونات والأصناف
    const GENDER_ICONS = {
        'ذكر': 'bi-person-fill text-primary',
        'أنثى': 'bi-person-fill-dress text-danger'
    };
    
    const RELATION_ICONS = {
        'ابن': 'bi-person-hearts',
        'ابنة': 'bi-person-hearts',
        'زوجة': 'bi-person-heart',
        'والد': 'bi-person-fill-up',
        'والدة': 'bi-person-fill-up'
    };
    
    const STATUS_CLASSES = {
        'مقبول': 'status-approved',
        'معتمد': 'status-approved',
        'مرفوض': 'status-rejected'
    };

    App.renderFamilyMembers = function(familyMembers) {
        const container = document.getElementById('familyMembersContainer');
        if (!container) return;

        if (familyMembers.length === 0) {
            container.innerHTML = `
                <div class="family-members-table">
                    <div class="table-responsive" style="display: block;">
                        <table class="table table-hover mb-0">
                            <thead class="table-primary">
                                <tr>
                                    <th scope="col" class="text-center">
                                        <i class="bi bi-person-fill me-2"></i>الاسم الكامل
                                    </th>
                                    <th scope="col" class="text-center">
                                        <i class="bi bi-card-text me-2"></i>رقم الهوية
                                    </th>
                                    <th scope="col" class="text-center">
                                        <i class="bi bi-calendar3 me-2"></i>تاريخ الميلاد
                                    </th>
                                    <th scope="col" class="text-center">
                                        <i class="bi bi-gender-ambiguous me-2"></i>الجنس
                                    </th>
                                    <th scope="col" class="text-center">
                                        <i class="bi bi-people-fill me-2"></i>صلة القرابة
                                    </th>
                                    <th scope="col" class="text-center">
                                        <i class="bi bi-file-earmark-text me-2"></i>نوع الدليل
                                    </th>
                                    <th scope="col" class="text-center">
                                        <i class="bi bi-check-circle me-2"></i>الحالة
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="7" class="text-center py-5">
                                        <div class="empty-family-state">
                                            <i class="bi bi-people-fill text-muted mb-3 d-block" style="font-size: 3rem;"></i>
                                            <p class="text-muted mb-3">لا يوجد أفراد عائلة مسجلين حتى الآن.</p>
                                            <button class="btn btn-primary btn-lg" data-bs-toggle="modal" data-bs-target="#addFamilyMemberModal">
                                                <i class="bi bi-person-plus me-2"></i>إضافة فرد جديد
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <!-- عرض الجوال - حالة فارغة مميزة -->
                    <div class="family-mobile-cards">
                        <div class="family-mobile-empty">
                            <div class="empty-icon-container">
                                <i class="bi bi-people-fill"></i>
                                <div class="empty-icon-glow"></div>
                            </div>
                            <h6>لا يوجد أفراد عائلة</h6>
                            <p>ابدأ بإضافة أفراد عائلتك للحصول على المساعدات المناسبة</p>
                            <button class="btn btn-primary btn-lg pulse-btn" data-bs-toggle="modal" data-bs-target="#addFamilyMemberModal">
                                <i class="bi bi-person-plus me-2"></i>إضافة فرد جديد
                            </button>
                        </div>
                    </div>
                </div>
                <style>
                    .empty-icon-container {
                        position: relative;
                        display: inline-block;
                        margin-bottom: 20px;
                    }
                    .empty-icon-glow {
                        position: absolute;
                        top: 50%;
                        left: 50%;
                        transform: translate(-50%, -50%);
                        width: 80px;
                        height: 80px;
                        background: radial-gradient(circle, rgba(103, 126, 234, 0.2) 0%, transparent 70%);
                        border-radius: 50%;
                        animation: glow 2s ease-in-out infinite alternate;
                    }
                    .pulse-btn {
                        animation: pulse 2s ease-in-out infinite;
                    }
                    @keyframes glow {
                        from { opacity: 0.5; transform: translate(-50%, -50%) scale(0.8); }
                        to { opacity: 1; transform: translate(-50%, -50%) scale(1.2); }
                    }
                    @keyframes pulse {
                        0% { transform: scale(1); }
                        50% { transform: scale(1.05); }
                        100% { transform: scale(1); }
                    }
                </style>
            `;
            return;
        }

        // تحسين الأداء: استخدام template strings مرة واحدة
        const fragment = document.createDocumentFragment();
        const wrapper = document.createElement('div');
        
        // بناء الجدول بسرعة
        const tableRows = [];
        const mobileCards = [];
        
        // معالجة البيانات مرة واحدة
        for (let i = 0; i < familyMembers.length; i++) {
            const member = familyMembers[i];
            const gender = member.memberGender || 'ذكر';
            const relation = member.memberRelation || '';
            const status = member.status || 'قيد المراجعة';
            
            const genderIcon = GENDER_ICONS[gender] || 'bi-person-fill';
            const relationIcon = RELATION_ICONS[relation] || 'bi-people';
            const statusClass = STATUS_CLASSES[status] || 'status-pending';
            const genderBadgeClass = gender === 'ذكر' ? 'bg-primary' : 'bg-danger';
            const statusIcon = (status === 'مقبول' || status === 'معتمد') ? 'bi-check-circle-fill' :
                              status === 'مرفوض' ? 'bi-x-circle-fill' : 'bi-clock-fill';
            
            // بناء صف الجدول
            tableRows.push(`
                <tr class="align-middle" style="animation: slideInRight 0.6s ease-out ${i * 0.05}s both;">
                    <td class="text-center">
                        <div class="d-flex align-items-center justify-content-center">
                            <i class="bi ${genderIcon} me-2 fs-5"></i>
                            <strong>${member.memberName}</strong>
                        </div>
                    </td>
                    <td class="text-center">
                        <span class="badge bg-secondary bg-opacity-25 text-dark px-3 py-2">
                            ${member.memberIdNumber}
                        </span>
                    </td>
                    <td class="text-center">
                        <small class="text-muted">${App.formatDateToEnglish(member.memberBirthDate)}</small>
                    </td>
                    <td class="text-center">
                        <span class="badge ${genderBadgeClass} bg-opacity-75">
                            <i class="bi ${genderIcon.split(' ')[0]} me-1"></i>${gender}
                        </span>
                    </td>
                    <td class="text-center">
                        <span class="badge bg-info bg-opacity-75 text-dark">
                            <i class="bi ${relationIcon} me-1"></i>${relation}
                        </span>
                    </td>
                    <td class="text-center">
                        <small class="text-muted">
                            <i class="bi bi-file-earmark-text me-1"></i>${member.memberProofType || 'غير محدد'}
                        </small>
                    </td>
                    <td class="text-center">
                        <span class="family-member-status ${statusClass}">
                            <i class="bi ${statusIcon} me-1"></i>${status}
                        </span>
                    </td>
                </tr>
            `);
            
            // بناء بطاقة الجوال
            mobileCards.push(`
                <div class="family-mobile-card" style="animation-delay: ${i * 0.05}s;">
                    <div class="family-mobile-card-header">
                        <div class="family-mobile-card-name">
                            <i class="bi ${genderIcon.split(' ')[0]}"></i>${member.memberName}
                        </div>
                        <div class="family-mobile-card-status">
                            <span class="family-member-status ${statusClass}">
                                <i class="bi ${statusIcon} me-1"></i>${status}
                            </span>
                        </div>
                    </div>
                    <div class="family-mobile-card-details">
                        <div class="family-mobile-detail-item">
                            <span class="family-mobile-detail-label">
                                <i class="bi bi-card-text me-1"></i>رقم الهوية
                            </span>
                            <div class="family-mobile-detail-value">${member.memberIdNumber}</div>
                        </div>
                        <div class="family-mobile-detail-item">
                            <span class="family-mobile-detail-label">
                                <i class="bi bi-calendar3 me-1"></i>تاريخ الميلاد
                            </span>
                            <div class="family-mobile-detail-value">${App.formatDateToEnglish(member.memberBirthDate)}</div>
                        </div>
                        <div class="family-mobile-detail-item">
                            <span class="family-mobile-detail-label">
                                <i class="bi bi-gender-ambiguous me-1"></i>الجنس
                            </span>
                            <div class="family-mobile-detail-value">
                                <span class="badge ${genderBadgeClass} bg-opacity-75">
                                    <i class="bi ${genderIcon.split(' ')[0]} me-1"></i>${gender}
                                </span>
                            </div>
                        </div>
                        <div class="family-mobile-detail-item">
                            <span class="family-mobile-detail-label">
                                <i class="bi bi-people-fill me-1"></i>صلة القرابة
                            </span>
                            <div class="family-mobile-detail-value">
                                <span class="badge bg-info bg-opacity-75 text-dark">
                                    <i class="bi ${relationIcon} me-1"></i>${relation}
                                </span>
                            </div>
                        </div>
                        <div class="family-mobile-detail-item">
                            <span class="family-mobile-detail-label">
                                <i class="bi bi-file-earmark-text me-1"></i>نوع الدليل
                            </span>
                            <div class="family-mobile-detail-value">${member.memberProofType || 'غير محدد'}</div>
                        </div>
                    </div>
                </div>
            `);
        }
        
        // بناء HTML مرة واحدة
        wrapper.innerHTML = `
            <div class="family-members-table">
                <div class="table-responsive" style="display: block;">
                    <table class="table table-hover table-striped mb-0">
                        <thead class="table-primary">
                            <tr>
                                <th scope="col" class="text-center">
                                    <i class="bi bi-person-fill me-2"></i>الاسم الكامل
                                </th>
                                <th scope="col" class="text-center">
                                    <i class="bi bi-card-text me-2"></i>رقم الهوية
                                </th>
                                <th scope="col" class="text-center">
                                    <i class="bi bi-calendar3 me-2"></i>تاريخ الميلاد
                                </th>
                                <th scope="col" class="text-center">
                                    <i class="bi bi-gender-ambiguous me-2"></i>الجنس
                                </th>
                                <th scope="col" class="text-center">
                                    <i class="bi bi-people-fill me-2"></i>صلة القرابة
                                </th>
                                <th scope="col" class="text-center">
                                    <i class="bi bi-file-earmark-text me-2"></i>نوع الدليل
                                </th>
                                <th scope="col" class="text-center">
                                    <i class="bi bi-check-circle me-2"></i>الحالة
                                </th>
                            </tr>
                        </thead>
                        <tbody>${tableRows.join('')}</tbody>
                    </table>
                </div>
                <div class="family-mobile-cards">${mobileCards.join('')}</div>
            </div>
            <div class="text-center mt-4">
                <button class="btn btn-primary btn-lg add-member-btn" data-bs-toggle="modal" data-bs-target="#addFamilyMemberModal">
                    <i class="bi bi-person-plus me-2"></i>إضافة فرد جديد للعائلة
                </button>
            </div>
            <style>
                @keyframes slideInRight {
                    from { opacity: 0; transform: translateX(30px); }
                    to { opacity: 1; transform: translateX(0); }
                }
                .add-member-btn {
                    transition: all 0.3s ease;
                    box-shadow: 0 4px 15px rgba(103, 126, 234, 0.3);
                }
                .add-member-btn:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 6px 20px rgba(103, 126, 234, 0.4);
                }
            </style>
        `;
        
        // استبدال المحتوى مرة واحدة (أسرع طريقة)
        container.innerHTML = '';
        container.appendChild(wrapper);
    };

    // زر تحديث بيانات المستخدم
    document.getElementById('refreshUserDataBtn')?.addEventListener('click', function() {
        const userId = localStorage.getItem('loggedInUserId');
        if (userId) {
            App.loadUserData(userId);
            App.loadFamilyMembers(userId); // Refresh family members as well
            App.showToast('تم تحديث البيانات بنجاح!', true);
        } else {
            App.showToast('تعذر العثور على معرف المستخدم.', false);
        }
    });

    // زر تعديل بيانات المستخدم
    document.getElementById('editUserDataBtn')?.addEventListener('click', function() {
        // جلب القيم الحالية من الصفحة
        document.getElementById('editPhoneModal').value = document.getElementById('contactPhone')?.textContent || '';
        // تاريخ الميلاد
        let birthValue = '-';
        const birthEl = Array.from(document.querySelectorAll('.info-label')).find(e => e.textContent.includes('تاريخ الميلاد'));
        if (birthEl) {
            birthValue = birthEl.nextElementSibling?.textContent || '';
        }
        document.getElementById('editBirthModal').value = birthValue !== '-' ? birthValue : '';
        document.getElementById('editLocationModal').value = document.getElementById('contactLocation')?.textContent || '';
        // فتح المودال
        const modal = new bootstrap.Modal(document.getElementById('editUserDataModal'));
        modal.show();
    });

    // حفظ التعديلات من المودال
    document.getElementById('saveUserDataBtn')?.addEventListener('click', async function() {
        const saveBtn = this;
        const originalText = saveBtn.textContent;
        
        try {
            // تعطيل الزر وإظهار حالة التحميل
            saveBtn.disabled = true;
            saveBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>جاري الحفظ...';
            
            // جمع البيانات المعدلة
            const userId = localStorage.getItem('loggedInUserId');
            const profileData = {
                'رقم الهاتف': document.getElementById('editPhoneModal')?.value || '',
                'العنوان': document.getElementById('editLocationModal')?.value || '',
                'تاريخ الميلاد': document.getElementById('editBirthModal')?.value || ''
            };
            
            // إرسال البيانات للسيرفر
            console.log('📤 إرسال تحديث البيانات للسيرفر:', profileData);
            const response = await App.apiCall({
                action: 'updateUserProfile',
                userId: userId,
                profileData: profileData
            });
            
            if (response?.success) {
                console.log('✅ تم تحديث البيانات في السيرفر بنجاح');
                
                // تحديث القيم في الواجهة مباشرة
                if (document.getElementById('contactPhone')) {
                    document.getElementById('contactPhone').textContent = profileData['رقم الهاتف'];
                }
                if (document.getElementById('contactLocation')) {
                    document.getElementById('contactLocation').textContent = profileData['العنوان'];
                }
                
                // تحديث تاريخ الميلاد
                const birthEl = Array.from(document.querySelectorAll('.info-label')).find(e => e.textContent.includes('تاريخ الميلاد'));
                if (birthEl && birthEl.nextElementSibling && profileData['تاريخ الميلاد']) {
                    birthEl.nextElementSibling.querySelector('.value-text').textContent = profileData['تاريخ الميلاد'];
                }
                
                // إغلاق المودال
                const modal = bootstrap.Modal.getInstance(document.getElementById('editUserDataModal'));
                if (modal) modal.hide();
                
                // إعادة تحميل البيانات من السيرفر لضمان التحديث الكامل
                console.log('🔄 إعادة تحميل البيانات من السيرفر...');
                await App.loadUserData(userId, true); // force reload
                
                App.showToast('✅ تم تحديث البيانات بنجاح!', true);
            } else {
                throw new Error(response?.message || 'فشل تحديث البيانات');
            }
            
        } catch (error) {
            console.error('❌ خطأ في حفظ البيانات:', error);
            App.showToast('❌ حدث خطأ في حفظ البيانات: ' + error.message, false);
        } finally {
            // إعادة تفعيل الزر
            saveBtn.disabled = false;
            saveBtn.innerHTML = originalText;
        }
    });
});

// Function to show the injury modal
function showInjuryForm() {
    // The injury modal was removed; navigate to the dedicated injuries page.
    window.location.href = 'injuries.html';
}

// Handle injury form submission
const _injuryForm = document.getElementById('injuryForm');
if (_injuryForm) {
    _injuryForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const submitBtn = this.querySelector('button[type="submit"]');
        const spinner = submitBtn?.querySelector('.spinner-border');
        const buttonText = submitBtn?.querySelector('.button-text');
        if (spinner) spinner.classList.remove('d-none');
        if (buttonText) buttonText.textContent = 'جاري الحفظ...';
        if (submitBtn) submitBtn.disabled = true;

        // Simulate data saving (replace with actual backend API call)
        setTimeout(() => {
            // Hide loading state
            if (spinner) spinner.classList.add('d-none');
            if (buttonText) buttonText.textContent = 'تم الحفظ بنجاح';

            // Reset form and close modal
            setTimeout(() => {
                this.reset();
                const modalEl = document.getElementById('injuryModal');
                if (modalEl) {
                    const instance = bootstrap.Modal.getInstance(modalEl);
                    if (instance) instance.hide();
                }
                if (submitBtn) submitBtn.disabled = false;
                if (buttonText) buttonText.textContent = 'حفظ بيانات الإصابة';

                // Show success message using app toast and dialog
                if (typeof App !== 'undefined' && App && typeof App.showToast === 'function') {
                    App.showToast('تم تسجيل الإصابة بنجاح!', true);
                } else {
                    console.log('تم تسجيل الإصابة بنجاح!');
                }
                // Optionally show a confirmation dialog for more details
                if (typeof App !== 'undefined' && App && typeof App.showDialog === 'function') {
                    App.showDialog({ title: 'تم الحفظ', message: 'تم تسجيل الإصابة بنجاح ويمكنك مشاهدة السجل أو إضافة حالة جديدة.', type: 'success', confirmText: 'حسناً', autoCloseMs: 3000 });
                }
            }, 1500);
        }, 2000);
    });
}

// تمت إزالة checkServerStatus العالمية لوجود النسخة الموحّدة داخل App

/*
 Shared client-side pagination module
 Exposes: initMembersPagination, initAidLogsPagination, initReportsPagination, initResetRequestsPagination
 Each initializer accepts an array (or opts) and will render into the page's table using the known IDs.
*/
(function(){
    function escapeHtml(s){ if (!s && s!==0) return ''; return String(s).replace(/[&<>"']/g, function(c){ return {'&':'&','<':'<','>':'>','"':'"',"'":"&#39;"}[c]; }); }

    function createPaginationButton(text, enabled, onClick, active){
        const li = document.createElement('li');
        li.className = `page-item ${active ? 'active' : ''} ${!enabled ? 'disabled' : ''}`;
        const a = document.createElement('a');
        a.className = 'page-link'; a.href = '#'; a.innerHTML = text;
        if (enabled) a.addEventListener('click', function(e){ e.preventDefault(); onClick(); });
        li.appendChild(a);
        return li;
    }

    function createState(opts){
        return {
            items: Array.isArray(opts.items)? opts.items : [],
            filtered: [],
            page: 1,
            perPage: opts.perPage || 10,
            ids: opts.ids,
            dateKeys: opts.dateKeys || ['تاريخ التسجيل','تاريخ الاستلام','date','createdAt','created_at','datetime']
        };
    }

    function updatePaginationUI(state){
        const totalPages = Math.max(1, Math.ceil(state.filtered.length / state.perPage));
        const startItem = state.filtered.length? ((state.page-1)*state.perPage)+1 : 0;
        const endItem = Math.min(state.page*state.perPage, state.filtered.length);
        if (state.ids.start) document.getElementById(state.ids.start).textContent = startItem;
        if (state.ids.end) document.getElementById(state.ids.end).textContent = endItem;
        if (state.ids.total) document.getElementById(state.ids.total).textContent = state.filtered.length;

        const list = document.getElementById(state.ids.list);
        if (!list) return;
        list.innerHTML = '';
        list.appendChild(createPaginationButton('<i class="bi bi-chevron-right me-1"></i> <span class="d-none d-sm-inline">السابق</span>', state.page>1, ()=>changePage(state, state.page-1)));

        let startPage = Math.max(1, state.page-2);
        let endPage = Math.min(totalPages, state.page+2);
        if (startPage > 1){ list.appendChild(createPaginationButton('1', true, ()=>changePage(state,1))); if (startPage>2){ const dots=document.createElement('li'); dots.className='page-item disabled'; dots.innerHTML='<span class="page-link">...</span>'; list.appendChild(dots); } }
        for (let i=startPage;i<=endPage;i++){ list.appendChild(createPaginationButton(i, true, ()=>changePage(state,i), i===state.page)); }
        if (endPage < totalPages){ if (endPage < totalPages-1){ const dots=document.createElement('li'); dots.className='page-item disabled'; dots.innerHTML='<span class="page-link">...</span>'; list.appendChild(dots); } list.appendChild(createPaginationButton(totalPages, true, ()=>changePage(state,totalPages))); }

        list.appendChild(createPaginationButton('<span class="d-none d-sm-inline">التالي</span> <i class="bi bi-chevron-left ms-1"></i>', state.page<totalPages, ()=>changePage(state, state.page+1)));

        const container = document.getElementById(state.ids.container);
        if (container) container.style.display = state.filtered.length? 'flex' : 'none';
    }

    function renderTableGeneric(state, rowRenderer, colsCount){
        const tbody = document.getElementById(state.ids.body);
        if (!tbody) return;
        if (!state.filtered.length){ tbody.innerHTML = `<tr><td colspan="${colsCount}" class="text-center text-muted py-4">لا توجد سجلات</td></tr>`; updatePaginationUI(state); return; }
        const start = (state.page-1)*state.perPage;
        const end = Math.min(start + state.perPage, state.filtered.length);
        const pageData = state.filtered.slice(start, end);
        tbody.innerHTML = pageData.map(row=> rowRenderer(row)).join('');
        updatePaginationUI(state);
    }

    function changePage(state, p){ const totalPages = Math.max(1, Math.ceil(state.filtered.length / state.perPage)); if (p<1 || p>totalPages) return; state.page = p; if (state.render) state.render(); document.querySelector('.data-table-card')?.scrollIntoView({behavior:'smooth', block:'start'}); }

    function applyFilterGeneric(state, term, extraPredicate){ term = (term||'').toString().trim().toLowerCase(); state.filtered = state.items.filter(it=>{ const name = (it.name||it.fullName||it['الاسم الكامل']||it['المستفيد']||'').toString().toLowerCase(); const idNo = (it.id||it.idNo||it['رقم الهوية']||'').toString().toLowerCase(); const matched = !term || name.includes(term) || idNo.includes(term); return matched && (typeof extraPredicate === 'function' ? extraPredicate(it) : true); });
        const k = state.dateKeys.find(k=> state.items.some(i=> i[k] )); if (k) state.filtered.sort((a,b)=> new Date(b[k]) - new Date(a[k])); state.page = 1; if (state.render) state.render(); }

    // specific inits
    window.initMembersPagination = function(dataArray, perPage = 10){
        const state = createState({ items: Array.isArray(dataArray)? dataArray : [], perPage, ids: { body: 'membersTableBody', list: 'paginationList', container:'paginationContainer', start:'startItem', end:'endItem', total:'totalItems' }, dateKeys: ['تاريخ التسجيل','date','createdAt','created_at'] });
        state.render = ()=> renderTableGeneric(state, (m)=>{
            const fullName = m['الاسم الكامل'] || m.fullName || m.name || '';
            const idNo = m['رقم الهوية'] || m.id || m.idNo || '';
            const phone = m['رقم الجوال'] || m.phone || '';
            const residence = m['مكان الاقامة'] || m.residence || '';
            return `\n                        <tr class="table-row-hover">\n                            <td>\n                                <div class="d-flex align-items-center">\n                                    <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center me-2" style="width:35px;height:35px;"><i class="bi bi-person-fill text-white"></i></div>\n                                    <strong class="text-dark">${escapeHtml(fullName)}</strong>\n                                </div>\n                            </td>\n                            <td><span class="font-monospace bg-light px-2 py-1 rounded">${escapeHtml(idNo)}</span></td>\n                            <td>${escapeHtml(phone)}</td>\n                            <td>${escapeHtml(residence)}</td>\n                            <td>\n                                <div class="btn-group" role="group">\n                                    <button class="btn btn-sm btn-outline-info btn-modern" title="عرض"><i class="bi bi-eye"></i></button>\n                                    <button class="btn btn-sm btn-outline-warning btn-modern" title="تعديل"><i class="bi bi-pencil"></i></button>\n                                </div>\n                            </td>\n                        </tr>\n                    `; }, 5);

        // wire search & filters
        document.addEventListener('DOMContentLoaded', ()=>{
            const searchEl = document.getElementById('memberSearchInput'); if (searchEl){ let t; searchEl.addEventListener('input', ()=>{ clearTimeout(t); t=setTimeout(()=>applyFilterGeneric(state, searchEl.value), 250); }); }
            const branchEl = document.getElementById('branchFilter'); if (branchEl) branchEl.addEventListener('change', ()=> applyFilterGeneric(state, document.getElementById('memberSearchInput')?.value));
            const statusEl = document.getElementById('statusFilter'); if (statusEl) statusEl.addEventListener('change', ()=> applyFilterGeneric(state, document.getElementById('memberSearchInput')?.value));
            if (window.membersData) window.initMembersPagination(window.membersData, perPage);
        });
        // initial load
        state.filtered = [...state.items]; state.page = 1; state.render();
    };

    window.initAidLogsPagination = function(opts){
        // opts: { future: { items: [] }, completed: { items: [] }, perPage }
        const per = (opts && opts.perPage) || 10;
        const futureState = createState({ items: Array.isArray(opts.future?.items)? opts.future.items : [], perPage: per, ids: { body: 'futureAidsTableBody', list: 'paginationList', container:'paginationContainer', start:'startItem', end:'endItem', total:'totalItems' } });
        const completedState = createState({ items: Array.isArray(opts.completed?.items)? opts.completed.items : [], perPage: per, ids: { body: 'completedAidsTableBody', list: 'completedPaginationList', container:'completedPaginationContainer', start:'completedStartItem', end:'completedEndItem', total:'completedTotalItems' } });

        futureState.render = ()=> renderTableGeneric(futureState, (row)=>{
            const name = row.name || row.fullName || row['المستفيد'] || '';
            const idNo = row.id || row.idNo || row['رقم الهوية'] || '';
            const kind = row.kind || row.type || row['نوع المساعدة'] || '';
            const date = row.date || row.createdAt || row['تاريخ الاستلام'] || '';
            const source = row.source || row['مصدر المساعدة'] || '';
            return `\n                            <tr class="table-row-hover">\n                                <td>\n                                    <div class="d-flex align-items-center">\n                                        <div class="bg-primary rounded-circle d-flex align-items-center justify-content-center me-2" style="width:35px;height:35px;"><i class="bi bi-person-fill text-white"></i></div>\n                                        <strong class="text-dark">${escapeHtml(name)}</strong>\n                                    </div>\n                                </td>\n                                <td><span class="font-monospace bg-light px-2 py-1 rounded">${escapeHtml(idNo)}</span></td>\n                                <td>${escapeHtml(kind)}</td>\n                                <td>${escapeHtml(date)}</td>\n                                <td>${escapeHtml(source)}</td>\n                                <td>\n                                    <div class="btn-group" role="group">\n                                        <button class="btn btn-sm btn-outline-info btn-modern" title="عرض"><i class="bi bi-eye"></i></button>\n                                        <button class="btn btn-sm btn-outline-warning btn-modern" title="تعديل"><i class="bi bi-pencil"></i></button>\n                                    </div>\n                                </td>\n                            </tr>\n                        `; }, 6);

// Add profile edit form handler for dashboard
document.addEventListener('DOMContentLoaded', function() {
    // Handle profile edit form submission (dashboard uses id="profileUpdateForm")
    const profileForm = document.getElementById('profileUpdateForm') || document.getElementById('profileEditForm');
    if (profileForm) {
        profileForm.addEventListener('submit', async function(e) {
            e.preventDefault();

            const userId = localStorage.getItem('loggedInUserId') || sessionStorage.getItem('userId') || window.currentUserId;
            if (!userId) {
                App.showToast('لم يتم العثور على معرف المستخدم', false);
                return;
            }

            // Build profileData using the exact sheet headers
            const profileData = {
                'رقم الجوال': (this.querySelector('#editPhone')?.value || '').trim(),
                'البريد الإلكتروني': (this.querySelector('#editEmail')?.value || '').trim(),
                'العنوان': (this.querySelector('#editAddress')?.value || '').trim(),
                'المدينة': (this.querySelector('#editCity')?.value || '').trim(),
                'المحافظة': (this.querySelector('#editProvince')?.value || '').trim(),
                'رقم جوال بديل': (this.querySelector('#editAltPhone')?.value || '').trim(),
                'المهنة': (this.querySelector('#editProfession')?.value || '').trim(),
                'مكان العمل': (this.querySelector('#editWorkPlace')?.value || '').trim(),

                'المؤهل العلمي': (this.querySelector('#editEducation')?.value || '').trim(),
                'المدينة': (this.querySelector('#editCity')?.value || '').trim()
            };

            // Remove empty keys to avoid unnecessary writes (server ignores empty anyway)
            Object.keys(profileData).forEach(k => { if (profileData[k] === '') delete profileData[k]; });

            const result = await App.postToAPI({ action: 'updateUserProfile', userId, profileData }, true);
            if (result && result.success) {
                // Close modal if present
                const modalEl = document.getElementById('editProfileModal') || document.getElementById('editUserDataModal');
                if (modalEl) {
                    const modal = bootstrap.Modal.getInstance(modalEl);
                    if (modal) modal.hide();
                }
                App.showToast(result.message || 'تم تحديث البيانات بنجاح', true);
                if (typeof App.loadUserData === 'function') App.loadUserData(userId);
            } else {
                App.showToast(result?.message || 'فشل في تحديث البيانات', false);
            }
        });
    }
});

        completedState.render = futureState.render; // same layout for completed

        document.addEventListener('DOMContentLoaded', ()=>{
            const fSearch = document.getElementById('futureAidSearchInput'); if (fSearch){ let t; fSearch.addEventListener('input', ()=>{ clearTimeout(t); t=setTimeout(()=> applyFilterGeneric(futureState, fSearch.value), 250); }); }
            const cSearch = document.getElementById('completedAidSearchInput'); if (cSearch){ let t; cSearch.addEventListener('input', ()=>{ clearTimeout(t); t=setTimeout(()=> applyFilterGeneric(completedState, cSearch.value), 250); }); }
            if (opts && (opts.future?.items || opts.completed?.items)){
                futureState.filtered = [...futureState.items]; completedState.filtered = [...completedState.items]; futureState.render(); completedState.render();
            }
            if (window.aidFutureData || window.aidCompletedData){
                initAidLogsPagination({ future: { items: window.aidFutureData || [] }, completed: { items: window.aidCompletedData || [] }, perPage: per });
            }
        });
    };

    window.initReportsPagination = function(dataArray, perPage = 10){
        const state = createState({ items: Array.isArray(dataArray)? dataArray : [], perPage, ids: { body: 'reportTableBody', list: 'reportPaginationList', container:'reportPaginationContainer', start:'reportStartItem', end:'reportEndItem', total:'reportTotalItems' }, dateKeys:['تاريخ الاستلام','date','createdAt','created_at'] });
        state.render = ()=> renderTableGeneric(state, (r)=>{ const name = r.name || r.fullName || r['اسم المستفيد'] || ''; const idn = r.id || r.idNo || r['معرف المستفيد'] || ''; const kind = r.kind || r.type || r['نوع المساعدة'] || ''; const date = r.date || r['تاريخ الاستلام'] || ''; const source = r.source || r['مصدر المساعدة'] || ''; return `\n                <tr>\n                    <td><strong class="text-dark">${escapeHtml(name)}</strong></td>\n                    <td><span class="font-monospace bg-light px-2 py-1 rounded">${escapeHtml(idn)}</span></td>\n                    <td>${escapeHtml(kind)}</td>\n                    <td>${escapeHtml(date)}</td>\n                    <td>${escapeHtml(source)}</td>\n                </tr>\n            `; }, 5);
        document.addEventListener('DOMContentLoaded', ()=>{ if (window.reportData) window.initReportsPagination(window.reportData, perPage); }); state.filtered = [...state.items]; state.page=1; state.render(); };

    window.initResetRequestsPagination = function(dataArray, perPage = 10){
        const state = createState({ items: Array.isArray(dataArray)? dataArray : [], perPage, ids: { body: 'resetRequestsTableBody', list: 'resetPaginationList', container:'resetPaginationContainer', start:'resetStartItem', end:'resetEndItem', total:'resetTotalItems' }, dateKeys:['التاريخ والوقت','date','datetime','createdAt','created_at'] });
        state.render = ()=> renderTableGeneric(state, (r)=>{ const date = r.date || r.datetime || r['التاريخ والوقت'] || ''; const idn = r.id || r.idNo || r['رقم الهوية'] || ''; return `\n                <tr>\n                    <td>${escapeHtml(date)}</td>\n                    <td><span class="font-monospace bg-light px-2 py-1 rounded">${escapeHtml(idn)}</span></td>\n                    <td>\n                        <div class="btn-group" role="group">\n                            <button class="btn btn-sm btn-outline-success btn-modern" title="موافقة"><i class="bi bi-check-lg"></i></button>\n                            <button class="btn btn-sm btn-outline-danger btn-modern" title="رفض"><i class="bi bi-x-lg"></i></button>\n                        </div>\n                    </td>\n                </tr>\n            `; }, 3);
        document.addEventListener('DOMContentLoaded', ()=>{ if (window.resetRequestsData) window.initResetRequestsPagination(window.resetRequestsData, perPage); }); state.filtered = [...state.items]; state.page=1; state.render(); };

});

// دالة تسجيل عائلة جديدة
async function submitNewFamilyRegistration() {
    const form = document.getElementById('newFamilyRegistrationForm');
    const spinner = document.getElementById('registrationSpinner');
    const submitBtn = event.target;


    // التحقق من صحة النموذج (باستثناء التحقق من صحة رقم الهوية للطلبات الجديدة)
    // ملاحظة: تم إلغاء التحقق من صحة رقم الهوية للطلبات الجديدة لأنها تخضع للمراجعة الإدارية
    if (!form.checkValidity()) {
        // إزالة أي رسائل خطأ متعلقة برقم الهوية قبل التحقق من صحة النموذج
        const idFields = document.querySelectorAll('#husbandIdNumber, #wifeIdNumber');
        idFields.forEach(field => {
            field.classList.remove('is-invalid');
            const feedback = field.nextElementSibling;
            if (feedback && feedback.classList.contains('invalid-feedback')) {
                feedback.remove();
            }
        });
        // إعادة التحقق من صحة النموذج بعد إزالة أخطاء رقم الهوية
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }
    }

    // التحقق من وجود رقم الهوية في شيت الأفراد أصبح يتم مباشرة عند إدخال الحقل (انظر الأسفل)

    // التحقق من الموافقة على الشروط
    if (!document.getElementById('agreeToTerms').checked) {
        App.showToast('يرجى الموافقة على الشروط والأحكام', false);
        return;
    }

    // التحقق من رفع الملفات
    const requiredFiles = ['marriageContractFile', 'husbandIdFile', 'wifeIdFile'];
    for (const fileId of requiredFiles) {
        const fileInput = document.getElementById(fileId);
        if (!fileInput.files || !fileInput.files[0]) {
            App.showToast(`يرجى رفع ملف ${fileInput.labels[0].textContent}`, false);
            return;
        }

        // التحقق من حجم الملف (5 ميجابايت كحد أقصى)
        if (fileInput.files[0].size > 5 * 1024 * 1024) {
            App.showToast(`حجم ملف ${fileInput.labels[0].textContent} كبير جداً. الحد الأقصى 5 ميجابايت`, false);
            return;
        }
    }

    try {
        // إظهار حالة التحميل
        spinner.classList.remove('d-none');
        submitBtn.disabled = true;

        // إعداد FormData لإرسال البيانات والملفات
        const formData = new FormData();
        
        // إضافة بيانات النموذج
        const formElements = form.elements;
        for (let element of formElements) {
            if (element.type === 'file') {
                if (element.files && element.files[0]) {
                    formData.append(element.name, element.files[0]);
                }
            } else if (element.type !== 'submit' && element.type !== 'button') {
                formData.append(element.name, element.value);
            }
        }

        // إضافة معلومات إضافية
        formData.append('action', 'submitNewFamilyRegistration');
        formData.append('submissionDate', new Date().toISOString());
        formData.append('status', 'pending'); // حالة انتظار المراجعة

        // إرسال الطلب
        const response = await fetch(App.WEB_APP_URL || App.DEFAULT_WEB_APP_URL, {
            method: 'POST',
            body: formData
        });

        const result = await response.json();

        if (result.success) {
            // إغلاق النافذة
            const modal = bootstrap.Modal.getInstance(document.getElementById('newFamilyRegistrationModal'));
            modal.hide();

            // إعادة تعيين النموذج
            form.reset();

            // عرض رسالة نجاح
            App.showDialog({
                title: 'تم إرسال الطلب بنجاح',
                message: `
                    <div class="text-center">
                        <div class="mb-4">
                            <i class="bi bi-check-circle-fill text-success" style="font-size: 4rem;"></i>
                        </div>
                        
                        <h4 class="text-success mb-3">شكراً لك!</h4>
                        
                        <div class="alert alert-success mb-4" role="alert">
                            <h5 class="alert-heading mb-3">
                                <i class="bi bi-envelope-check me-2"></i>
                                تم إرسال طلب تسجيل العائلة بنجاح
                            </h5>
                            <p class="mb-2">سيتم مراجعة طلبكم من قبل الإدارة خلال <strong>24-48 ساعة</strong></p>
                            <hr>
                            <p class="mb-0">
                                <strong>رقم الطلب:</strong> 
                                <span class="badge bg-primary">${result.requestId || 'سيتم إشعاركم لاحقاً'}</span>
                            </p>
                        </div>
                        
                        <div class="alert alert-info" role="alert">
                            <h6 class="mb-2">
                                <i class="bi bi-telephone me-2"></i>
                                خطوات المتابعة
                            </h6>
                            <p class="mb-0 small">
                                سيتم التواصل معكم عبر رقم الهاتف المسجل لإعلامكم بنتيجة المراجعة والخطوات التالية.
                            </p>
                        </div>
                    </div>
                `,
                type: 'success',
                showConfirmButton: true,
                confirmButtonText: 'حسناً'
            });

        } else {
            throw new Error(result.message || 'حدث خطأ أثناء إرسال الطلب');
        }

    } catch (error) {
        console.error('خطأ في تسجيل العائلة الجديدة:', error);
        App.showToast('حدث خطأ أثناء إرسال الطلب. يرجى المحاولة مرة أخرى.', false);
    } finally {
        // إخفاء حالة التحميل
        spinner.classList.add('d-none');
        submitBtn.disabled = false;
    }
}

// دالة التحقق من صحة رقم الهوية (فلسطيني) - معدلة لتقبل أي رقم
function validatePalestinianId(idNumber) {
    // قبول أي رقم هوية بدلاً من التحقق من الصحة
    return true;
    
    /* الكود الأصلي معطل - يمكن إعادة تفعيله لاحقاً
    // التحقق من أن الرقم يحتوي على 9 أرقام
    if (!/^\d{9}$/.test(idNumber)) {
        return false;
    }

    // خوارزمية التحقق من صحة رقم الهوية الفلسطيني
    let sum = 0;
    for (let i = 0; i < 8; i++) {
        let digit = parseInt(idNumber[i]);
        if (i % 2 === 0) {
            digit *= 1;
        } else {
            digit *= 2;
            if (digit > 9) {
                digit = Math.floor(digit / 10) + (digit % 10);
            }
        }
        sum += digit;
    }

    const checkDigit = (10 - (sum % 10)) % 10;
    return checkDigit === parseInt(idNumber[8]);
    */
}

// إضافة مستمعات الأحداث للتحقق من صحة البيانات والتحذير الفوري عند إدخال رقم هوية موجود
document.addEventListener('DOMContentLoaded', function() {
    // التحقق من صحة أرقام الهوية (تم إلغاء التحقق للطلبات الجديدة)
    // ملاحظة: التحقق من صحة رقم الهوية معطل للطلبات الجديدة لأنها تخضع للمراجعة الإدارية
    const idFields = ['husbandIdNumber', 'wifeIdNumber'];
    idFields.forEach(fieldId => {
        const field = document.getElementById(fieldId);
        if (field) {
            field.addEventListener('blur', async function() {
                // إزالة أي رسائل خطأ سابقة
                this.classList.remove('is-invalid');
                const feedback = this.nextElementSibling;
                if (feedback && feedback.classList.contains('invalid-feedback')) {
                    feedback.remove();
                }

                // تحقق فوري من وجود الهوية في شيت الأفراد
                const idVal = this.value.trim();
                if (idVal) {
                    const res = await App.verifyPersonById(idVal);
                    if (res && res.exists) {
                        App.showDialog({
                            title: 'تنبيه',
                            message: `<div class="text-center"><i class="bi bi-exclamation-triangle text-warning" style="font-size:2.5rem;"></i><br><br><strong>أنت مسجل بالفعل ضمن أفراد العائلة.</strong><br>يرجى تسجيل الدخول ولا داعي لتسجيل عائلة جديدة.</div>`,
                            type: 'warning',
                            showConfirmButton: true,
                            confirmButtonText: 'حسناً'
                        });
                        this.value = '';
                        this.classList.remove('is-valid');
                        return;
                    }
                }
                // إضافة رسالة تأكيد بأن الطلب سيخضع للمراجعة الإدارية
                if (this.value.trim()) {
                    this.classList.remove('is-invalid');
                    this.classList.add('is-valid');
                    let successFeedback = this.nextElementSibling;
                    if (!successFeedback || !successFeedback.classList.contains('valid-feedback')) {
                        successFeedback = document.createElement('div');
                        successFeedback.className = 'valid-feedback';
                        this.parentNode.appendChild(successFeedback);
                    }
                    successFeedback.textContent = 'سيتم التحقق من صحة رقم الهوية أثناء المراجعة الإدارية';
                }
            });
        }
    });

    // التحقق من صحة أرقام الهاتف
    const phoneFields = ['husbandPhone', 'wifePhone'];
    phoneFields.forEach(fieldId => {
        const field = document.getElementById(fieldId);
        if (field) {
            field.addEventListener('blur', function() {
                const phoneNumber = this.value.trim();
                if (phoneNumber && !/^(059|056|055|054|052)\d{7}$/.test(phoneNumber)) {
                    this.classList.add('is-invalid');
                    let feedback = this.nextElementSibling;
                    if (!feedback || !feedback.classList.contains('invalid-feedback')) {
                        feedback = document.createElement('div');
                        feedback.className = 'invalid-feedback';
                        this.parentNode.appendChild(feedback);
                    }
                    feedback.textContent = 'رقم الهاتف غير صحيح (مثال: 0599123456)';
                } else {
                    this.classList.remove('is-invalid');
                    const feedback = this.nextElementSibling;
                    if (feedback && feedback.classList.contains('invalid-feedback')) {
                        feedback.remove();
                    }
                }
            });
        }
    });

    // التحقق من صحة التواريخ
    const dateFields = ['husbandBirthDate', 'wifeBirthDate', 'marriageContractDate'];
    dateFields.forEach(fieldId => {
        const field = document.getElementById(fieldId);
        if (field) {
            field.addEventListener('change', function() {
                const selectedDate = new Date(this.value);
                const today = new Date();
                const minAge = new Date();
                minAge.setFullYear(today.getFullYear() - 100); // حد أقصى 100 سنة

                if (fieldId.includes('Birth')) {
                    // التحقق من العمر (بين 18-100 سنة)
                    const age = today.getFullYear() - selectedDate.getFullYear();
                    if (age < 16 || age > 100) {
                        this.classList.add('is-invalid');
                        let feedback = this.nextElementSibling;
                        if (!feedback || !feedback.classList.contains('invalid-feedback')) {
                            feedback = document.createElement('div');
                            feedback.className = 'invalid-feedback';
                            this.parentNode.appendChild(feedback);
                        }
                        feedback.textContent = 'العمر يجب أن يكون بين 16-100 سنة';
                    } else {
                        this.classList.remove('is-invalid');
                        const feedback = this.nextElementSibling;
                        if (feedback && feedback.classList.contains('invalid-feedback')) {
                            feedback.remove();
                        }
                    }
                } else if (fieldId === 'marriageContractDate') {
                    // التحقق من تاريخ الزواج (لا يجوز أن يكون في المستقبل)
                    if (selectedDate > today) {
                        this.classList.add('is-invalid');
                        let feedback = this.nextElementSibling;
                        if (!feedback || !feedback.classList.contains('invalid-feedback')) {
                            feedback = document.createElement('div');
                            feedback.className = 'invalid-feedback';
                            this.parentNode.appendChild(feedback);
                        }
                        feedback.textContent = 'تاريخ الزواج لا يمكن أن يكون في المستقبل';
                    } else {
                        this.classList.remove('is-invalid');
                        const feedback = this.nextElementSibling;
                        if (feedback && feedback.classList.contains('invalid-feedback')) {
                            feedback.remove();
                        }
                    }
                }
            });
        }
    });
});

// دالة لإضافة العائلة المقبولة إلى شيت الأفراد (تُستدعى من لوحة الإدارة)
async function approveNewFamilyRegistration(requestId, approvalData) {
    try {
        const response = await fetch(App.WEB_APP_URL || App.DEFAULT_WEB_APP_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: 'approveNewFamilyRegistration',
                requestId: requestId,
                approvalData: approvalData,
                approvedBy: localStorage.getItem('loggedInUserId') || 'admin',
                approvalDate: new Date().toISOString()
            })
        });

        const result = await response.json();
        return result;

    } catch (error) {
        console.error('خطأ في قبول طلب العائلة الجديدة:', error);
        throw error;
    }
}

document.addEventListener('DOMContentLoaded', function() {

    // Expose globally for pages with inline scripts (e.g., births.html)
    window.App = App;
    App.init();
    // بدء مراقبة حالة الخادم كل 60 ثانية (يمكن تعديل الفترة لاحقاً)
    App.startServerStatusMonitor(60000);

});
