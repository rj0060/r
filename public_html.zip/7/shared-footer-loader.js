// Shared Footer Loader with Status Update
function loadSharedFooter() {
    fetch('shared-footer.html')
        .then(response => response.text())
        .then(html => {
            document.getElementById('shared-footer').innerHTML = html;
            
            // Update server status after footer is loaded
            setTimeout(() => {
                const statusDot = document.querySelector('.status-dot');
                const statusText = document.querySelector('.status-text');
                
                if (statusDot && statusText) {
                    statusDot.style.backgroundColor = '#4CAF50';
                    statusDot.style.boxShadow = '0 0 5px #4CAF50';
                    statusText.textContent = 'حالة الخادم: متصل الآن';
                    statusText.style.color = '#4CAF50';
                }
            }, 500);
        })
        .catch(error => console.log('Error loading footer:', error));
}

// Auto-load when script runs
loadSharedFooter();
