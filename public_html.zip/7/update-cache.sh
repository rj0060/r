#!/bin/bash

# Update Script - سكريبت التحديث الشامل
# يقوم بتحديث جميع الملفات وإضافة versioning تلقائياً

echo "=== بدء عملية التحديث الشامل ==="

# الحصول على timestamp الحالي
TIMESTAMP=$(date +%s)
VERSION=$(date +%Y.%m.%d.%H.%M)

echo "الإصدار الجديد: $VERSION"
echo "Timestamp: $TIMESTAMP"

# تحديث ملف الإصدارات
echo "تحديث ملف الإصدارات..."
cat > version.json << EOF
{
  "version": "$VERSION",
  "timestamp": $TIMESTAMP,
  "files": {},
  "lastUpdate": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "cachePolicy": {
    "css": "max-age=31536000",
    "js": "max-age=31536000", 
    "html": "no-cache"
  }
}
EOF

# إضافة إصدارات لجميع الملفات CSS و JS
echo "إضافة إصدارات للملفات..."

# معالجة ملفات CSS
for file in *.css; do
    if [ -f "$file" ]; then
        FILE_TIME=$(stat -f %m "$file" 2>/dev/null || stat -c %Y "$file" 2>/dev/null)
        echo "  CSS: $file -> إصدار $FILE_TIME"
        # إضافة إلى ملف الإصدارات
        sed -i.bak "s/\"files\": {}/\"files\": {\"$file\": $FILE_TIME}/" version.json
    fi
done

# معالجة ملفات JS
for file in *.js; do
    if [ -f "$file" ]; then
        FILE_TIME=$(stat -f %m "$file" 2>/dev/null || stat -c %Y "$file" 2>/dev/null)
        echo "  JS: $file -> إصدار $FILE_TIME"
    fi
done

# تحديث ملفات HTML لتستخدم versioning
echo "تحديث ملفات HTML..."

for html_file in *.html; do
    if [ -f "$html_file" ]; then
        echo "  معالجة: $html_file"
        
        # إنشاء نسخة احتياطية
        cp "$html_file" "$html_file.backup"
        
        # استبدال links CSS
        sed -i.tmp "s/href=\"\([^\"]*\.css\)\"/href=\"\1?v=$TIMESTAMP\"/g" "$html_file"
        
        # استبدال script src
        sed -i.tmp "s/src=\"\([^\"]*\.js\)\"/src=\"\1?v=$TIMESTAMP\"/g" "$html_file"
        
        # تنظيف الملفات المؤقتة
        rm -f "$html_file.tmp"
        
        echo "    ✓ تم تحديث $html_file"
    fi
done

# تحديث ملفات في مجلد hm
if [ -d "hm" ]; then
    echo "تحديث ملفات مجلد hm..."
    cd hm
    
    for html_file in *.html; do
        if [ -f "$html_file" ]; then
            echo "  معالجة: hm/$html_file"
            
            # إنشاء نسخة احتياطية
            cp "$html_file" "$html_file.backup"
            
            # استبدال links CSS
            sed -i.tmp "s/href=\"\([^\"]*\.css\)\"/href=\"\1?v=$TIMESTAMP\"/g" "$html_file"
            
            # استبدال script src
            sed -i.tmp "s/src=\"\([^\"]*\.js\)\"/src=\"\1?v=$TIMESTAMP\"/g" "$html_file"
            
            # تنظيف الملفات المؤقتة
            rm -f "$html_file.tmp"
            
            echo "    ✓ تم تحديث hm/$html_file"
        fi
    done
    
    cd ..
fi

# تحديث .htaccess إذا لم يكن موجوداً
if [ ! -f ".htaccess" ]; then
    echo "إنشاء ملف .htaccess..."
    cat > .htaccess << 'EOF'
# Cache Management Rules
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType text/html "access plus 0 seconds"
    ExpiresByType text/css "access plus 1 year"
    ExpiresByType application/javascript "access plus 1 year"
</IfModule>

<IfModule mod_headers.c>
    <FilesMatch "\.(html|htm)$">
        Header set Cache-Control "no-cache, no-store, must-revalidate"
    </FilesMatch>
    <FilesMatch "\.(css|js)$">
        Header set Cache-Control "public, max-age=31536000"
    </FilesMatch>
</IfModule>
EOF
fi

# إنشاء ملف update log
echo "$VERSION - $TIMESTAMP - تحديث شامل" >> update.log

echo ""
echo "=== تم إنهاء التحديث بنجاح ==="
echo "الإصدار الجديد: $VERSION"
echo "جميع الملفات تم تحديثها مع versioning"
echo ""
echo "لتطبيق التحديثات:"
echo "1. ارفع الملفات على الاستضافة"
echo "2. المستخدمون سيحصلون على التحديثات تلقائياً"
echo "3. في حالة عدم ظهور التحديثات، استخدم Ctrl+F5"
echo ""
