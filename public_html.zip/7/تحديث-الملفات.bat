@echo off
chcp 65001 > nul
title تحديث ملفات الموقع - Cache Busting

echo ===============================================
echo           تحديث ملفات الموقع
echo        حل مشكلة التخزين المؤقت
echo ===============================================
echo.

echo [1] تحديث جميع الملفات (موصى به)
echo [2] تحديث ملفات CSS فقط  
echo [3] عرض حالة الملفات
echo [4] إنشاء نسخة احتياطية
echo [5] استعادة من النسخة الاحتياطية
echo [0] خروج
echo.

set /p choice="اختر رقماً: "

if "%choice%"=="1" goto update_all
if "%choice%"=="2" goto update_css
if "%choice%"=="3" goto show_status
if "%choice%"=="4" goto create_backup
if "%choice%"=="5" goto restore_backup
if "%choice%"=="0" goto exit
goto menu

:update_all
echo.
echo تحديث جميع الملفات...
powershell -ExecutionPolicy Bypass -File "%~dp0Update-Cache.ps1"
echo.
echo تم الانتهاء من التحديث!
pause
goto menu

:update_css
echo.
echo تحديث ملفات CSS فقط...
powershell -ExecutionPolicy Bypass -Command ^
"$timestamp = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds(); ^
Get-ChildItem -Filter '*.html' | ForEach-Object { ^
$content = Get-Content $_.FullName -Raw; ^
$content = $content -replace 'href=\"([^\"]*\.css)\?v=\d+\"', \"href=`\"`$1?v=$timestamp`\"\"; ^
$content = $content -replace 'href=\"([^\"]*\.css)\"(?!\?)', \"href=`\"`$1?v=$timestamp`\"\"; ^
$content | Out-File $_.FullName -Encoding UTF8 -NoNewline; ^
Write-Host \"تم تحديث: $($_.Name)\" ^
}"
echo.
echo تم تحديث ملفات CSS!
pause
goto menu

:show_status
echo.
echo حالة الملفات الحالية:
echo ========================
dir *.css /b 2>nul && echo - ملفات CSS موجودة
dir *.js /b 2>nul && echo - ملفات JS موجودة  
dir *.html /b 2>nul && echo - ملفات HTML موجودة
if exist "version.json" echo - ملف الإصدارات موجود
if exist ".htaccess" echo - ملف .htaccess موجود
echo.
pause
goto menu

:create_backup
echo.
echo إنشاء نسخة احتياطية...
if not exist "backup" mkdir backup
xcopy *.html backup\ /Y > nul 2>&1
xcopy *.css backup\ /Y > nul 2>&1  
xcopy *.js backup\ /Y > nul 2>&1
echo تم إنشاء النسخة الاحتياطية في مجلد backup
pause
goto menu

:restore_backup
echo.
if not exist "backup" (
    echo لا يوجد مجلد نسخ احتياطية!
    pause
    goto menu
)
echo استعادة من النسخة الاحتياطية...
xcopy backup\*.html . /Y > nul 2>&1
xcopy backup\*.css . /Y > nul 2>&1
xcopy backup\*.js . /Y > nul 2>&1  
echo تم استعادة الملفات من النسخة الاحتياطية
pause
goto menu

:menu
cls
goto start

:start
echo ===============================================
echo           تحديث ملفات الموقع
echo        حل مشكلة التخزين المؤقت
echo ===============================================
echo.

echo [1] تحديث جميع الملفات (موصى به)
echo [2] تحديث ملفات CSS فقط  
echo [3] عرض حالة الملفات
echo [4] إنشاء نسخة احتياطية
echo [5] استعادة من النسخة الاحتياطية
echo [0] خروج
echo.

set /p choice="اختر رقماً: "

if "%choice%"=="1" goto update_all
if "%choice%"=="2" goto update_css
if "%choice%"=="3" goto show_status
if "%choice%"=="4" goto create_backup
if "%choice%"=="5" goto restore_backup
if "%choice%"=="0" goto exit

echo خيار غير صحيح!
pause
goto menu

:exit
echo.
echo شكراً لاستخدام أداة تحديث الملفات!
echo لا تنس رفع الملفات على الاستضافة
pause
exit
