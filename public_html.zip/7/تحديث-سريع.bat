@echo off
chcp 65001 > nul
title نظام التحديث التلقائي - عائلة أبو رجيلة
color 0A
echo.
echo ===============================================
echo        🚀 نظام التحديث التلقائي المتقدم
echo        عائلة أبو رجيلة - قديح  
echo ===============================================
echo.
echo 📅 بدء عملية التحديث...

REM الحصول على timestamp حالي  
for /f %%i in ('powershell -command "(Get-Date -UFormat %%s)"') do set timestamp=%%i000

REM الحصول على التاريخ الحالي
for /f %%i in ('powershell -command "(Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')"') do set currentDate=%%i

echo 📅 آخر تحديث: %currentDate%
echo 🔢 Timestamp: %timestamp%

REM إنشاء version.json محدث
(
echo {
echo   "version": "2.0.%timestamp:~0,-3%",
echo   "timestamp": %timestamp%,
echo   "lastUpdate": "%currentDate%",
echo   "files": {
echo     "style.css": "2.0.%timestamp:~0,-3%",
echo     "modern-theme.css": "2.0.%timestamp:~0,-3%", 
echo     "professional-theme.css": "2.0.%timestamp:~0,-3%",
echo     "script.js": "2.0.%timestamp:~0,-3%",
echo     "app-config.js": "2.0.%timestamp:~0,-3%",
echo     "cache-busting.js": "2.0.%timestamp:~0,-3%",
echo     "manage-family-members.html": "2.0.%timestamp:~0,-3%"
echo   },
echo   "features": [
echo     "Advanced cache busting",
echo     "Auto-refresh on updates", 
echo     "Version monitoring",
echo     "Family member bulk approval",
echo     "Real-time updates"
echo   ],
echo   "cachePolicy": {
echo     "css": "max-age=31536000",
echo     "js": "max-age=31536000",
echo     "html": "no-cache"
echo   }
echo }
) > version.json

echo ✅ تم تحديث version.json بنجاح!
echo.
echo ===============================================
echo           🎉 تم الانتهاء من التحديث!
echo ===============================================
echo.
echo 🌐 جميع المستخدمين سيحصلون على التحديث تلقائياً
echo ⏰ خلال 30 ثانية من زيارة الموقع
echo.
echo 💡 نصائح:
echo    • لا تنس رفع الملفات للاستضافة
echo    • تأكد من رفع version.json المحدث
echo    • اختبر الموقع للتأكد من عمل التحديث
echo.
echo ===============================================
pause
